# Phase 15: Granular permissions scaffold + Storage rules

Adapted two pieces from an external Flutter/Firebase reference doc
into this app's existing patterns - phone/OTP auth, Navigator
routing, and the `admin` custom-claim system from Phase 14 all stay
as-is. The reference doc's email/password auth, go_router, and
string-based `role` custom claim were NOT adopted - they'd conflict
with what's already here (see the chat discussion for the full list
of conflicts).

## What changed

- **`lib/models/user_role.dart`** - `UserRole` now carries a
  `hierarchyLevel` (student/parent = 1, teacher = 2, admin = 3) and
  `hasMinimumRole()`/`isAdmin`/`isTeacher` getters. Purely additive -
  `fromStorage()` and the enum names are unchanged, so nothing
  reading/writing the Firestore `role` field breaks.
- **`lib/models/app_permissions.dart`** (new) - `AppPermissions`,
  a set of per-role UI capability flags (`canCreateCourses`,
  `canManageUsers`, etc.) derived from `UserRole`. Explicitly
  documented as a UI-only convenience layer, not a security
  boundary - real enforcement is still `isAdminProvider` (the actual
  claim) for admin things, and Firestore rules for everything else.
  None of the teacher-level flags have a backend to actually act on
  yet (courses are still server-write-only, see firestore.rules) -
  this just gives future teacher-facing screens something principled
  to gate on instead of ad hoc role checks.
- **`lib/providers/user_profile_provider.dart`** - added
  `permissionsProvider`, watchable anywhere `AppPermissions` is
  needed.
- **`storage.rules`** (new) + **`firebase_storage` dependency** +
  **`firebase.json`** storage config - rules for the upload paths
  `lib/admin/widgets/course_form_dialog.dart` and
  `import_questions_dialog.dart` already pick files for (thumbnail,
  PDF, video, question-import) but don't yet upload anywhere (still
  mock/local-only, see README). Write access is gated on the same
  `admin` custom claim as everything else - not a new/different
  admin check. Not wired into the admin screens yet - those file
  pickers still just hold the picked file locally.

## Still not wired

Same caveat as always: `lib/admin/` is still mock data end to end.
This phase adds the permission plumbing and Storage security rules
so they're ready, but no screen calls `firebase_storage` yet.
