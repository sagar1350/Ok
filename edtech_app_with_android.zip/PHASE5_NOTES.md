# Phase 5: Offline sync queue (foundation)

## Problem
Actions a student takes while offline (submitting a quiz, saving notes,
bookmarking, requesting a download, editing their profile) had nowhere
to go until Firestore was reachable again - there was no durable,
typed local queue to hold them.

## What changed

**New models** (`lib/models/`):
- `sync_type.dart` - `SyncType` enum (`quiz`, `notes`, `bookmark`,
  `download`, `profile`) identifying what a queued item represents.
- `sync_status.dart` - `SyncStatus` enum (`pending`, `syncing`,
  `synced`, `failed`) for queue-item lifecycle.
- `sync_item.dart` - `SyncItem`, a `HiveObject` (`typeId: 1`) holding
  `id`, `type`, `payload` (`Map<String, dynamic>`), `status`,
  `createdAt`, and `retryCount`. `type`/`status` are stored as `String`
  rather than the enums directly, so a future enum reorder can't
  silently corrupt already-persisted data; convert via
  `SyncType.name` / `SyncType.values.byName(...)` at the repository
  boundary.
- `sync_item.g.dart` - the Hive `TypeAdapter`. **Hand-written here**
  since this environment has no Flutter/Dart SDK to run
  `build_runner` - regenerate it for real with the command below once
  you're in the actual project.

**New `lib/database/`:**
- `hive_boxes.dart` - centralizes box-name constants: `syncQueue`
  (new) plus `settings`/`downloads`, which `main.dart` previously
  opened with raw string literals.
- `local_database.dart` - `LocalDatabase.init()` now does all Hive
  setup in one place: `Hive.initFlutter()`, registers
  `SyncItemAdapter`, and opens all three boxes. Exposes `syncBox`,
  `settingsBox`, `downloadsBox` getters.

**`main.dart`:** the old inline block
(`Hive.initFlutter()` + two `Hive.openBox` calls) is replaced with a
single `await LocalDatabase.init()` call in the same try/catch, same
place in the startup sequence (after the Firebase block, independent
of whether Firebase succeeded).

**`pubspec.yaml`:** added `hive: ^2.2.3` (needed directly for
`HiveObject`/`@HiveType`/`@HiveField`, previously only pulled in
transitively via `hive_flutter`) and dev dependencies
`hive_generator: ^2.0.1` + `build_runner: ^2.4.10`.

## To do once you're in a real Flutter environment
Run codegen to replace the hand-written adapter with a verified one:

```
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
```

## Deliberately out of scope for this phase
- No UI (e.g. a "N items waiting to sync" indicator).

## Update: queue itself (`lib/services/`)
Added the pieces that actually enqueue and drain `LocalDatabase.syncBox`:

- `queue_constants.dart` - `maxRetry` (5) / `batchSize` (20).
- `retry_policy.dart` - `canRetry(retryCount)` and exponential
  `nextDelay(retryCount)` (2s, 4s, 8s, 16s...).
- `queue_manager.dart` - thin CRUD over the sync box: `add` (dedupes
  by `id`), `pending()`, `remove`, `markSynced`, `markFailed`.
- `queue_processor.dart` - `QueueProcessor.processPending()` drains up
  to `batchSize` pending items per call (re-entrant calls while a
  batch is running are a no-op) and dispatches by `SyncType`:
  - `quiz` → `QuizRepository.submitResult`
  - `profile` → `UserRepository.setRole`
  - `bookmark` / `notes` / `download` → throws `UnimplementedError`
    on purpose (no backend repository method exists for these yet -
    bookmarks/notes have UI but aren't Firestore-backed, downloads
    are local-only via `OfflineLessonStore`), so these items stay
    genuinely retried/visible instead of being silently marked
    `synced`.

  On failure: if retries remain, `retryCount` is bumped directly on
  the item and it's left `status: "pending"` (calling
  `QueueManager.markFailed` here would move it to `"failed"` and
  `pending()` would never see it again - so failed-but-retryable
  items skip that method on purpose). Only once retries are exhausted
  does it call `markFailed` for real, making that item a permanent
  dead letter. Backoff is approximated as "wait N seconds since the
  item was first queued" (`createdAt`), since `SyncItem` has no
  `lastAttemptAt` field yet - fine for avoiding hammering a
  just-failed item every batch, not for precise backoff.

## Still not wired (next follow-up)
- `QueueProcessor` isn't connected to `connectivityProvider` yet, and
  there's no `queueManagerProvider`/`queueProcessorProvider` in
  `repository_providers.dart` - nothing currently calls
  `processQueue()` automatically when the device comes back online.
- Nothing yet calls `QueueManager.add()` from the screens/notifiers
  that perform quiz submission, notes, bookmarks, downloads, or
  profile edits - the queue exists and can be drained, but isn't fed.

## Update: queue_processor.dart redesigned around a callback
Replaced the `SyncType`-switch version with a simpler
`SyncCallback = Future<bool> Function(SyncItem item)` typedef -
`QueueProcessor` no longer knows about repositories at all; the
caller supplies however it wants to actually perform the sync
(`return true`/`return false`), which decouples it from
`QuizRepository`/`UserRepository` and makes it trivial to unit-test
with a fake callback.

Two bugs fixed from the pasted version before wiring it in:
- **Retryable failures were ending up permanently `"failed"`.**
  Calling `QueueManager.markFailed` on every failure sets
  `status: "failed"`, but `QueueManager.pending()` only returns
  `status == "pending"` items - so even with retries remaining, the
  item would never be picked up again. Fixed: bump `retryCount` and
  keep `status: "pending"` while retries remain; only call
  `markFailed` once `RetryPolicy.canRetry` is false (permanent dead
  letter).
- **`await Future.delayed(...)` inside the loop blocked the whole
  batch** - one flaky item's 2s/4s/8s backoff stalled every item
  after it in the same `processQueue()` call. Fixed: don't await the
  delay; it now just means "don't expect this item to be ready again
  until then" rather than gating the batch. A future `processQueue()`
  call retries it immediately - add an elapsed-time check against
  `createdAt`/`retryCount` before dispatching if strict per-item
  backoff (not just "eventually retried") matters.

The real repository dispatch from the previous version wasn't
deleted, just moved: `lib/services/default_sync_handlers.dart` now
exposes `buildRepositorySyncCallback(...)`, a ready-made `SyncCallback`
that switches on `SyncType` and calls `QuizRepository.submitResult` /
`UserRepository.setRole` (`bookmark`/`notes`/`download` still return
`false` - no backend method exists for them). Pass its result as
`QueueProcessor`'s `syncCallback` instead of the `return true;` stub.

## Update: live pending-count stream + dead-letter removal

**`lib/services/queue_stream.dart`** - `QueueStream`, a broadcast
`Stream<int>` singleton. `QueueManager.refreshQueueCount()` pushes the
current `pending().length` to it after every mutation (`add`,
`remove`, `markSynced`, `markFailed`), so anything listening (e.g.
`PendingSyncIndicator`) updates without polling. `main.dart` also
calls it once right after `LocalDatabase.init()`, so items already
queued from a previous session show up immediately instead of
defaulting to 0 until the next mutation.

**`lib/widgets/pending_sync_indicator.dart`** - a small
`StreamBuilder<int>`-backed `Text` ("Pending Sync : N"), renders
nothing at 0 (same pattern as `OfflineBanner`). Not yet placed on any
screen - drop it wherever it should show (dashboard app bar, settings
screen, etc.).

**`QueueManager.add()`** now checks `exists(id)` (`box.containsKey`,
O(1)) instead of `box.values.any(...)` (O(n) scan) before inserting.

**Dead-letter behavior changed.** Once `RetryPolicy.canRetry` is
false, `QueueProcessor` no longer calls `QueueManager.markFailed`
(which left the item sitting in the box forever with
`status: "failed"`) - it now calls `QueueManager.remove(item.id)`
after logging the drop via `AppLogger`, so the `sync_queue` box
doesn't accumulate permanently-broken rows. This is a real tradeoff:
once removed, there's no record left in Hive of what failed or why -
only whatever reached Crashlytics via that log call. `markFailed()`
itself is left in `QueueManager` (unused by the processor now, kept in
case something else calls it directly) rather than deleted, since
removing it wasn't asked for.
