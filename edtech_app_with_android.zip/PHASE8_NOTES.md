# Phase 8: Sync orchestration layer (`lib/sync/`)

## What changed
Matches the layering diagram (User Action → Local Database → Queue
Manager → Queue Processor → Sync Service → API Service → Server) -
this adds the top of that chain, sitting above the Phase 5/6
`QueueManager`/`QueueProcessor`:

- `sync_state.dart` - `SyncState` enum (`idle`, `syncing`,
  `completed`, `failed`). Not yet read or set anywhere - nothing
  currently tracks which state a sync run is in.
- `sync_progress.dart` - `SyncProgress` (`total`/`completed`/
  `percent`). Also not yet produced anywhere - `QueueProcessor`
  doesn't currently report per-item progress as it drains a batch.
- `sync_service.dart` - `SyncService.startSync()` just calls
  `processor.processQueue()`. Added with its existing imports
  (`../services/queue_manager.dart`, `../services/queue_processor.dart`)
  unchanged - both resolve correctly against this project's structure.
- `conflict_resolver.dart` - `ConflictStrategy` enum +
  `ConflictResolver`, holds a strategy but has no `resolve(...)`
  method yet - not called from anywhere.
- `sync_scheduler.dart` - `SyncScheduler.start(sync)` fires a
  `Future<void> Function()` every 5 minutes via `Timer.periodic`;
  `stop()` cancels it.
- `sync_manager.dart` - **missing imports added**
  (`sync_service.dart`, `sync_scheduler.dart` - the pasted file
  referenced `SyncService`/`SyncScheduler` without importing either,
  so it wouldn't have compiled as pasted). `SyncManager.initialize()`
  wires the scheduler's periodic callback to `service.startSync()`.

## Nothing here is instantiated or run yet
No provider, `main.dart`, or anywhere else constructs a `SyncManager`
(which would need a `SyncService`, which needs a `QueueManager` +
`QueueProcessor`, which needs a `SyncCallback` - see
`default_sync_handlers.dart` from Phase 5). This phase adds the
classes; assembling and starting the real object graph is still open.

## Worth knowing before wiring it up
- `SyncScheduler`'s 5-minute timer has no connectivity check - it'll
  fire and call `processQueue()` on schedule whether the device is
  online or not. That's not necessarily wrong (a fully offline
  `processQueue()` call just fails every item's `syncCallback` and
  they stay `pending`/retry per `RetryPolicy`), but it means syncing
  isn't event-driven off `connectivityProvider` coming back online -
  it's purely time-based. Both could coexist (scheduler as a backstop,
  connectivity listener for immediate retries) if that's wanted.
- `SyncProgress`/`SyncState` exist as data shapes but `QueueProcessor.
  processQueue()` doesn't emit either one - there's no plumbing yet
  from "N/M items synced" to a `SyncProgress`, or from
  syncing/completed/failed to `SyncState`. Whatever ends up exposing
  sync status to the UI (a Riverpod provider, most likely, following
  this app's existing pattern) would need `SyncService`/`SyncManager`
  updated to actually produce these values, not just define them.
- `ConflictResolver` has no way to resolve anything yet - it's a
  strategy holder, not a working resolver. None of the sync paths
  (quiz/profile in `default_sync_handlers.dart`) currently detect or
  route through a conflict at all.
