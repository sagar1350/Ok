# Phase 1: Architecture & project structure

## Problem
The app had no data layer. `cloud_firestore` was a dependency in
`pubspec.yaml` but was never imported anywhere - courses and quiz
questions were hardcoded `List<Map<String, dynamic>>` literals inside
`course_list_screen.dart` and `quiz_screen.dart`. Auth called
`FirebaseAuth.instance` directly inside `AuthNotifier` with no
interface. State management was inconsistent: auth/theme/locale used
Riverpod, but courses/quiz/dashboard used local `setState` over
embedded data. None of this was unit-testable without a live Firebase
project.

## What changed
```
lib/
  models/              # Course, CourseChapter, CourseLesson, CourseProgress,
                        # Quiz, QuizQuestion, AppUser, UserRole - plain Dart,
                        # no Firebase/Flutter imports
  repositories/         # abstract interfaces: AuthRepository, UserRepository,
                        # CourseRepository, QuizRepository
  repositories/impl/    # Firestore/Firebase implementations of each
  providers/
    repository_providers.dart  # the one place interfaces are bound to impls
    auth_provider.dart          # refactored to depend on AuthRepository via DI
    course_providers.dart       # course list/filter/detail/dashboard providers
    quiz_provider.dart          # QuizController - replaces setState in QuizScreen
    user_profile_provider.dart  # role read/write
  utils/course_visuals.dart     # maps iconKey/colorKey strings -> IconData/Color
```

Every feature now follows the same shape: **repository interface →
Riverpod provider → screen**. Screens never talk to Firebase directly.

Screens updated to read from providers instead of embedded data:
`course_list_screen.dart`, `course_detail_screen.dart`,
`student_dashboard.dart`, `quiz_screen.dart`, `role_selection_screen.dart`
(now persists the chosen role), `video_player_screen.dart` (now records
lesson progress on open, closing the loop back into "Continue Learning").

`auth_provider.dart`'s public API (`sendOTP`, `verifyOTP`, `logout`,
`authProvider` state shape minus the `user` field) was kept intentionally
stable, so `login_screen.dart`, `otp_screen.dart`, and
`settings_screen.dart` needed no changes.

## Firestore
Schema, security rules, and seed data are new (see `firestore/schema.md`,
`firestore.rules`, `firestore/seed_data.json` + `seed.js`). Rules:
catalog (`courses`, `quizzes`) is read-only for signed-in users; a
user's own profile/enrollments/quiz attempts are readable/writable only
by that user; everything else is denied by default.

## Tests
`test/fakes/` holds in-memory fakes for all four repositories.
`test/app_test.dart` now boots the whole widget tree against fakes
instead of nothing being exercised past the config-error screen.
`test/quiz_controller_test.dart` and `test/course_providers_test.dart`
unit-test the scoring/filtering/progress logic without touching
Firebase - this is the concrete payoff of the interface boundary.

## Deliberately out of scope for this phase
- Payment gateway wiring (`Enroll Now` is still a no-op placeholder)
- Crash reporting (Crashlytics/Sentry) - `AppLogger` still just logs to console
- Course/quiz *authoring* flows (teacher role has no admin UI yet)
- Personalized recommendations (currently ranks by `studentsCount`)
