# Phase 11: Push notifications (FCM) + deep-link navigation

## What changed

**`pubspec.yaml`:** added `firebase_messaging: ^15.1.3` (compatible with
the `firebase_core: ^3.1.0` already pinned - the pasted pubspec's
`firebase_core: ^2.27.0` would have downgraded/conflicted with every
other Firebase package already in use) and `flutter_local_notifications:
^17.2.2`.

**New `lib/services/notification_service.dart`:** a singleton wrapping
FCM + local notification display + deep-link navigation on tap, plus a
top-level `firebaseMessagingBackgroundHandler`. Initialized from
`main.dart` right after `activateAppCheck()`.

**`main.dart`:** registers `FirebaseMessaging.onBackgroundMessage(...)`
and calls `NotificationService().initialize()` inside the existing
Firebase try/catch block, so a notification-setup failure degrades the
same way an AppCheck/Performance failure already does (logged, app still
launches) rather than crashing boot.

**`app.dart`:** `MaterialApp` now has `navigatorKey:
NotificationService.navigatorKey`, so a notification tap can navigate
before any screen's `BuildContext` exists (cold start from a terminated
push).

**`auth_provider.dart`:** `AuthNotifier.logout()` now calls
`NotificationService().deleteToken()` alongside the existing
storage/Hive cleanup - this app already treats logout as "wipe
everything per-user for the next person on a shared device"
(school/library tablets), and a stale FCM token is the same category of
leak as the downloads box it was already clearing.

## Deep links: mapped to this app's real routes, not the pasted ones
The pasted `NavigationService`/`fcm_service.dart` assumed routes
(`/home`, `/profile`, `/post/:id`, `/chat/:id`, `/notification/:id`) and
screens (`HomeScreen`, `ProfileScreen`, `PostDetailScreen`, `ChatScreen`)
that don't exist anywhere in this codebase - it's a generic demo, not
built against this app. `NotificationService._navigate()` instead
targets `app.dart`'s actual `_generateRoute` table:
`course-detail` (with `courseId`), `quiz`, `saved-lessons`, `settings`,
falling back to `/dashboard` for anything else - same "don't crash on
bad input" posture `_generateRoute` itself already has.

One route was deliberately left out: `/video`. `VideoPlayerScreen`
requires a full `Course` object as its route argument (see
`_generateRoute`'s `/video` case), which a push notification's data
payload can't carry. Deep-linking to `/course-detail` and letting the
student pick the lesson from there is the closest safe equivalent.

## What was rejected from the pasted code, and why
- **`fcm_service.dart`'s `sendToTopic()`** - sending pushes directly
  from the client with `'Authorization': 'key=YOUR_SERVER_KEY'`
  hardcoded in the app is a real vulnerability, not just a stub to fill
  in: any FCM server key shipped inside an APK/IPA can be extracted and
  used by anyone to send arbitrary push notifications to every one of
  your users. This wasn't adapted - sending pushes belongs server-side
  (e.g. a Cloud Function triggered by whatever backend event should
  notify a student), outside this Flutter app entirely.
- **The pasted `HomeScreen`** (FCM token displayed on-screen, "Send Test
  Notification" / topic-subscription-chip UI) - a demo harness for the
  FCM plumbing itself, not a screen this app has or needs;
  `StudentDashboard` is this app's actual home screen and wasn't
  touched.
- **`go_router` dependency** - the pasted `pubspec.yaml` listed it (with
  a comment admitting "or use Navigator 2.0"). This app already has a
  complete `onGenerateRoute` table in `app.dart`; adding a second
  routing system alongside it would be a straight conflict, not an
  addition.
- **A second `NavigationService` class storing its own
  `pending_deep_link` SharedPreferences key** - folded into
  `NotificationService` instead (same key name, one owner) rather than
  splitting notification handling and deep-link storage across two
  singletons that would each need to know about the other.
- **Local notification display in the background handler** - the pasted
  version called `showNotification()` there too. For a terminated app,
  FCM's own notification payload is already surfaced by the OS without
  any app code running; showing a second local notification on top
  would double it. The background handler here only logs and stashes
  the deep link.

## Still open
- Android manifest permissions (`POST_NOTIFICATIONS`,
  `RECEIVE_BOOT_COMPLETED`, `VIBRATE`, `WAKE_LOCK`) and the
  `default_notification_channel_id`/icon/color `meta-data` entries:
  same limitation as Phase 10 - no `android/` folder in this checkout to
  edit. Add these once the platform folders exist, or Android
  notifications won't show correctly (and `POST_NOTIFICATIONS` is
  required at runtime on API 33+, separate from the FCM permission
  request already wired in code).
- `SplashScreen._navigateAfterDelay()` now calls
  `NotificationService().processPendingDeepLink()` right after its own
  `pushReplacementNamed` to `/dashboard`/`/login` - so a deep link that
  arrived cold (before `runApp()`, when `navigatorKey.currentState` was
  still null) replays on top of that screen once a real navigator
  exists. This is the one call site for it; a link arriving while the
  app is already past splash goes straight through
  `onMessageOpenedApp`/`onDidReceiveNotificationResponse` instead, which
  already have a live navigator.
- No UI surfaces notification permission status or lets a student manage
  topic subscriptions - `subscribeToTopic`/`unsubscribeFromTopic` exist
  on `NotificationService` but nothing calls them yet.
