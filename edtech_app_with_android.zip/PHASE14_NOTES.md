# Phase 14: Real admin access control (custom claims)

Phase 13 wired the admin dashboard module in but left admin access
entirely client-controlled: picking "Admin" on `RoleSelectionScreen`
just wrote `role: 'admin'` to the user's own Firestore doc, which
`firestore.rules` happily allowed. Anyone could become an admin.
This phase closes that gap. The admin dashboard's *data* is still
mock (unchanged from Phase 13) - this is only about who is allowed
to reach it.

## What changed

- **`functions/`** (new) - a Cloud Functions project with one
  callable, `setAdminRole`, which is now the only code path that can
  grant or revoke the `admin` custom claim on a user's auth token.
  Callable only by an existing admin. `functions/scripts/
  bootstrapFirstAdmin.js` is the one-time, run-by-hand exception that
  creates the very first admin (nothing can satisfy "caller must
  already be admin" before one exists) - not deployed, not reachable
  by the app, uses a service account directly.
- **`firestore.rules`** - `isValidRole` split into
  `isSelfServiceRole` (`student` / `teacher` / `parent` - what a
  client may write to its own `role` field) with `admin` removed from
  that list entirely. A client can no longer write `role: 'admin'` on
  its own profile, at create *or* update time. The Firestore `role`
  field was always just a UI label; it's now also impossible to fake.
  (Added `firestore/rules_test` cases for both.)
- **`lib/repositories/auth_repository.dart`** /
  **`impl/firebase_auth_repository.dart`** - new `isAdmin()`, reading
  the `admin` custom claim off `getIdTokenResult()`. This is the
  actual authorization check now - never the Firestore `role` field.
  `test/fakes/fake_auth_repository.dart` got a matching
  `isAdminValue` for tests.
- **`lib/providers/admin_access_provider.dart`** (new) -
  `isAdminProvider`, the single source of truth the app uses to
  decide "show admin UI or not."
- **`lib/screens/splash_screen.dart`** - routes a returning user to
  `/admin` based on `isAdminProvider`, not `userProfileProvider`'s
  role field.
- **`lib/widgets/admin_route_guard.dart`** (new) + **`lib/app.dart`**
  - the `/admin` route itself now re-checks the claim
  (`AdminRouteGuard`), independent of how the route was reached.
  Splash already checks before navigating, but a deep link or a
  stale back-stack entry shouldn't get a free pass - this is the
  actual gate, not just a convenience redirect.
- **`lib/screens/role_selection_screen.dart`** - the Admin card no
  longer calls `setRole(UserRole.admin)` (Firestore would reject it
  now anyway). It force-refreshes the ID token and checks the real
  claim: already-admin goes straight to `/admin`, everyone else sees
  a dialog explaining access is granted by an existing admin, not
  self-service.
- **`lib/services/admin_role_service.dart`** (new) + `cloud_functions`
  dependency - typed wrapper around the `setAdminRole` callable, for
  whenever the User Management screen moves off mock data and needs
  a real "make this user an admin" action.
- **`firebase.json`** - added a `functions` source + emulator entry.

## Still mock / not yet wired

Same caveat as Phase 13: `lib/admin/models/*` is still hand-written
mock data. Wiring a real User Management screen to
`AdminRoleService.setAdminRole()` is the natural next step once that
screen moves onto the repository/provider pattern, but is out of
scope here - this phase only closes the "anyone can become admin"
hole.

## Deploying / testing this

```
cd functions && npm install
firebase deploy --only firestore:rules,functions
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json \
  node functions/scripts/bootstrapFirstAdmin.js <your-uid>
```

Sign in through the app once first (so the uid/profile doc exist),
then run the bootstrap script with that uid. After that, re-tap
Admin on the role screen (or restart the app) - it force-refreshes
the token and will now find the claim.
