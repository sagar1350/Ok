# EdTech App

A Flutter-based EdTech app (student login via OTP, course listing, video
lessons, quizzes, multi-language UI).

## Tech stack
- Flutter + Riverpod (state management)
- Firebase Auth (phone/OTP) + Cloud Firestore + App Check (abuse prevention)
- Hive (local cache) + flutter_secure_storage (secure token storage)
- English / Hindi localization

## Architecture
```
lib/
  models/            # Course, Quiz, AppUser, etc - plain Dart, no Firebase/Flutter deps
  repositories/       # abstract interfaces (CourseRepository, AuthRepository, ...)
  repositories/impl/  # Firestore-backed implementations
  providers/          # Riverpod providers - repository_providers.dart is the one
                       # place interfaces are bound to implementations
  screens/            # UI only - reads from providers, no embedded data
  services/           # local-only concerns with no Firebase dependency (offline lesson store)
  widgets/            # small reusable UI pieces shared across screens (offline banner, skeletons)
  utils/              # cross-cutting: logger, config check, icon/color lookups, App Check
  admin/              # Exam Admin Dashboard module - see below, deliberately not on the
                       # repository/provider pattern above yet
```

### Admin dashboard (`lib/admin/`)
A content/ops admin panel - Dashboard, User Management, Course
Management, Quiz Management, Live Classes, Payments, Settings, and
Analytics - reachable by picking **Admin** on `RoleSelectionScreen`
(`UserRole.admin`, routed to `/admin` → `AdminDashboardScreen`). A
returning signed-in admin is sent straight there from `SplashScreen`
instead of the student shell.

It was built as a separate standalone Flutter Web app and is dropped in
mostly as-is rather than refactored onto this app's
repository/provider/Firestore pattern:
- Everything in `lib/admin/models/*` is still **mock data** (no
  Firestore reads/writes) - same swap-this-file-for-a-real-API-call
  scoping the module's own screens document inline. Wiring it to real
  data means giving it `repositories/`+`providers/` the same way the
  student-facing features already have, not editing the screens
  themselves.
- It carries its own theme (`lib/admin/admin_theme.dart`, "ink &
  marigold" - deliberately distinct from the student app's indigo/violet
  theme) mounted via a `Theme` wrapper in `AdminDashboardScreen` so it
  doesn't override `MaterialApp.theme` for the rest of the app.
- Reaching this screen **is** real access control (see
  `PHASE14_NOTES.md`): gated on the `admin` custom claim on the
  Firebase ID token, granted only by the `setAdminRole` Cloud
  Function / the one-time `bootstrapFirstAdmin.js` script - never by
  the client. `firestore.rules` rejects any client attempt to write
  `role: 'admin'` on its own profile. The dashboard's *data* is still
  mock, per the point above; only *who can open it* is enforced.
- Added `fl_chart`, `google_fonts`, and `file_picker` back to
  `pubspec.yaml` for this module's charts, typography, and
  thumbnail/PDF/video/question-import file pickers - run `flutter pub
  get` before building.
Every feature follows the same shape: repository interface → Riverpod
provider → screen. Screens never talk to Firebase directly, which
means:
- Widget tests can override `repository_providers.dart` with in-memory
  fakes instead of hitting a real Firestore project (see
  `test/fakes/` and `test/quiz_controller_test.dart` /
  `test/course_providers_test.dart` for examples).
- Swapping a backend later (a different DB, a REST API) means writing
  a new implementation of the interface and changing one line in
  `repository_providers.dart` - no screen changes needed.

See `firestore/schema.md` for the exact collections/fields the
repositories expect, and `firestore/seed_data.json` /
`firestore/seed.js` to populate a fresh Firebase project with sample
courses and a quiz so the app isn't empty on first run.

## Performance & offline
- **Firestore persistence** is explicitly configured with an unlimited
  disk cache (`main.dart`) instead of the 40MB default, so a course
  catalog + a student's progress history don't get silently evicted
  and "go offline" on their own.
- **The course catalog loads once per session.** `allCoursesProvider`
  fetches every course a single time; `courseListProvider` filters
  that in-memory result per subject/level tap instead of issuing a new
  Firestore query on every chip press (`test/course_providers_test.dart`
  has a test asserting exactly one fetch across several filter changes).
  `courseDetailProvider` checks that same cached list before falling
  back to a direct fetch, so opening a course from the list is instant
  and works offline.
- **Shimmer skeletons** (`lib/widgets/shimmer_placeholders.dart`) replace
  bare spinners on the course grid and dashboard rows - same layout
  shape as the loaded content, so there's no reflow once data arrives.
- **`OfflineBanner`** (`lib/widgets/offline_banner.dart`, mounted once in
  `app.dart`'s `MaterialApp.builder`) tells the student when they're
  looking at cached data instead of leaving a blank/frozen screen
  unexplained. It reflects device connectivity, not Firestore reachability -
  Firestore's own cache fallback is what actually serves the data.
- **"Saved for Offline Browsing"** (bookmark icon on `VideoPlayerScreen`,
  browsable from Settings → *Saved for Offline Browsing*): saves lesson
  *metadata* locally via `OfflineLessonStore`, not the video file itself.
  YouTube's own terms and `youtube_player_flutter` don't support caching
  the video stream, so this is honestly scoped as "browse your saved
  lesson list without a connection," not "watch without a connection" -
  the UI copy says exactly that.
- Removed `cached_network_image` and `lottie` from `pubspec.yaml` - never
  imported anywhere, so they were pure dead weight on app size and build
  time. (`fl_chart` and `google_fonts` came back in Phase 13 - the admin
  dashboard module actually uses both; see below.)

## Getting started

```bash
flutter pub get
flutter run
```

### 1. Configure Firebase (required)
`lib/firebase_options.dart` currently ships with **placeholder values**.
The app will still launch (it shows a "Setup needed" screen instead of
crashing), but auth/courses/quizzes won't work until you replace them:

```bash
dart pub global activate flutterfire_cli
flutterfire configure
```

This regenerates `lib/firebase_options.dart` with your real project's keys.

### 2. Add data and lock down access
The app reads courses/quizzes from Firestore and stores nothing locally
as mock data - a fresh Firebase project will show empty lists until you
seed it:

```bash
cd firestore
npm install firebase-admin
# Download a service account key from Firebase console > Project
# settings > Service accounts, save it as firestore/service-account.json
node seed.js
```

Then deploy the security rules (`firestore.rules`) so users can only
read the catalog and read/write their own profile/enrollments:
```bash
firebase deploy --only firestore:rules
```

### 3. Turn on App Check (blocks anything that isn't your real app)
Firestore/Auth security rules only decide what a *legitimate* signed-in
user can touch - they don't stop a cloned APK, a scraped API key, or a
bot from calling Firebase directly. [Firebase App Check](https://firebase.google.com/docs/app-check)
closes that gap. The client side is already wired up
(`lib/utils/app_check_init.dart`, called from `main.dart`); to finish
enabling it:

1. Firebase console > App Check > register this app.
2. Debug builds print a debug token to the console/logcat on first run
   - add it under App Check > **Manage debug tokens**, or debug builds
     get rejected once you flip enforcement on.
3. Release builds use Play Integrity (Android) / App Attest (iOS) -
   no extra client code needed, just register the app in the console.
4. Start enforcement in **monitor/unenforced mode** for Firestore and
   Authentication first, watch the App Check metrics for a few days to
   confirm real traffic isn't being rejected, *then* switch to
   "Enforced".

### 4. Turn on Crash reporting & Performance Monitoring
The Dart side is already wired up - `lib/utils/logger.dart` forwards
errors to Crashlytics and `lib/utils/perf_trace.dart` times the
course-catalog fetch as a named trace - but both packages also need a
one-time native Android setup that `flutterfire configure` doesn't do
for you if (like this repo) you're not committing a generated `android/`
folder:

1. Firebase console > Project settings > your Android app > download
   `google-services.json`.
2. Base64-encode it and add it as the `GOOGLE_SERVICES_JSON` repo
   secret (Settings > Secrets and variables > Actions) - CI decodes it
   and applies the Crashlytics/Performance Gradle plugins automatically
   (see the `Configure Crashlytics + Performance Monitoring` step in
   `.github/workflows/build-apk.yml`). Building locally instead of via
   CI: put the file at `android/app/google-services.json` yourself and
   add `apply plugin: 'com.google.gms.google-services'`,
   `apply plugin: 'com.google.firebase.crashlytics'`, and
   `apply plugin: 'com.google.firebase.firebase-perf'` to the bottom of
   `android/app/build.gradle`.
3. Without step 2, the app still builds and runs fine -
   `AppLogger.attachCrashlytics()` and the Performance Monitoring setup
   in `main.dart` are both wrapped in try/catch, so a missing native
   plugin just leaves crash/perf reporting inactive instead of crashing
   startup.
4. Both default to **off in debug builds** (`kDebugMode` check in
   `main.dart`) so local development doesn't pollute the production
   dashboards - trigger a release build to see data show up.

### 5. Test the Firestore rules before you trust them
`firestore.rules` validates field names/types/ranges, not just
ownership (e.g. a quiz score can't exceed its total, `role` can't be
set to an arbitrary string). `firestore/rules_test/` proves this
against the real emulator instead of by inspection:

```bash
npm install --prefix firestore/rules_test
firebase emulators:exec --only firestore \
  "npm test --prefix firestore/rules_test"
```
CI runs this on every push (see `firestore-rules` job in
`.github/workflows/build-apk.yml`).

### 6. Restrict your Firebase API key
The values `flutterfire configure` puts in `firebase_options.dart`
aren't secret the way a server API key is - they're compiled into the
app and can be extracted from any APK - but an *unrestricted* key can
still be abused if someone lifts it. In Google Cloud Console > APIs &
Services > Credentials, restrict the Android key to your app's
package name + SHA-1 fingerprint(s), and the iOS key to your bundle
ID. App Check (above) is the stronger control; key restriction is a
second layer that costs nothing to turn on.

### 7. Configure Razorpay (course purchases & subscriptions)
`functions/index.js` (`createOrder`/`verifyPayment`/`razorpayWebhook`)
needs three secrets - never put these in `pubspec.yaml`, client code,
or source control:

```bash
firebase functions:secrets:set RAZORPAY_KEY_ID
firebase functions:secrets:set RAZORPAY_KEY_SECRET
firebase functions:secrets:set RAZORPAY_WEBHOOK_SECRET
firebase deploy --only functions
```

`RAZORPAY_KEY_ID`/`RAZORPAY_KEY_SECRET` come from the Razorpay
Dashboard → Settings → API Keys (use the test-mode pair first).
`RAZORPAY_WEBHOOK_SECRET` comes from Dashboard → Settings → Webhooks →
Add New Webhook, pointed at the deployed `razorpayWebhook` function's
URL (`firebase deploy` prints it), subscribed to the
`payment.captured` event - this is a backup path so a payment still
gets fulfilled if the app never gets to call `verifyPayment` itself
(closed mid-checkout, dropped connection). See `PHASE16_NOTES.md` for
how the pieces fit together.

### 8. Run tests & lints locally before pushing
```bash
flutter analyze
flutter test
```
CI runs these automatically and will fail the build if either fails.

## CI/CD
`.github/workflows/build-apk.yml` runs on every push to `main` (with
a read-only default `GITHUB_TOKEN` - jobs only get more than `contents:
read` if they explicitly need it):
1. **`build` job**: `flutter analyze` + `flutter test` (build fails if
   either fails), generates launcher icons, builds a **debug APK**
   (always, uploaded as an artifact) and a **signed release APK**
   (only if signing secrets are set - see below), then wipes the
   decoded keystore/`key.properties` off the runner.
2. **`firestore-rules` job**: runs the security rules tests from step 4
   above against the emulator, independently of the Flutter build.

## Release signing (for a real, installable production APK)
A debug APK works for testing but isn't suitable for distribution. To get
a signed release build from CI:

1. Generate a keystore locally:
   ```bash
   keytool -genkey -v -keystore release.keystore -keyalg RSA \
     -keysize 2048 -validity 10000 -alias upload
   ```
2. Base64-encode it: `base64 -i release.keystore | pbcopy` (or `base64 -w0
   release.keystore` on Linux)
3. In your GitHub repo, go to **Settings → Secrets and variables →
   Actions** and add:
   - `ANDROID_KEYSTORE_BASE64` — the base64 string from step 2
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
4. Push again — the workflow will now also produce a signed release APK.

**Never commit `release.keystore` or `key.properties` to git** — they're
already excluded in `.gitignore`.

## Production checklist
- [x] Global error handling (`runZonedGuarded`, `FlutterError.onError`) so
      the app degrades gracefully instead of crashing
- [x] Friendly "setup needed" screen instead of a raw crash when Firebase
      isn't configured
- [x] Route-level guards against missing/invalid navigation arguments
- [x] Lint rules (`analysis_options.yaml`) + CI-enforced `flutter analyze`
- [x] Basic widget tests + CI-enforced `flutter test`
- [x] Custom app icon (`flutter_launcher_icons`)
- [x] Release build + signing pipeline
- [x] Data layer: courses/quizzes/user profiles read from Firestore
      through repository interfaces instead of hardcoded in screens
      (see Architecture section above)
- [x] Firestore security rules (`firestore.rules`) - catalog read-only,
      per-user data locked to its owner, field/type/range validated
      (not just ownership), quiz attempts append-only
- [x] Automated rules tests against the emulator (`firestore/rules_test/`),
      CI-enforced (`firestore-rules` job)
- [x] Firebase App Check wired up (`lib/utils/app_check_init.dart`) -
      needs enabling in the Firebase console (README step 3) to take effect
- [x] Least-privilege CI token permissions (`permissions: contents: read`)
      and signing material wiped off the runner after use
- [x] Per-user local cache cleared on logout (`AuthNotifier.logout` clears
      the `downloads` Hive box) so a shared device doesn't leak between users
- [x] Unbounded Firestore disk cache + catalog fetched once per session
      and filtered client-side, instead of a query per filter tap (see
      "Performance & offline" section above)
- [x] Shimmer loading skeletons, an offline-status banner, and an
      honestly-scoped "save lesson details for offline browsing" feature
      (see "Performance & offline" section above)
- [x] Unit tests for the repository-backed providers with fake
      implementations (`test/quiz_controller_test.dart`,
      `test/course_providers_test.dart`, `test/offline_lesson_store_test.dart`)
- [ ] Replace placeholder Firebase config with real project (`flutterfire
      configure`) — **you must do this**
- [ ] Seed your Firestore project (`firestore/seed.js`), deploy
      `firestore.rules`, and turn on App Check enforcement (README steps 2-3)
- [ ] Restrict the Firebase API key by package name/SHA-1/bundle ID
      (README step 6)
- [x] Crash reporting: `lib/utils/logger.dart` forwards to Firebase
      Crashlytics once Firebase is up (`AppLogger.attachCrashlytics()`
      in `main.dart`); still prints to console too. Needs
      `GOOGLE_SERVICES_JSON` set in CI (or a local `google-services.json`)
      for the native Gradle plugin to actually activate - see
      "Crash reporting & performance monitoring" below
- [x] Performance monitoring: Firebase Performance auto-instruments
      network calls and screen rendering; `lib/utils/perf_trace.dart`
      adds a named `catalog_fetch` trace around the full course-catalog
      read. Same native setup requirement as Crashlytics above
- [ ] Server-side quiz grading (a Cloud Function) if quiz results ever
      feed into anything higher-stakes than a personal streak - the
      rules validate shape/range but still trust the client's score
- [ ] Payment gateway for course enrollment (`course_detail_screen.dart`'s
      "Enroll Now" button is a no-op placeholder)
- [ ] App Store / Play Store listing assets (screenshots, privacy policy,
      data-safety form)
