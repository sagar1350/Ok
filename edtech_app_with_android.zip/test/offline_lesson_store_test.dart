import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:edtech_app/services/offline_lesson_store.dart';

/// Uses a real Hive box backed by a temp directory rather than mocking
/// it - `OfflineLessonStore` is a thin wrapper over Hive's own API, so
/// the thing worth verifying is the actual persisted shape (composite
/// key, sort order) surviving a real read/write round trip.
void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await Directory.systemTemp.createTemp('offline_lesson_store_test');
    Hive.init(tempDir.path);
    await Hive.openBox('downloads');
  });

  tearDown(() async {
    await Hive.deleteFromDisk();
    await tempDir.delete(recursive: true);
  });

  test('a lesson is not saved until save() is called', () {
    final store = OfflineLessonStore();
    expect(store.isSaved('course_flutter', 'Installing Flutter'), isFalse);
  });

  test('save() then isSaved() round-trips', () async {
    final store = OfflineLessonStore();
    await store.save(
      courseId: 'course_flutter',
      courseTitle: 'Flutter Complete Course',
      lessonTitle: 'Installing Flutter',
      videoUrl: 'https://youtube.com/watch?v=example1',
    );

    expect(store.isSaved('course_flutter', 'Installing Flutter'), isTrue);
  });

  test('the same lesson title in a different course is a distinct entry',
      () async {
    final store = OfflineLessonStore();
    await store.save(
      courseId: 'course_flutter',
      courseTitle: 'Flutter Complete Course',
      lessonTitle: 'Intro',
      videoUrl: 'https://youtube.com/watch?v=a',
    );

    expect(store.isSaved('course_math', 'Intro'), isFalse);
    expect(store.isSaved('course_flutter', 'Intro'), isTrue);
  });

  test('remove() clears a saved lesson', () async {
    final store = OfflineLessonStore();
    await store.save(
      courseId: 'course_flutter',
      courseTitle: 'Flutter Complete Course',
      lessonTitle: 'Intro',
      videoUrl: 'https://youtube.com/watch?v=a',
    );
    await store.remove('course_flutter', 'Intro');

    expect(store.isSaved('course_flutter', 'Intro'), isFalse);
  });

  test('getAll() returns most-recently-saved first', () async {
    final store = OfflineLessonStore();
    await store.save(
      courseId: 'course_flutter',
      courseTitle: 'Flutter Complete Course',
      lessonTitle: 'Older lesson',
      videoUrl: 'https://youtube.com/watch?v=a',
    );
    // Hive stores savedAt as an ISO string sorted lexicographically, so
    // a real (if tiny) delay keeps this test meaningful rather than
    // relying on two DateTime.now() calls happening to differ.
    await Future<void>.delayed(const Duration(milliseconds: 5));
    await store.save(
      courseId: 'course_flutter',
      courseTitle: 'Flutter Complete Course',
      lessonTitle: 'Newer lesson',
      videoUrl: 'https://youtube.com/watch?v=b',
    );

    final all = store.getAll();
    expect(all, hasLength(2));
    expect(all.first['lessonTitle'], 'Newer lesson');
    expect(all.last['lessonTitle'], 'Older lesson');
  });
}
