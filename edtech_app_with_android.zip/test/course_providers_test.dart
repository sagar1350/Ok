import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:edtech_app/models/course_progress.dart';
import 'package:edtech_app/providers/auth_provider.dart';
import 'package:edtech_app/providers/course_providers.dart';
import 'package:edtech_app/providers/repository_providers.dart';
import 'package:edtech_app/repositories/auth_repository.dart';
import 'package:edtech_app/repositories/user_repository.dart';
import 'fakes/fake_auth_repository.dart';
import 'fakes/fake_course_repository.dart';
import 'fakes/fake_user_repository.dart';

class _SignedInAuthNotifier extends AuthNotifier {
  _SignedInAuthNotifier(AuthRepository authRepo, UserRepository userRepo, String uid)
      : super(authRepo, userRepo) {
    state = state.copyWith(uid: uid, isLoggedIn: true);
  }
}

void main() {
  const testUid = 'test-uid';
  late FakeCourseRepository fakeCourseRepo;
  late ProviderContainer container;

  ProviderContainer buildContainer() {
    final fakeAuthRepo = FakeAuthRepository();
    final fakeUserRepo = FakeUserRepository();
    return ProviderContainer(overrides: [
      authRepositoryProvider.overrideWithValue(fakeAuthRepo),
      userRepositoryProvider.overrideWithValue(fakeUserRepo),
      courseRepositoryProvider.overrideWithValue(fakeCourseRepo),
      authProvider.overrideWith(
        (ref) => _SignedInAuthNotifier(fakeAuthRepo, fakeUserRepo, testUid),
      ),
    ]);
  }

  setUp(() {
    fakeCourseRepo = FakeCourseRepository();
  });

  test('course list respects the selected subject filter', () async {
    container = buildContainer();
    addTearDown(container.dispose);

    container.read(courseFilterProvider.notifier).state =
        const CourseFilter(subject: 'Mathematics');

    // courseListProvider derives synchronously from allCoursesProvider -
    // await the underlying fetch once, then read the filtered result.
    await container.read(allCoursesProvider.future);
    final courses = container.read(courseListProvider).value!;
    expect(courses, hasLength(1));
    expect(courses.single.title, 'Mathematics Class 10');
  });

  test('course list with "All" filter returns every course', () async {
    container = buildContainer();
    addTearDown(container.dispose);

    await container.read(allCoursesProvider.future);
    final courses = container.read(courseListProvider).value!;
    expect(courses, hasLength(2));
  });

  test('continue learning surfaces the signed-in user\'s enrollments',
      () async {
    fakeCourseRepo = FakeCourseRepository(enrollmentsByUid: {
      testUid: [
        const CourseProgress(
          courseId: 'course_flutter',
          courseTitle: 'Flutter Complete Course',
          iconKey: 'code',
          colorKey: 'deepPurple',
          lastLessonLabel: 'Lesson 3',
          progressPercent: 0.4,
        ),
      ],
    });
    container = buildContainer();
    addTearDown(container.dispose);

    final progress = await container.read(continueLearningProvider.future);
    expect(progress, hasLength(1));
    expect(progress.single.courseId, 'course_flutter');
  });

  test('changing filters does not re-fetch the catalog', () async {
    container = buildContainer();
    addTearDown(container.dispose);

    await container.read(allCoursesProvider.future);
    expect(fakeCourseRepo.getCoursesCallCount, 1);

    // Flip through a few filter combinations - courseListProvider
    // derives from the already-fetched allCoursesProvider, so none of
    // these should trigger another Firestore read.
    container.read(courseFilterProvider.notifier).state =
        const CourseFilter(subject: 'Mathematics');
    container.read(courseListProvider);
    container.read(courseFilterProvider.notifier).state =
        const CourseFilter(subject: 'Coding', level: 'Beginner');
    container.read(courseListProvider);

    expect(fakeCourseRepo.getCoursesCallCount, 1);
  });

  test('recommended courses are sorted by student count', () async {
    container = buildContainer();
    addTearDown(container.dispose);

    final recommended = await container.read(recommendedCoursesProvider.future);
    expect(recommended.first.title, 'Flutter Complete Course'); // 1200 students
  });
}
