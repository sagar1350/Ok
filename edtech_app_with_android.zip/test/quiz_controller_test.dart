import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:edtech_app/providers/quiz_provider.dart';
import 'package:edtech_app/providers/auth_provider.dart';
import 'package:edtech_app/providers/repository_providers.dart';
import 'package:edtech_app/repositories/auth_repository.dart';
import 'package:edtech_app/repositories/user_repository.dart';
import 'fakes/fake_auth_repository.dart';
import 'fakes/fake_user_repository.dart';
import 'fakes/fake_quiz_repository.dart';

/// AuthNotifier that starts already "logged in" as a fixed uid, so
/// tests can exercise flows that depend on a signed-in user (like the
/// quiz controller submitting a result) without going through the
/// full OTP flow.
class _SignedInAuthNotifier extends AuthNotifier {
  _SignedInAuthNotifier(AuthRepository authRepo, UserRepository userRepo, String uid)
      : super(authRepo, userRepo) {
    state = state.copyWith(uid: uid, isLoggedIn: true);
  }
}

void main() {
  late ProviderContainer container;
  late FakeQuizRepository fakeQuizRepo;
  const testUid = 'test-uid';

  setUp(() {
    fakeQuizRepo = FakeQuizRepository();
    final fakeAuthRepo = FakeAuthRepository();
    final fakeUserRepo = FakeUserRepository();
    container = ProviderContainer(overrides: [
      authRepositoryProvider.overrideWithValue(fakeAuthRepo),
      userRepositoryProvider.overrideWithValue(fakeUserRepo),
      quizRepositoryProvider.overrideWithValue(fakeQuizRepo),
      authProvider.overrideWith(
        (ref) => _SignedInAuthNotifier(fakeAuthRepo, fakeUserRepo, testUid),
      ),
    ]);
    addTearDown(container.dispose);
  });

  Future<void> flushMicrotasks() => Future<void>.delayed(Duration.zero);

  test('loads the daily quiz on creation', () async {
    container.read(quizControllerProvider.notifier);
    await flushMicrotasks();

    final state = container.read(quizControllerProvider);
    expect(state.isLoading, isFalse);
    expect(state.quiz, isNotNull);
    expect(state.quiz!.questions, hasLength(2));
  });

  test('correct answer increments score, wrong answer does not', () async {
    final controller = container.read(quizControllerProvider.notifier);
    await flushMicrotasks();

    // First question's correct index is 1.
    controller.checkAnswer(1);
    expect(container.read(quizControllerProvider).score, 1);
    expect(container.read(quizControllerProvider).isAnswered, isTrue);

    // Answering again before moving on should be a no-op.
    controller.checkAnswer(0);
    expect(container.read(quizControllerProvider).score, 1);
  });

  test('finishing the quiz submits the result via the repository', () async {
    final controller = container.read(quizControllerProvider.notifier);
    await flushMicrotasks();

    controller.checkAnswer(1); // correct
    controller.nextQuestion();
    controller.checkAnswer(0); // wrong (correct is 2)
    controller.nextQuestion();
    await flushMicrotasks();

    final state = container.read(quizControllerProvider);
    expect(state.isFinished, isTrue);
    expect(state.score, 1);
    expect(fakeQuizRepo.submittedResults, hasLength(1));
    expect(fakeQuizRepo.submittedResults.first['uid'], testUid);
    expect(fakeQuizRepo.submittedResults.first['score'], 1);
    expect(fakeQuizRepo.submittedResults.first['total'], 2);
  });

  test('retry resets score and question index without reloading', () async {
    final controller = container.read(quizControllerProvider.notifier);
    await flushMicrotasks();

    controller.checkAnswer(1);
    controller.nextQuestion();
    controller.checkAnswer(2);
    controller.nextQuestion();
    await flushMicrotasks();

    controller.retry();
    final state = container.read(quizControllerProvider);
    expect(state.currentQuestion, 0);
    expect(state.score, 0);
    expect(state.isFinished, isFalse);
    expect(state.isAnswered, isFalse);
  });
}
