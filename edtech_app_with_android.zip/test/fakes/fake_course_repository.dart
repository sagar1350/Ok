import 'package:edtech_app/models/course.dart';
import 'package:edtech_app/models/course_progress.dart';
import 'package:edtech_app/repositories/course_repository.dart';

class FakeCourseRepository implements CourseRepository {
  final List<Course> courses;
  final Map<String, List<CourseProgress>> enrollmentsByUid;
  final List<Map<String, dynamic>> recordedProgress = [];
  int getCoursesCallCount = 0;

  FakeCourseRepository({
    List<Course>? courses,
    Map<String, List<CourseProgress>>? enrollmentsByUid,
  })  : courses = courses ?? _defaultCourses,
        enrollmentsByUid = enrollmentsByUid ?? {};

  static final _defaultCourses = [
    const Course(
      id: 'course_flutter',
      title: 'Flutter Complete Course',
      subject: 'Coding',
      level: 'Beginner',
      description: 'Learn Flutter from scratch.',
      iconKey: 'code',
      colorKey: 'deepPurple',
      lessonsCount: 24,
      durationHours: 12,
      rating: 4.8,
      studentsCount: 1200,
      priceInr: 499,
    ),
    const Course(
      id: 'course_math',
      title: 'Mathematics Class 10',
      subject: 'Mathematics',
      level: 'Intermediate',
      description: 'Board-exam-ready maths.',
      iconKey: 'calculate',
      colorKey: 'teal',
      lessonsCount: 30,
      durationHours: 18,
      rating: 4.6,
      studentsCount: 900,
      priceInr: 0,
    ),
  ];

  @override
  Future<List<Course>> getCourses({String? subject, String? level}) async {
    getCoursesCallCount++;
    return courses.where((c) {
      final subjectOk =
          subject == null || subject == 'All' || c.subject == subject;
      final levelOk = level == null || level == 'All' || c.level == level;
      return subjectOk && levelOk;
    }).toList();
  }

  @override
  Future<Course?> getCourseById(String courseId) async {
    try {
      return courses.firstWhere((c) => c.id == courseId);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<List<CourseProgress>> getContinueLearning(String uid) async {
    return enrollmentsByUid[uid] ?? [];
  }

  @override
  Future<List<Course>> getRecommended(String uid, {int limit = 4}) async {
    final sorted = [...courses]
      ..sort((a, b) => b.studentsCount.compareTo(a.studentsCount));
    return sorted.take(limit).toList();
  }

  @override
  Future<void> recordLessonProgress({
    required String uid,
    required Course course,
    required String lessonLabel,
    required double progressPercent,
  }) async {
    recordedProgress.add({
      'uid': uid,
      'courseId': course.id,
      'lessonLabel': lessonLabel,
      'progressPercent': progressPercent,
    });
  }
}
