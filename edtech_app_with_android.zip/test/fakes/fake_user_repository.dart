import 'dart:async';
import 'package:edtech_app/models/app_user.dart';
import 'package:edtech_app/models/notification_prefs.dart';
import 'package:edtech_app/models/user_role.dart';
import 'package:edtech_app/repositories/user_repository.dart';

class FakeUserRepository implements UserRepository {
  final Map<String, AppUser> _profiles = {};
  final _controllers = <String, StreamController<AppUser?>>{};

  StreamController<AppUser?> _controllerFor(String uid) =>
      _controllers.putIfAbsent(uid, () => StreamController<AppUser?>.broadcast());

  @override
  Future<AppUser?> getProfile(String uid) async => _profiles[uid];

  @override
  Stream<AppUser?> watchProfile(String uid) => _controllerFor(uid).stream;

  @override
  Future<void> createProfileIfMissing(String uid, {String? phoneNumber}) async {
    if (_profiles.containsKey(uid)) return;
    final user = AppUser(uid: uid, phoneNumber: phoneNumber);
    _profiles[uid] = user;
    _controllerFor(uid).add(user);
  }

  @override
  Future<void> setRole(String uid, UserRole role) async {
    final existing = _profiles[uid] ?? AppUser(uid: uid);
    final updated = existing.copyWith(role: role);
    _profiles[uid] = updated;
    _controllerFor(uid).add(updated);
  }

  @override
  Future<void> stampLastActive(String uid) async {
    // No-op for tests - nothing currently asserts on this.
  }

  final Map<String, Map<String, bool>> _prefs = {};
  final _prefsControllers = <String, StreamController<Map<String, bool>>>{};

  Map<String, bool> _prefsFor(String uid) => {
        for (final key in optionalNotificationCategories.keys)
          key: _prefs[uid]?[key] ?? true,
      };

  @override
  Stream<Map<String, bool>> watchNotificationPrefs(String uid) {
    final controller = _prefsControllers.putIfAbsent(
        uid, () => StreamController<Map<String, bool>>.broadcast());
    Future.microtask(() => controller.add(_prefsFor(uid)));
    return controller.stream;
  }

  @override
  Future<void> updateNotificationPrefs(
      String uid, Map<String, bool> prefs) async {
    _prefs[uid] = prefs;
    _prefsControllers[uid]?.add(_prefsFor(uid));
  }
}
