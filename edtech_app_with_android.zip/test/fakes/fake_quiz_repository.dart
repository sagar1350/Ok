import 'package:edtech_app/models/quiz.dart';
import 'package:edtech_app/models/quiz_question.dart';
import 'package:edtech_app/repositories/quiz_repository.dart';

class FakeQuizRepository implements QuizRepository {
  final Quiz? quiz;
  final List<Map<String, dynamic>> submittedResults = [];

  FakeQuizRepository({Quiz? quiz}) : quiz = quiz ?? _defaultQuiz;

  static final _defaultQuiz = Quiz(
    id: 'daily',
    title: 'Daily Quiz',
    questions: const [
      QuizQuestion(
        question: 'What is Flutter?',
        options: [
          'A programming language',
          'A UI toolkit by Google',
          'An operating system',
          'A database',
        ],
        correctIndex: 1,
      ),
      QuizQuestion(
        question: 'Which language is used for Flutter?',
        options: ['Java', 'Kotlin', 'Dart', 'Swift'],
        correctIndex: 2,
      ),
    ],
  );

  @override
  Future<Quiz?> getQuiz(String quizId) async {
    if (quiz == null || quiz!.id != quizId) return null;
    return quiz;
  }

  @override
  Future<void> submitResult({
    required String uid,
    required String quizId,
    required int score,
    required int total,
  }) async {
    submittedResults.add({
      'uid': uid,
      'quizId': quizId,
      'score': score,
      'total': total,
    });
  }
}
