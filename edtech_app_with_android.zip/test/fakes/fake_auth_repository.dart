import 'dart:async';
import 'package:edtech_app/repositories/auth_repository.dart';

/// In-memory stand-in for [AuthRepository]. Lets tests drive login/OTP
/// state without touching Firebase.
class FakeAuthRepository implements AuthRepository {
  final _controller = StreamController<String?>.broadcast();
  String? _uid;
  bool failVerification;
  bool nextOtpSucceeds;
  bool isAdminValue;

  FakeAuthRepository({
    this.failVerification = false,
    this.nextOtpSucceeds = true,
    this.isAdminValue = false,
  });

  @override
  String? get currentUid => _uid;

  @override
  Stream<String?> authStateChanges() => _controller.stream;

  @override
  Future<void> sendOtp(
    String phoneNumber, {
    required void Function(String verificationId) onCodeSent,
    required void Function(String message) onVerificationFailed,
    required void Function() onAutoVerified,
  }) async {
    if (failVerification) {
      onVerificationFailed('Verification failed');
      return;
    }
    onCodeSent('fake-verification-id');
  }

  @override
  Future<bool> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    if (!nextOtpSucceeds) return false;
    _uid = 'fake-uid';
    _controller.add(_uid);
    return true;
  }

  @override
  Future<bool> isAdmin({bool forceRefresh = false}) async => isAdminValue;

  @override
  Future<void> signOut() async {
    _uid = null;
    _controller.add(null);
  }

  void dispose() => _controller.close();
}
