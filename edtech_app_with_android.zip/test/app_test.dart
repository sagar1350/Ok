import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:edtech_app/app.dart';
import 'package:edtech_app/providers/repository_providers.dart';
import 'package:edtech_app/providers/connectivity_provider.dart';
import 'package:edtech_app/screens/config_error_screen.dart';
import 'fakes/fake_auth_repository.dart';
import 'fakes/fake_course_repository.dart';
import 'fakes/fake_quiz_repository.dart';
import 'fakes/fake_user_repository.dart';

/// Widget tests never need to reach Firebase - every screen depends on
/// the repository interfaces, so overriding these four providers with
/// in-memory fakes is enough to boot the whole app tree safely.
///
/// `connectivityProvider` is overridden too, separately from the
/// repositories above: `OfflineBanner` sits in `MyApp`'s builder, so
/// it's on every screen these tests boot, and `connectivity_plus` talks
/// to a real platform channel that doesn't exist under `flutter test` -
/// without this override that call would throw instead of exercising
/// the fake repositories above.
List<Override> get _fakeRepositoryOverrides => [
      authRepositoryProvider.overrideWithValue(FakeAuthRepository()),
      userRepositoryProvider.overrideWithValue(FakeUserRepository()),
      courseRepositoryProvider.overrideWithValue(FakeCourseRepository()),
      quizRepositoryProvider.overrideWithValue(FakeQuizRepository()),
      connectivityProvider.overrideWith((ref) => Stream.value(true)),
    ];

void main() {
  testWidgets('shows config error screen when Firebase is not configured',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      ProviderScope(
        overrides: _fakeRepositoryOverrides,
        child: const MyApp(
          firebaseReady: false,
          firebaseInitError: 'Firebase is not configured yet.',
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType(ConfigErrorScreen), findsOneWidget);
    expect(find.text('Setup needed'), findsOneWidget);
  });

  testWidgets('boots to splash screen when Firebase is ready',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      ProviderScope(
        overrides: _fakeRepositoryOverrides,
        child: const MyApp(firebaseReady: true),
      ),
    );
    // Just confirm it builds without throwing.
    await tester.pump();
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
