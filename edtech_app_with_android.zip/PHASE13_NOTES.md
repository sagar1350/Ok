# Phase 13: Exam Admin Dashboard integrated as a module

Merged the standalone `exam_admin_dashboard` Flutter Web app (8 modules:
Dashboard, User Management, Course Management, Quiz Management, Live
Classes, Payments, Settings, Analytics) into this app as `lib/admin/`,
reachable through the existing role-selection flow instead of shipping
as a second app.

## What changed

- **`lib/admin/`** - copied from the standalone project's `lib/`
  (`models/`, `screens/`, `widgets/`), keeping its internal relative
  import structure intact. `theme.dart` → `admin_theme.dart` (the plain
  name was too easy to import by accident instead of the main app's own
  theme); the ~19 files that imported it were updated to match. No other
  renames - nothing in `lib/admin/` collided with an existing class name
  elsewhere in `lib/`, since Dart scopes by import, not by directory.
- **`lib/admin/admin_dashboard_screen.dart`** (new) - thin wrapper that
  mounts the admin module's `AppShell` under its own `Theme`, so the
  "ink & marigold" admin palette doesn't leak into student-facing
  screens (and the student app's indigo doesn't leak into the admin
  screens either).
- **`lib/models/user_role.dart`** - added `UserRole.admin` to the enum.
- **`firestore.rules`** - `isValidRole` now accepts `'admin'` alongside
  the existing three. This only affects what value a user is allowed to
  write into their own `role` field - it grants no additional Firestore
  read/write permission, since none of the existing rules branch on
  role at all yet. The admin dashboard itself makes no Firestore calls
  (still mock data - see below), so nothing in Firestore is actually
  gated by this role today.
- **`lib/screens/role_selection_screen.dart`** - added an Admin card
  (`Icons.admin_panel_settings`) that sets the role and routes to
  `/admin` instead of `/dashboard`.
- **`lib/app.dart`** - added the `/admin` route → `AdminDashboardScreen`.
- **`lib/screens/splash_screen.dart`** - a returning signed-in user now
  waits for the first `userProfileProvider` emission and routes admins
  to `/admin`; everyone else keeps going to `/dashboard` exactly as
  before (teacher/parent still share the student shell - that was
  already the case pre-Phase-13, not something this phase changed).
- **`assets/translations/{en,hi}.json`** + `app_localizations.dart` -
  added an `admin` string key, mirroring how `student`/`teacher`/`parent`
  were already done.
- **`pubspec.yaml`** - re-added `fl_chart`, `google_fonts`, and
  `file_picker`. Phase-something-earlier's cleanup removed these as
  unused dead weight, which was correct *at the time* - the admin module
  actually uses all three now (charts, Poppins/Inter typography, and
  thumbnail/PDF/video/question-import pickers), so they're back.
  Versions were carried over unchanged from the standalone project's own
  `pubspec.yaml`; I did not run `flutter pub get`/`flutter pub deps` to
  confirm there's no transitive version conflict with `dio`/the Firebase
  packages, since this sandbox has no network access to resolve
  packages - do that before shipping this.

## Deliberately not done

- **Not wired to real data.** Every screen under `lib/admin/` still
  reads its own `lib/admin/models/*` mock files - same as it did as a
  standalone project. This app already has a clean
  repository-interface → Riverpod-provider → screen pattern for exactly
  this kind of swap (see the main Architecture section above); giving
  the admin module `AdminRepository` interfaces + providers that read
  real Firestore collections (or whatever backend ends up managing
  users/courses/quizzes/payments) is the natural next step, but is a
  separate, sizeable piece of work I didn't start speculatively.
- **Not enforced server-side.** Nothing stops a signed-in student from
  manually navigating to `/admin` or a non-admin `role` value from
  reading admin-only data, because there is no admin-only data yet - it's
  all local mock state. Once the module reads/writes anything real,
  `firestore.rules` needs actual `role == 'admin'` checks on whatever
  collections it touches, not just an allowed-values check on the role
  field itself.
- **Not merged into one `ThemeData`.** Kept the admin module's palette
  fully separate (scoped `Theme` wrapper) rather than reconciling it
  with the student app's `MaterialApp.theme` in `app.dart`, since the
  two were designed independently and forcing one palette onto both
  would mean redesigning one of them, not just a config change.
- **File-picker uploads are still mock/in-memory**, same limitation the
  standalone project's own README already documented for course
  thumbnails/PDFs/videos and quiz-question import - unchanged by this
  integration.
