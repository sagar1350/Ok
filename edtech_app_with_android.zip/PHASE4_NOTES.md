# Phase 4: Crash reporting & performance monitoring

## Problem
`lib/utils/logger.dart` already centralized every error through one
function, with a comment saying to wire it up to Crashlytics "in
production" - but nothing did. Errors only ever reached the debug
console, so anything that went wrong on a real student's device (the
target audience skews toward less reliable phones/connections) was
invisible unless they happened to report it. Nothing measured whether
the Phase 3 performance work (catalog-fetched-once, unbounded disk
cache) actually translated into a faster first paint on real devices
in the field, either.

## What changed

**Crashlytics wired into the existing logging seam.**
`AppLogger.recordError`/`AppLogger.info` (`lib/utils/logger.dart`) now
forward to `FirebaseCrashlytics` once it's available
(`AppLogger.attachCrashlytics()`, called from `main.dart` right after
`Firebase.initializeApp()` succeeds), in addition to still printing to
the debug console. Nothing that calls `AppLogger` had to change - the
whole point of centralizing logging in Phase-1-era code was exactly
this kind of swap. `main.dart`'s `FlutterError.onError` and
`runZonedGuarded` handler now pass `fatal: true`, since those two paths
are the ones that would otherwise have taken down the app.
`AuthNotifier` (`lib/providers/auth_provider.dart`) tags reports with
the signed-in uid via `AppLogger.setUserId` so a crash can be traced
back to an account - and clears it on logout, consistent with this
being a shared-device app (see Phase 3's per-user Hive clearing).

**Performance Monitoring, mostly automatic.** `firebase_performance`
auto-instruments network calls and screen rendering with zero extra
code once `FirebasePerformance.instance.setPerformanceCollectionEnabled`
is called (`main.dart`). `lib/utils/perf_trace.dart` adds one named
custom trace, `catalog_fetch`, around
`FirestoreCourseRepository.getCourses` - the one operation from Phase 3
worth a dashboard number of its own, since it gates how long a student
looks at the catalog skeleton on first launch. Deliberately did not
wrap every provider/repository call in a trace; that would be dashboard
noise, not signal (see `perf_trace.dart`'s doc comment).

**Both default off in debug builds** (`kDebugMode` checks in
`main.dart`), same reasoning as `activateAppCheck`'s debug/release
split in Phase... earlier: local dev churn shouldn't pollute production
crash-free-users and performance percentiles.

**Native Android setup, since this repo doesn't commit `android/`.**
Both packages need `google-services.json` plus their Gradle plugins
applied at the native layer - `flutterfire configure` normally handles
this, but this repo's CI scaffolds `android/` fresh via `flutter
create` on every run (see Phase-1-era comment in
`.github/workflows/build-apk.yml`), so there's nothing for
`flutterfire configure` to have touched. Added a new CI step,
`Configure Crashlytics + Performance Monitoring`, that decodes a
`GOOGLE_SERVICES_JSON` secret (mirrors the existing release-signing
secret pattern) and patches `android/build.gradle` /
`android/app/build.gradle` to apply the three needed plugins. Gated on
the secret being present, same as release signing - without it, this
step is skipped and the app still builds and runs, just without native
crash/perf collection (everything on the Dart side is try/catch-guarded
for exactly this case; see `main.dart`).

## Deliberately out of scope for this phase
- Custom traces beyond `catalog_fetch` (e.g. quiz submission, video
  screen load) - worth adding once there's an actual dashboard someone
  is watching; instrumenting speculatively just adds unread noise (see
  `perf_trace.dart`'s doc comment).
- Crash-free-users alerting/Slack integration - a Crashlytics console
  setting, not a code change; note in this repo for whoever owns the
  Firebase project to configure once real traffic exists.
- iOS native setup (`GoogleService-Info.plist` + equivalent Xcode
  build-phase scripts) - this app currently only ships an Android CI
  pipeline (`build-apk.yml`); revisit if/when an iOS build gets added.
