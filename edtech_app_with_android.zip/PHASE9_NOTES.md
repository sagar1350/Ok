# Phase 9: Progress stream + connectivity-triggered sync

## Problem
Phase 8 added `SyncState`/`SyncProgress` as data shapes but nothing
produced them - `QueueProcessor.processQueue()` had no way to report
"N/M items synced," and nothing kicked off a sync run when the device
came back online (`SyncScheduler`'s 5-minute timer is purely
time-based). This phase closes both gaps with the pasted
`lib/sync/` files.

## What changed

**New `lib/sync/` files** (matches the file tree you pasted):

- `sync_stream.dart` - added as pasted, unchanged. Compiles cleanly
  against the `SyncProgress` that already exists from Phase 8
  (`total`/`completed`/`percent`) - no shape mismatch to fix.
- `sync_controller.dart` - added as pasted, unchanged.
  `updateProgress(total, completed)` builds a `SyncProgress` and
  pushes it to `SyncStream`. Nothing calls this yet on its own - see
  `queue_processor.dart` below for where it actually gets wired in.
- `retry_scheduler.dart` - added as pasted, unchanged, but worth
  being precise about what it does: `retry()` doesn't catch or check
  success/failure of the task - it's a plain "wait 5s, then run once"
  primitive, not a self-retrying loop. See "Worth knowing" below for
  how this differs from `services/retry_policy.dart`, which already
  existed.
- `incremental_sync.dart` - added as pasted, plus one addition: a
  `markSynced([DateTime? at])` method. In the pasted version
  `lastSync` could be read but never written, so `shouldSync()` would
  always return `true` - there was no way to ever record that a sync
  happened. Not called from anywhere yet (see "Deliberately out of
  scope").
- `connectivity_sync.dart` - the pasted version was comments only
  (`// connectivity_plus`, `// Internet Available`, `// Start Sync`)
  with a no-argument `startListening()`, so as written it had no way
  to actually trigger anything. Implemented for real:
  - Uses `Connectivity()` from `connectivity_plus` (already a
    dependency) the same way `providers/connectivity_provider.dart`
    does - checks initial state, then listens to
    `onConnectivityChanged`.
  - **Added a constructor parameter**, `onReconnected: Future<void>
    Function()`, since the class needs *something* to call when the
    device reconnects. Fires only on an offline→online transition
    (not every connectivity event, so a wifi↔cellular handoff while
    already online doesn't re-trigger a sync).
  - On failure, uses `RetryScheduler` for exactly one delayed retry
    of `onReconnected`. If that retry *also* fails, the exception
    isn't caught locally - it propagates to the app's existing
    `runZonedGuarded` handler in `main.dart` and gets logged there,
    same as any other uncaught async error, rather than looping or
    failing silently.
  - Intentionally separate from `connectivityProvider`: that one is a
    Riverpod stream watched/rebuilt by widgets (`OfflineBanner`).
    This one is a plain class meant to be constructed once and left
    running, not tied to a widget's lifecycle.
  - Has a doc-comment example (same pattern as
    `default_sync_handlers.dart` from Phase 5) showing how it'd
    eventually be constructed via a provider once something builds
    `SyncManager` - not actually wired into `repository_providers.dart`
    or `main.dart` (see "Deliberately out of scope").

**`lib/services/queue_processor.dart` (modified):**
Added an optional `onProgress: void Function(int completed, int
total)?` callback, called once per item after its outcome (synced,
retry-pending, or dropped) is decided - so `completed` reaches
`total` by the end of every batch regardless of how individual items
went. This meant removing the early `continue` on the success path
(it would have skipped the new call) in favour of a plain
if/else-if/else, otherwise the loop body is untouched. Optional and
defaults to doing nothing, so nothing that constructs a
`QueueProcessor` today needs to change.

**New `lib/widgets/sync_progress_bar.dart`:**
Wraps the pasted `StreamBuilder<SyncProgress>` snippet as a proper
widget, following `PendingSyncIndicator`'s pattern. One change from
the pasted version: hides not just on `null` but also once
`completed >= total`, so the bar doesn't sit stuck at 100% between
sync runs (the stream never emits an explicit "idle" value to reset
it otherwise). Not yet placed on any screen - drop it next to
`PendingSyncIndicator` wherever that already lives.

## Architecture diagram reconciliation
The diagram you pasted (User Action → Local Database → Queue Manager
→ **Sync Controller → Progress Stream** → Queue Processor → API
Service → Server) differs slightly from Phase 8's (... → Queue
Processor → **Sync Service** → API Service → ...). Read literally,
the new diagram would mean Sync Controller runs *before* Queue
Processor - but Sync Controller has nothing to control at that point
(no items have been attempted yet), and nothing pasted actually calls
it that way. What's implemented instead: `SyncController`/
`SyncStream` are a progress side-channel that `QueueProcessor` reports
into *during* `processQueue()`, not a sequential stage before it. The
real call order is unchanged from Phase 8: `SyncScheduler` →
`SyncService.startSync()` → `QueueProcessor.processQueue()` (now also
emitting progress as it goes) → `syncCallback` → API Service → Server.

## Deliberately out of scope for this phase
- Nobody constructs `ConnectivitySync` or wires its `onReconnected`
  to a real `SyncManager`/`SyncService` yet - same open item Phase 7
  and 8 both flagged for their own pieces (no `queueProcessorProvider`
  /`syncManagerProvider` in `repository_providers.dart`, nothing in
  `main.dart`). Assembling and starting the full object graph is
  still one open step.
- `IncrementalSync` isn't called from anywhere. It's built for a
  *pull* direction (only fetch things updated since `lastSync`), but
  everything else in `lib/sync`/`lib/services` is about *pushing*
  queued local changes - there's no download-updated-content code
  path yet for it to plug into.
- `SyncProgressBar` isn't placed on any screen.

## Worth knowing before wiring it up
- **Two retry mechanisms now exist and do different jobs** -
  `RetryPolicy` (Phase 5, exponential 2/4/8/16s) decides whether/when
  an *individual queue item* gets another attempt across future
  `processQueue()` calls. `RetryScheduler` (this phase) gives a whole
  *sync attempt* exactly one 5-second-later second chance if it fails
  to even start. They're not redundant, but they sit close enough in
  purpose that it's worth a comment at each call site (added) so a
  future reader doesn't assume one replaced the other.
- **`_isOnline` is now duplicated** between `connectivity_provider.dart`
  (private to that file, so not reusable as-is) and the new
  `connectivity_sync.dart`. Small enough that duplicating it seemed
  better than making that helper public just for this - flagging in
  case you'd rather share one implementation.
- `QueueProcessor`'s `onProgress` reports *items processed*, not
  *items successfully synced* - a batch with every item failing but
  retryable still reports `completed` climbing to `total`. That's the
  intended meaning (it's a "how far through this batch are we"
  indicator, not a success rate), but worth knowing if a screen
  displaying `SyncProgressBar` might be read as the latter.
