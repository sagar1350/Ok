/**
 * One-off script to load firestore/seed_data.json into a real Firestore
 * project - lets you see the app fully populated instead of empty
 * lists on a fresh Firebase project.
 *
 * Setup:
 *   1. In the Firebase console: Project settings > Service accounts >
 *      Generate new private key. Save it as firestore/service-account.json
 *      (already gitignored - never commit this file).
 *   2. npm install firebase-admin
 *   3. node firestore/seed.js
 */
const admin = require('firebase-admin');
const seedData = require('./seed_data.json');

admin.initializeApp({
  credential: admin.credential.cert(require('./service-account.json')),
});

const db = admin.firestore();

async function seedCollection(collectionName, docs) {
  const batch = db.batch();
  for (const [docId, data] of Object.entries(docs)) {
    batch.set(db.collection(collectionName).doc(docId), data);
  }
  await batch.commit();
  console.log(`Seeded ${Object.keys(docs).length} doc(s) into "${collectionName}"`);
}

async function main() {
  await seedCollection('courses', seedData.courses);
  await seedCollection('quizzes', seedData.quizzes);
  console.log('Done.');
  process.exit(0);
}

main().catch((err) => {
  console.error('Seeding failed:', err);
  process.exit(1);
});
