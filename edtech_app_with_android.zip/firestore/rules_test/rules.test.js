/**
 * Runs firestore.rules against the Firestore emulator to prove the
 * ownership + validation logic actually behaves as intended, instead
 * of trusting the rules file by inspection alone.
 *
 * Setup:
 *   1. npm install --prefix firestore/rules_test
 *   2. In one terminal, from the repo root: firebase emulators:start --only firestore
 *   3. In another: npm test --prefix firestore/rules_test
 *
 * (CI can run both in one job - see the "Firestore rules" section of
 * README.md for the single-command version used there.)
 */
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} = require('@firebase/rules-unit-testing');
const fs = require('fs');
const path = require('path');

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: 'edtech-app-rules-test',
    firestore: {
      rules: fs.readFileSync(
        path.resolve(__dirname, '../../firestore.rules'),
        'utf8'
      ),
    },
  });
});

after(async () => {
  await testEnv.cleanup();
});

afterEach(async () => {
  await testEnv.clearFirestore();
});

describe('courses / quizzes (catalog)', () => {
  it('lets a signed-in user read a course', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection('courses').doc('c1').set({ title: 'x' });
    });
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(alice.firestore().collection('courses').doc('c1').get());
  });

  it('blocks an unauthenticated read', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection('courses').doc('c1').set({ title: 'x' });
    });
    const anon = testEnv.unauthenticatedContext();
    await assertFails(anon.firestore().collection('courses').doc('c1').get());
  });

  it('blocks a client from writing a course', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice.firestore().collection('courses').doc('c1').set({ title: 'hacked' })
    );
  });
});

describe('users/{uid} profile', () => {
  const validProfile = {
    phoneNumber: '9876543210',
    name: null,
    role: 'student',
    createdAt: '2026-01-01T00:00:00.000Z',
  };

  it('lets a user create their own profile with a valid shape', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice.firestore().collection('users').doc('alice').set(validProfile)
    );
  });

  it('rejects an extra/unexpected field', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .set({ ...validProfile, isAdmin: true })
    );
  });

  it('rejects a role outside the known enum', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .set({ ...validProfile, role: 'superadmin' })
    );
  });

  it('rejects self-assigning the admin role, at create time', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .set({ ...validProfile, role: 'admin' })
    );
  });

  it('rejects self-assigning the admin role via a later update', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context
        .firestore()
        .collection('users')
        .doc('alice')
        .set(validProfile);
    });
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .update({ role: 'admin' })
    );
  });

  it("blocks writing to someone else's profile", async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice.firestore().collection('users').doc('bob').set(validProfile)
    );
  });

  it('lets a user change only their own role afterwards', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice.firestore().collection('users').doc('alice').set(validProfile)
    );
    await assertSucceeds(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .update({ role: 'teacher' })
    );
  });

  it('blocks changing phoneNumber via the role-update path', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice.firestore().collection('users').doc('alice').set(validProfile)
    );
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .update({ role: 'teacher', phoneNumber: '0000000000' })
    );
  });
});

describe('users/{uid}/enrollments', () => {
  const validEnrollment = {
    courseTitle: 'Flutter Complete Course',
    iconKey: 'code',
    colorKey: 'deepPurple',
    lastLessonLabel: 'Lesson 2',
    progressPercent: 0.4,
    lastAccessedAt: '2026-01-01T00:00:00.000Z',
  };

  it('accepts a valid progress write for the owner', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('enrollments')
        .doc('course_flutter')
        .set(validEnrollment)
    );
  });

  it('rejects progressPercent above 1', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('enrollments')
        .doc('course_flutter')
        .set({ ...validEnrollment, progressPercent: 1.5 })
    );
  });

  it("blocks reading someone else's enrollments", async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('enrollments')
        .doc('course_flutter')
        .set(validEnrollment)
    );
    const bob = testEnv.authenticatedContext('bob');
    await assertFails(
      bob
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('enrollments')
        .doc('course_flutter')
        .get()
    );
  });
});

describe('users/{uid}/quizAttempts', () => {
  const validAttempt = {
    quizId: 'daily',
    score: 3,
    total: 5,
    submittedAt: '2026-01-01T00:00:00.000Z',
  };

  it('accepts a valid attempt', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertSucceeds(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('quizAttempts')
        .add(validAttempt)
    );
  });

  it('rejects a score greater than total (forged/cheated result)', async () => {
    const alice = testEnv.authenticatedContext('alice');
    await assertFails(
      alice
        .firestore()
        .collection('users')
        .doc('alice')
        .collection('quizAttempts')
        .add({ ...validAttempt, score: 99 })
    );
  });

  it('cannot be edited once written (append-only log)', async () => {
    const alice = testEnv.authenticatedContext('alice');
    const ref = alice
      .firestore()
      .collection('users')
      .doc('alice')
      .collection('quizAttempts')
      .doc('attempt1');
    await assertSucceeds(ref.set(validAttempt));
    await assertFails(ref.update({ score: 5 }));
  });
});
