# Firestore schema

This is the schema the repositories in `lib/repositories/impl/` read and
write. Nothing in the app hardcodes this data anymore (see
`PHASE1_NOTES.md`) - if you add a field here, add it to the matching
model's `fromMap`/`toMap` too.

## `courses/{courseId}`
Read by `CourseRepository.getCourses/getCourseById/getRecommended`.

| Field            | Type                  | Notes                                   |
|-------------------|-----------------------|------------------------------------------|
| title             | string                |                                          |
| subject           | string                | e.g. `Mathematics`, `Coding`             |
| level             | string                | `Beginner` \| `Intermediate` \| `Advanced` |
| description       | string                |                                          |
| iconKey           | string                | one of `code, calculate, biotech, language, history, computer` - see `lib/utils/course_visuals.dart` |
| colorKey          | string                | one of `deepPurple, teal, orange, pink, blue, indigo` |
| lessonsCount      | number                |                                          |
| durationHours      | number                |                                          |
| rating            | number                |                                          |
| studentsCount     | number                | drives the "Recommended" ranking today  |
| priceInr          | number                | `0` = free                              |
| whatYoullLearn    | array\<string\>       |                                          |
| curriculum        | array\<object\>       | `{ title, lessons: [{ title, durationLabel, videoUrl, locked }] }` |

## `quizzes/{quizId}`
Read by `QuizRepository.getQuiz`. The dashboard's "Daily Quiz" action
always loads the doc with id `daily`.

| Field      | Type            | Notes |
|------------|------------------|-------|
| title      | string           |       |
| questions  | array\<object\>  | `{ question, options: [string], correctIndex }` |

## `users/{uid}`
Created automatically on first sign-in (`AuthNotifier._checkExistingUser`
→ `UserRepository.createProfileIfMissing`). `role` is updated by
`RoleSelectionScreen`.

| Field        | Type   | Notes                              |
|--------------|--------|-------------------------------------|
| phoneNumber  | string |                                      |
| name         | string | optional, not yet collected in UI  |
| role         | string | `student` \| `teacher` \| `parent` |
| createdAt    | string | ISO 8601                            |

## `users/{uid}/enrollments/{courseId}`
Written by `CourseRepository.recordLessonProgress` whenever a lesson is
opened (`VideoPlayerScreen`). Read by `getContinueLearning` for the
dashboard's "Continue Learning" row.

| Field             | Type   | Notes                     |
|--------------------|--------|----------------------------|
| courseTitle        | string |                            |
| iconKey            | string |                            |
| colorKey           | string |                            |
| lastLessonLabel    | string |                            |
| progressPercent    | number | `0.0` - `1.0`              |
| lastAccessedAt     | string | ISO 8601, used to sort     |

## `users/{uid}/quizAttempts/{attemptId}`
Written by `QuizRepository.submitResult` when a quiz finishes. Not read
back anywhere yet - a natural next feature (quiz history/analytics).

| Field        | Type   |
|--------------|--------|
| quizId       | string |
| score        | number |
| total        | number |
| submittedAt  | string |

## `users/{uid}/orders/{razorpayOrderId}`
Written only by `functions/index.js` (`createOrder`, then updated by
`verifyPayment`/`razorpayWebhook`). Never written by the client -
`firestore.rules` denies client writes to this whole subcollection.
Doc id is the Razorpay order id.

| Field             | Type   | Notes                                      |
|--------------------|--------|---------------------------------------------|
| razorpayOrderId    | string | same as the doc id (kept as a field for the webhook's `collectionGroup` lookup) |
| uid                | string |                                              |
| type               | string | `course` \| `subscription`                  |
| courseId           | string \| null |                                      |
| plan               | string \| null | `monthly` \| `yearly`               |
| amountInr          | number |                                              |
| status             | string | `created` \| `paid`                         |
| razorpayPaymentId  | string | set once paid                               |
| createdAt          | timestamp |                                           |
| paidAt             | timestamp | set once paid                            |

## `users/{uid}/purchases/{courseId}`
Written only by `functions/index.js` (`fulfillOrder`, called from
`verifyPayment`/`razorpayWebhook`) after the Razorpay payment
signature is verified server-side. Its existence is the entitlement -
`hasCourseAccessProvider` (Flutter) checks for this doc, not a field
on the course.

| Field              | Type   |
|---------------------|--------|
| courseTitle         | string |
| amountInr           | number |
| razorpayOrderId     | string |
| razorpayPaymentId   | string |
| purchasedAt         | string, ISO 8601 |

## `users/{uid}/subscription/current`
Single doc (id is always `current`), same write path as `purchases/`
above. An active doc here unlocks every paid course, independent of
individual `purchases/` docs.

| Field       | Type   | Notes                              |
|-------------|--------|--------------------------------------|
| plan        | string | `monthly` \| `yearly`                |
| status      | string | `active` \| `expired` \| `cancelled` |
| startedAt   | string | ISO 8601                             |
| expiresAt   | string | ISO 8601 - `SubscriptionStatus.isActive` checks this against the device clock |
