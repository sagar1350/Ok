# Phase 16: Razorpay payments (course purchases + subscriptions)

`CourseDetailScreen`'s "Enroll Now" button was a stub ("wire to a
payments provider once a payment gateway is chosen" - Phase 1). This
phase wires it up: per-course one-time purchases using the existing
`priceInr` field, plus monthly/yearly subscriptions that unlock every
paid course at once.

## Why the money logic lives entirely server-side

Same principle as `setAdminRole` in Phase 14: the client is never
trusted with anything that grants access. Concretely:

- **The price is decided server-side.** `createOrder` (Cloud
  Function) reads `courses/{courseId}.priceInr` itself for a course
  purchase, and uses a hardcoded `SUBSCRIPTION_PLANS` map for
  subscriptions - it never charges whatever amount the client sends.
- **"Payment succeeded" from the Razorpay SDK alone unlocks nothing.**
  `PaymentController` calls `verifyPayment` after checkout, which
  re-derives the HMAC signature from `(order_id, payment_id)` using
  `RAZORPAY_KEY_SECRET` and only *then* writes the
  `purchases/{courseId}` or `subscription/current` doc.
- **The client can't write those docs directly.** `firestore.rules`
  denies all client writes to `users/{uid}/purchases/**`,
  `users/{uid}/subscription/**`, and `users/{uid}/orders/**` - the
  Admin SDK inside `functions/index.js` is the only writer, exactly
  like the `admin` custom claim.
- **A webhook is the backup, not the primary path.**
  `razorpayWebhook` (subscribed to Razorpay's `payment.captured`
  event) calls the same `fulfillOrder` helper as `verifyPayment`, so a
  payment that succeeds but never makes it back to the app (closed
  mid-checkout, dropped connection right after paying) still gets
  fulfilled. `fulfillOrder` checks `order.status === 'paid'` first, so
  running both paths for the same order is harmless.

## What changed

- **`functions/index.js`** - three new exports: `createOrder`,
  `verifyPayment` (both `onCall`), `razorpayWebhook` (`onRequest`),
  plus the shared `fulfillOrder` helper. Three new secrets
  (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`,
  `RAZORPAY_WEBHOOK_SECRET`) via `firebase-functions/params` - see
  README "Configure Razorpay". `functions/package.json` gained the
  `razorpay` npm package.
- **`firestore.rules`** - `users/{uid}/{purchases,subscription,orders}`
  added: owner-readable, `allow write: if false` on all three.
- **`firestore/schema.md`** - documents the three new subcollections.
- **`lib/models/course_purchase.dart`**, **`subscription_status.dart`**
  (new) - plain models, no Firebase deps, matching `Course`'s style.
  `SubscriptionPlan` is an enum with the display price/duration mirrored
  from `functions/index.js`'s `SUBSCRIPTION_PLANS` (display only - the
  charge is decided server-side, see above).
- **`lib/repositories/payment_repository.dart`** (new interface) +
  **`impl/firebase_payment_repository.dart`** - same
  interface/implementation split as every other repository in this
  app. Wraps the two callables and streams the three entitlement
  collections. Bound in `repository_providers.dart` as
  `paymentRepositoryProvider`.
- **`lib/services/razorpay_checkout_service.dart`** (new) - wraps
  `razorpay_flutter`'s callback-based `Razorpay` object in a `Future`
  so `PaymentController` can `await` a checkout attempt.
- **`lib/providers/payment_providers.dart`** (new) -
  `purchasedCourseIdsProvider`, `subscriptionStatusProvider`, and
  `hasCourseAccessProvider(course)` (the one thing screens actually
  need: free course OR active subscription OR that course purchased).
- **`lib/providers/payment_controller.dart`** (new) - orchestrates
  create-order → open checkout → verify-payment for both a course
  purchase and a subscription; exposes `AsyncValue<void>` purely for
  the buy button's own spinner/error snackbar, never as an access
  check.
- **`lib/screens/course_detail_screen.dart`** - "Enroll Now" replaced
  by `_EnrollButton` (Enrolled / Buy Now with a spinner while a
  purchase is in flight). Each lesson's play/lock state now factors in
  `hasCourseAccessProvider`: a lesson authored `locked: false` is
  still always a free preview; `locked: true` unlocks once the
  learner has access.
- **`lib/screens/subscription_plans_screen.dart`** (new), reachable
  from Settings → *Subscription*, at route `/subscription-plans`.
- **`pubspec.yaml`** - added `razorpay_flutter`.

## Not done here

- **Cancellation/refunds** - Razorpay dashboard only for now; no
  in-app cancel flow or `subscription.status = 'cancelled'` writer.
- **Renewal reminders / auto-renew** - each subscription purchase is a
  one-time order for a fixed period (30/365 days), not a recurring
  Razorpay Subscription - a student re-buys when `expiresAt` passes.
  Wiring actual Razorpay Subscriptions (with `subscription.charged`
  webhook events) would be the natural next step if auto-renew turns
  out to matter.
- **GST/invoicing** - no invoice generation; Razorpay's own dashboard
  is the source of truth for that today.
