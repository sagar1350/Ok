# Phase 6: Queue manager, retry policy, queue processor

## What was added
- `lib/services/queue_constants.dart` - `maxRetry` (5), `batchSize` (20).
- `lib/services/retry_policy.dart` - `canRetry(retryCount)` and
  exponential `nextDelay(retryCount)` (2s, 4s, 8s, 16s...).
- `lib/services/queue_manager.dart` - thin wrapper over
  `LocalDatabase.syncBox`: `add` (id-deduped), `pending()`, `remove`,
  `markSynced`, `markFailed`.
- `lib/services/queue_processor.dart` - **not included in what was
  pasted**, so this one is mine, written to match the other three
  files' conventions and to actually drain the queue against real
  repositories (`QuizRepository.submitResult`, `UserRepository.setRole`).

## A bug worth knowing about before this ships
`QueueManager.pending()` only returns items with `status == "pending"`.
`QueueManager.markFailed()` sets `status = "failed"` on *any* failure.
Put together: the first time `markFailed` is called on an item, it
permanently drops out of `pending()` - it can never be picked up again,
no matter what `RetryPolicy.canRetry` says. `RetryPolicy` becomes dead
code in practice.

`QueueProcessor` works around this rather than calling `markFailed` on
every failure: while `RetryPolicy.canRetry(item.retryCount)` is true, it
increments `item.retryCount` directly and leaves `status` as `"pending"`
so the item stays eligible; `markFailed` (the terminal, excluded-forever
state) is only called once retries are exhausted. If you'd rather fix
this in `QueueManager` itself (e.g. a `markRetrying()` method that bumps
`retryCount` but keeps `status: "pending"`), that's probably the cleaner
long-term home for this logic instead of `QueueProcessor` reaching into
`item.retryCount`/`item.save()` directly - flagging it rather than
changing `queue_manager.dart` since it wasn't clear that file should
change.

## Other rough edges, left as-is / noted rather than silently fixed
- `SyncStatus` (the enum from Phase 5) is unused - both `QueueManager`
  and `QueueProcessor` compare/set status via raw strings
  (`"pending"`, `"synced"`, `"failed"`). Worth switching to
  `SyncStatus.pending.name` etc. for compile-time safety.
- `RetryPolicy.canRetry` hardcodes `5` instead of referencing
  `QueueConstants.maxRetry` - two sources of truth for the same number.
- Backoff timing is approximate: `SyncItem` only stores `createdAt`,
  not a "last attempt" timestamp, so `QueueProcessor` compares
  `nextDelay` against time-since-creation rather than
  time-since-last-attempt. Add a `lastAttemptAt` field to `SyncItem` if
  exact backoff intervals matter.

## Deliberately out of scope for this phase
- `QueueProcessor` isn't wired to `connectivityProvider` or exposed via
  a Riverpod provider yet - nothing currently calls
  `processPending()` automatically when the device comes back online.
- `bookmark`, `notes`, `download` sync types throw
  `UnimplementedError` in `QueueProcessor._dispatch` - there's no
  backend repository method for any of them yet (bookmark/notes have UI
  but no Firestore-backed repo; download is local-only via
  `offline_lesson_store`).
- Nothing yet calls `QueueManager.add()` from the screens/providers that
  perform these actions (quiz submission, profile edits) when offline.
