/**
 * Run this ONCE, by hand, from a trusted machine, to create the very
 * first admin. After that, every further grant/revoke should go
 * through the setAdminRole callable function instead (which requires
 * the caller to already be an admin) - this script is the deliberate
 * exception, because nothing can satisfy "must already be admin"
 * before an admin exists.
 *
 * This is NOT a Cloud Function and is never deployed - it talks to
 * Firebase directly using a service account key, the same way any
 * trusted backend script would.
 *
 * Setup:
 *   1. Firebase Console -> Project Settings -> Service Accounts ->
 *      "Generate new private key". Save the JSON somewhere outside
 *      the repo (never commit it).
 *   2. GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json \
 *        node scripts/bootstrapFirstAdmin.js <uid>
 *
 * <uid> is the Firebase Auth uid of the account to promote - e.g. the
 * developer's own account after signing in once through the app's
 * normal OTP flow, so a real Firestore profile doc already exists.
 */
const admin = require("firebase-admin");

const uid = process.argv[2];
if (!uid) {
  console.error("Usage: node scripts/bootstrapFirstAdmin.js <uid>");
  process.exit(1);
}

admin.initializeApp();

async function main() {
  const user = await admin.auth().getUser(uid).catch(() => null);
  if (!user) {
    throw new Error(`No Firebase Auth user with uid "${uid}". Sign in ` +
      "through the app first so the account exists.");
  }

  await admin.auth().setCustomUserClaims(uid, {
    ...user.customClaims,
    admin: true,
  });

  const profileRef = admin.firestore().collection("users").doc(uid);
  if ((await profileRef.get()).exists) {
    await profileRef.update({ role: "admin" });
  }

  console.log(`Granted admin to ${uid}. They'll need to sign out and back ` +
    "in (or wait up to an hour) for the app to pick up the new claim - " +
    "or just re-tap Admin on the role screen, which force-refreshes it.");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
