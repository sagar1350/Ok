const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { logger } = require("firebase-functions");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");
const Razorpay = require("razorpay");

admin.initializeApp();

// Set with: firebase functions:secrets:set RAZORPAY_KEY_ID (etc).
// Never hardcoded, never sent to the client except KEY_ID (public by
// design - it's what Razorpay's checkout.js needs to open the sheet;
// KEY_SECRET and WEBHOOK_SECRET never leave the server).
const RAZORPAY_KEY_ID = defineSecret("RAZORPAY_KEY_ID");
const RAZORPAY_KEY_SECRET = defineSecret("RAZORPAY_KEY_SECRET");
const RAZORPAY_WEBHOOK_SECRET = defineSecret("RAZORPAY_WEBHOOK_SECRET");

// Subscription prices live here, not on the client - createOrder is
// the only place a rupee amount is decided. lib/models/
// subscription_status.dart mirrors these values for display only.
const SUBSCRIPTION_PLANS = {
  monthly: { priceInr: 199, durationDays: 30 },
  yearly: { priceInr: 1499, durationDays: 365 },
};

/**
 * setAdminRole - grants or revokes the `admin` custom claim on another
 * user's account.
 *
 * This is the ONLY code path in the whole system that may set that
 * claim. The Flutter client never can:
 *  - firestore.rules rejects any client write of role: 'admin' on a
 *    user profile doc (see the isSelfServiceRole comment there).
 *  - lib/repositories/impl/firebase_auth_repository.dart's isAdmin()
 *    only ever *reads* the claim off the ID token.
 *
 * Callable only by an already-admin caller (context.auth.token.admin
 * === true), which is itself only ever set by this function or by the
 * one-time scripts/bootstrapFirstAdmin.js run out-of-band by a
 * developer with direct service-account access. That bootstrap script
 * is what creates the very first admin, since obviously no caller can
 * satisfy "must already be admin" before one exists.
 *
 * data: { uid: string, makeAdmin: boolean }
 */
exports.setAdminRole = onCall(async (request) => {
  const callerClaims = request.auth?.token;
  if (!callerClaims) {
    throw new HttpsError("unauthenticated", "Sign in required.");
  }
  if (callerClaims.admin !== true) {
    throw new HttpsError(
      "permission-denied",
      "Only an existing admin can grant or revoke admin access."
    );
  }

  const { uid, makeAdmin } = request.data || {};
  if (typeof uid !== "string" || uid.length === 0) {
    throw new HttpsError("invalid-argument", "uid is required.");
  }
  if (typeof makeAdmin !== "boolean") {
    throw new HttpsError("invalid-argument", "makeAdmin must be a boolean.");
  }

  // Don't let an admin revoke their own access via this call - a
  // mis-click here shouldn't be able to lock every admin out. A
  // second admin (or the bootstrap script, in a true break-glass
  // situation) has to be the one to remove someone.
  if (uid === request.auth.uid && makeAdmin === false) {
    throw new HttpsError(
      "failed-precondition",
      "Ask another admin to revoke your own access."
    );
  }

  const targetUser = await admin.auth().getUser(uid).catch(() => null);
  if (!targetUser) {
    throw new HttpsError("not-found", "No user with that uid.");
  }

  await admin.auth().setCustomUserClaims(uid, {
    ...targetUser.customClaims,
    admin: makeAdmin,
  });

  // Keep the Firestore profile's `role` field (a display label only -
  // see firestore.rules) in sync, using the Admin SDK so it bypasses
  // the client rules that otherwise block writing role: 'admin'.
  const profileRef = admin.firestore().collection("users").doc(uid);
  const profileSnap = await profileRef.get();
  if (profileSnap.exists) {
    await profileRef.update({
      role: makeAdmin ? "admin" : "student",
    });
  }

  await admin.firestore().collection("adminAuditLog").add({
    action: makeAdmin ? "grant" : "revoke",
    targetUid: uid,
    performedBy: request.auth.uid,
    at: admin.firestore.FieldValue.serverTimestamp(),
  });

  logger.info(
    `${request.auth.uid} ${makeAdmin ? "granted" : "revoked"} admin for ${uid}`
  );

  return { uid, admin: makeAdmin };
});

/**
 * createOrder - creates a Razorpay order for either a one-time course
 * purchase or a subscription plan, and records it at
 * `users/{uid}/orders/{razorpayOrderId}` with status "created".
 *
 * The amount charged is decided entirely here (course price read from
 * Firestore, subscription price from SUBSCRIPTION_PLANS above) - the
 * client only ever tells us *what* it wants to buy, never *how much*
 * it costs, so a tampered client can't get a discount.
 *
 * data: { type: 'course', courseId: string }
 *     | { type: 'subscription', plan: 'monthly' | 'yearly' }
 */
exports.createOrder = onCall(
  { secrets: [RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET] },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Sign in required.");
    }
    const uid = request.auth.uid;
    const { type } = request.data || {};

    const razorpay = new Razorpay({
      key_id: RAZORPAY_KEY_ID.value(),
      key_secret: RAZORPAY_KEY_SECRET.value(),
    });

    let amountInr;
    let description;
    let notes;

    if (type === "course") {
      const courseId = request.data?.courseId;
      if (typeof courseId !== "string" || courseId.length === 0) {
        throw new HttpsError("invalid-argument", "courseId is required.");
      }
      const courseSnap = await admin
        .firestore()
        .collection("courses")
        .doc(courseId)
        .get();
      if (!courseSnap.exists) {
        throw new HttpsError("not-found", "Course not found.");
      }
      const course = courseSnap.data();
      const priceInr = Number(course.priceInr) || 0;
      if (priceInr <= 0) {
        throw new HttpsError("failed-precondition", "This course is free.");
      }

      const existingPurchase = await admin
        .firestore()
        .collection("users")
        .doc(uid)
        .collection("purchases")
        .doc(courseId)
        .get();
      if (existingPurchase.exists) {
        throw new HttpsError("already-exists", "You already own this course.");
      }

      amountInr = priceInr;
      description = `Course: ${course.title || courseId}`;
      notes = { uid, type, courseId };
    } else if (type === "subscription") {
      const plan = request.data?.plan;
      const hardcodedConfig = SUBSCRIPTION_PLANS[plan];
      if (!hardcodedConfig) {
        throw new HttpsError(
          "invalid-argument",
          "plan must be 'monthly' or 'yearly'."
        );
      }
      // Prefer the admin-managed price from Firestore
      // (subscriptionPlans/{plan}, edited from the Payments module) -
      // falls back to the hardcoded default above if no admin has
      // configured one yet, so this never breaks on a fresh project.
      const planDoc = await admin
        .firestore()
        .collection("subscriptionPlans")
        .doc(plan)
        .get();
      const planData = planDoc.exists ? planDoc.data() : null;
      if (planData && planData.isActive === false) {
        throw new HttpsError(
          "failed-precondition",
          "This plan is not currently available."
        );
      }
      amountInr = Number(planData?.priceInr) || hardcodedConfig.priceInr;
      description = `${plan[0].toUpperCase()}${plan.slice(1)} subscription`;
      notes = { uid, type, plan };
    } else {
      throw new HttpsError(
        "invalid-argument",
        "type must be 'course' or 'subscription'."
      );
    }

    const amountInPaise = amountInr * 100;
    const order = await razorpay.orders.create({
      amount: amountInPaise,
      currency: "INR",
      receipt: `${type}_${uid}_${Date.now()}`,
      notes,
    });

    await admin
      .firestore()
      .collection("users")
      .doc(uid)
      .collection("orders")
      .doc(order.id)
      .set({
        razorpayOrderId: order.id,
        uid,
        type,
        courseId: type === "course" ? notes.courseId : null,
        plan: type === "subscription" ? notes.plan : null,
        amountInr,
        status: "created",
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    return {
      razorpayOrderId: order.id,
      razorpayKeyId: RAZORPAY_KEY_ID.value(),
      amountInPaise,
      currency: "INR",
      description,
    };
  }
);

/**
 * verifyPayment - confirms a Razorpay checkout result actually came
 * from Razorpay (HMAC signature check) and, only if valid, fulfills
 * the order: writes the `purchases/{courseId}` or
 * `subscription/current` doc that the client's access checks
 * (hasCourseAccessProvider) actually read.
 *
 * This is the ONLY code path that ever writes those two docs -
 * firestore.rules blocks client writes to both, the same pattern as
 * setAdminRole/the `admin` claim above. A "payment success" callback
 * from the Razorpay SDK alone never unlocks anything; this function
 * re-deriving and checking the signature server-side is what does.
 * Idempotent: calling it twice for an already-fulfilled order is a
 * no-op, so a flaky network retry can't double-charge/double-grant.
 *
 * data: { razorpay_order_id, razorpay_payment_id, razorpay_signature }
 */
exports.verifyPayment = onCall(
  { secrets: [RAZORPAY_KEY_SECRET] },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Sign in required.");
    }
    const uid = request.auth.uid;
    const {
      razorpay_order_id: orderId,
      razorpay_payment_id: paymentId,
      razorpay_signature: signature,
    } = request.data || {};

    if (!orderId || !paymentId || !signature) {
      throw new HttpsError(
        "invalid-argument",
        "razorpay_order_id, razorpay_payment_id and razorpay_signature are required."
      );
    }

    const expectedSignature = crypto
      .createHmac("sha256", RAZORPAY_KEY_SECRET.value())
      .update(`${orderId}|${paymentId}`)
      .digest("hex");
    if (expectedSignature !== signature) {
      throw new HttpsError("permission-denied", "Invalid payment signature.");
    }

    const orderRef = admin
      .firestore()
      .collection("users")
      .doc(uid)
      .collection("orders")
      .doc(orderId);
    const orderSnap = await orderRef.get();
    if (!orderSnap.exists) {
      throw new HttpsError("not-found", "No matching order for this user.");
    }

    await fulfillOrder(orderRef, orderSnap.data(), paymentId);
    return { success: true };
  }
);

/**
 * razorpayWebhook - server-to-server backup for verifyPayment. Covers
 * the case where a payment succeeds but the app never gets to call
 * verifyPayment itself (closed mid-checkout, network drop right
 * after payment). Configure this URL + a webhook secret in the
 * Razorpay dashboard, subscribed to the `payment.captured` event.
 *
 * Verifies the `X-Razorpay-Signature` header against the raw request
 * body using RAZORPAY_WEBHOOK_SECRET (a separate secret from the API
 * key pair) before trusting anything in the payload. fulfillOrder is
 * idempotent, so this safely no-ops if verifyPayment already ran for
 * the same order.
 */
exports.razorpayWebhook = onRequest(
  { secrets: [RAZORPAY_WEBHOOK_SECRET] },
  async (req, res) => {
    const signature = req.headers["x-razorpay-signature"];
    if (!signature || !req.rawBody) {
      res.status(400).send("Missing signature.");
      return;
    }

    const expectedSignature = crypto
      .createHmac("sha256", RAZORPAY_WEBHOOK_SECRET.value())
      .update(req.rawBody)
      .digest("hex");
    if (expectedSignature !== signature) {
      logger.warn("razorpayWebhook: signature mismatch");
      res.status(400).send("Invalid signature.");
      return;
    }

    const event = req.body?.event;
    if (event !== "payment.captured") {
      // Other event types (payment.failed, refund.*, ...) aren't
      // acted on yet - ack so Razorpay doesn't keep retrying.
      res.status(200).send("Ignored.");
      return;
    }

    const payment = req.body.payload?.payment?.entity;
    const orderId = payment?.order_id;
    const paymentId = payment?.id;
    if (!orderId || !paymentId) {
      res.status(400).send("Malformed payload.");
      return;
    }

    const matches = await admin
      .firestore()
      .collectionGroup("orders")
      .where("razorpayOrderId", "==", orderId)
      .limit(1)
      .get();
    if (matches.empty) {
      logger.warn(`razorpayWebhook: no order found for ${orderId}`);
      res.status(200).send("No matching order.");
      return;
    }

    const orderRef = matches.docs[0].ref;
    await fulfillOrder(orderRef, matches.docs[0].data(), paymentId);
    res.status(200).send("OK");
  }
);

/**
 * Shared by verifyPayment and razorpayWebhook: marks the order paid
 * and writes the purchase/subscription doc it corresponds to.
 * Re-entrant - if `order.status` is already "paid" this is a no-op,
 * so it's safe to call from both a client-triggered verify and a
 * later webhook delivery for the same payment.
 */
async function fulfillOrder(orderRef, order, paymentId) {
  if (!order || order.status === "paid") {
    return;
  }

  const uid = order.uid;
  const nowIso = new Date().toISOString();
  const db = admin.firestore();

  if (order.type === "course") {
    const courseSnap = await db.collection("courses").doc(order.courseId).get();
    const courseTitle = courseSnap.exists
      ? courseSnap.data().title || order.courseId
      : order.courseId;
    await db
      .collection("users")
      .doc(uid)
      .collection("purchases")
      .doc(order.courseId)
      .set({
        courseTitle,
        amountInr: order.amountInr,
        razorpayOrderId: order.razorpayOrderId,
        razorpayPaymentId: paymentId,
        purchasedAt: nowIso,
      });
  } else if (order.type === "subscription") {
    const hardcodedConfig = SUBSCRIPTION_PLANS[order.plan];
    const planDoc = await db
      .collection("subscriptionPlans")
      .doc(order.plan)
      .get();
    const durationDays =
      Number(planDoc.data()?.durationDays) || hardcodedConfig?.durationDays || 30;
    const expiresAt = new Date(
      Date.now() + durationDays * 24 * 60 * 60 * 1000
    ).toISOString();
    await db.collection("users").doc(uid).collection("subscription").doc("current").set({
      plan: order.plan,
      status: "active",
      startedAt: nowIso,
      expiresAt,
    });
  }

  await orderRef.update({
    status: "paid",
    razorpayPaymentId: paymentId,
    paidAt: admin.firestore.FieldValue.serverTimestamp(),
  });
}

/**
 * refundOrder - admin-only. Refunds a paid order via the Razorpay
 * Refunds API and revokes whatever it granted (course purchase doc,
 * or subscription access). The only path that can ever move an order
 * to "refunded" - same "server owns the write" pattern as
 * fulfillOrder/setAdminRole above; firestore.rules still blocks a
 * client from writing users/*\/orders or purchases/subscription
 * directly.
 *
 * data: { uid: string, orderId: string }
 */
exports.refundOrder = onCall(
  { secrets: [RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET] },
  async (request) => {
    if (request.auth?.token?.admin !== true) {
      throw new HttpsError(
        "permission-denied",
        "Only an admin can issue refunds."
      );
    }
    const { uid, orderId } = request.data || {};
    if (typeof uid !== "string" || typeof orderId !== "string") {
      throw new HttpsError("invalid-argument", "uid and orderId are required.");
    }

    const db = admin.firestore();
    const orderRef = db.collection("users").doc(uid).collection("orders").doc(orderId);
    const orderSnap = await orderRef.get();
    if (!orderSnap.exists) {
      throw new HttpsError("not-found", "No matching order.");
    }
    const order = orderSnap.data();
    if (order.status !== "paid") {
      throw new HttpsError(
        "failed-precondition",
        "Only a paid order can be refunded."
      );
    }

    const razorpay = new Razorpay({
      key_id: RAZORPAY_KEY_ID.value(),
      key_secret: RAZORPAY_KEY_SECRET.value(),
    });
    await razorpay.payments.refund(order.razorpayPaymentId, {});

    if (order.type === "course") {
      await db.collection("users").doc(uid).collection("purchases").doc(order.courseId).delete();
    } else if (order.type === "subscription") {
      await db.collection("users").doc(uid).collection("subscription").doc("current")
        .set({ status: "cancelled" }, { merge: true });
    }

    await orderRef.update({
      status: "refunded",
      refundedAt: admin.firestore.FieldValue.serverTimestamp(),
      refundedBy: request.auth.uid,
    });

    logger.info(`${request.auth.uid} refunded order ${orderId} for ${uid}`);
    return { success: true };
  }
);

// ---------------------------------------------------------------------
// Notifications (Module 9 - admin push notification composer)
// ---------------------------------------------------------------------

// Preference keys a user can individually opt out of - see
// users/{uid}.notificationPrefs and
// lib/screens/notification_preferences_screen.dart. 'general' is
// deliberately NOT a preference key: it's for announcements important
// enough that they always go out regardless of a user's other
// opt-outs (e.g. maintenance windows, policy changes).
const NOTIFICATION_CATEGORIES = [
  "general",
  "liveClasses",
  "courseUpdates",
  "quizReminders",
  "promotions",
];

/// sendNotification - admin-only. Composes a push, writes a
/// `notifications/{id}` history record, resolves the target audience,
/// filters out anyone who's opted out of that category, and fans the
/// push out to every one of their registered devices
/// (`users/{uid}/deviceTokens`). Sending only ever happens here, via
/// the Admin SDK - there's no client-side path to trigger a push,
/// same "server owns the write" stance as fulfillOrder/setAdminRole.
///
/// data: {
///   title: string, body: string,
///   category: one of NOTIFICATION_CATEGORIES,
///   targetType: 'all' | 'role' | 'examTrack' | 'user',
///   targetValue: string (role name / examTrack name / uid - omitted for 'all'),
///   deepLink: { screen: string, courseId?: string } (matches
///     NotificationService._navigate's supported screens)
/// }
exports.sendNotification = onCall(async (request) => {
  if (request.auth?.token?.admin !== true) {
    throw new HttpsError(
      "permission-denied",
      "Only an admin can send notifications."
    );
  }

  const { title, body, category, targetType, targetValue, deepLink } =
    request.data || {};

  if (typeof title !== "string" || title.trim() === "") {
    throw new HttpsError("invalid-argument", "title is required.");
  }
  if (typeof body !== "string" || body.trim() === "") {
    throw new HttpsError("invalid-argument", "body is required.");
  }
  if (!NOTIFICATION_CATEGORIES.includes(category)) {
    throw new HttpsError(
      "invalid-argument",
      `category must be one of: ${NOTIFICATION_CATEGORIES.join(", ")}`
    );
  }
  if (!["all", "role", "examTrack", "user"].includes(targetType)) {
    throw new HttpsError(
      "invalid-argument",
      "targetType must be 'all', 'role', 'examTrack', or 'user'."
    );
  }
  if (targetType !== "all" && (typeof targetValue !== "string" || !targetValue)) {
    throw new HttpsError(
      "invalid-argument",
      "targetValue is required unless targetType is 'all'."
    );
  }

  const db = admin.firestore();
  const historyRef = db.collection("notifications").doc();
  await historyRef.set({
    title,
    body,
    category,
    targetType,
    targetValue: targetValue || null,
    deepLink: deepLink || null,
    status: "sending",
    sentBy: request.auth.uid,
    sentAt: admin.firestore.FieldValue.serverTimestamp(),
    recipientCount: 0,
    successCount: 0,
    failureCount: 0,
  });

  try {
    // 1. Resolve which user docs match the target.
    let usersSnap;
    if (targetType === "user") {
      const doc = await db.collection("users").doc(targetValue).get();
      usersSnap = { docs: doc.exists ? [doc] : [] };
    } else {
      let usersQuery = db.collection("users");
      if (targetType === "role") {
        usersQuery = usersQuery.where("role", "==", targetValue);
      } else if (targetType === "examTrack") {
        usersQuery = usersQuery.where("examTrack", "==", targetValue);
      }
      usersSnap = await usersQuery.get();
    }

    // 2. Drop anyone who's opted out of this category (not applicable
    // to 'general', which always goes out).
    const eligibleUids = usersSnap.docs
      .filter((doc) => {
        if (category === "general") return true;
        const prefs = doc.data().notificationPrefs || {};
        return prefs[category] !== false;
      })
      .map((doc) => doc.id);

    // 3. Gather every device token across all eligible users.
    const tokenLists = await Promise.all(
      eligibleUids.map((uid) =>
        db.collection("users").doc(uid).collection("deviceTokens").get()
      )
    );
    const tokens = tokenLists.flatMap((snap) => snap.docs.map((d) => d.id));

    if (tokens.length === 0) {
      await historyRef.update({
        status: "sent",
        recipientCount: eligibleUids.length,
        successCount: 0,
        failureCount: 0,
      });
      return { success: true, recipientCount: eligibleUids.length, devicesSent: 0 };
    }

    // 4. Batch send - sendEachForMulticast caps at 500 tokens per call.
    const messageBase = {
      notification: { title, body },
      data: {
        notificationId: historyRef.id,
        screen: deepLink?.screen || "",
        courseId: deepLink?.courseId || "",
      },
    };

    let successCount = 0;
    let failureCount = 0;
    const staleTokens = [];

    for (let i = 0; i < tokens.length; i += 500) {
      const batch = tokens.slice(i, i + 500);
      const response = await admin.messaging().sendEachForMulticast({
        ...messageBase,
        tokens: batch,
      });
      successCount += response.successCount;
      failureCount += response.failureCount;
      response.responses.forEach((r, idx) => {
        if (!r.success && (r.error?.code === "messaging/registration-token-not-registered")) {
          staleTokens.push(batch[idx]);
        }
      });
    }

    // 5. Clean up tokens FCM says are dead (uninstalled app, expired,
    // etc.) so future sends don't keep paying to retry them. Best
    // effort - a failure here shouldn't fail the whole send.
    if (staleTokens.length > 0) {
      try {
        await Promise.all(
          tokenLists.flatMap((snap) =>
            snap.docs
              .filter((d) => staleTokens.includes(d.id))
              .map((d) => d.ref.delete())
          )
        );
      } catch (cleanupErr) {
        logger.warn(`Stale token cleanup failed: ${cleanupErr.message}`);
      }
    }

    await historyRef.update({
      status: "sent",
      recipientCount: eligibleUids.length,
      successCount,
      failureCount,
    });

    logger.info(
      `${request.auth.uid} sent notification ${historyRef.id} to ${successCount}/${tokens.length} devices`
    );
    return {
      success: true,
      recipientCount: eligibleUids.length,
      devicesSent: successCount,
      devicesFailed: failureCount,
    };
  } catch (err) {
    await historyRef.update({ status: "failed", error: err.message });
    throw new HttpsError("internal", `Send failed: ${err.message}`);
  }
});
