# Phase 12: Device/transport security - integrated with real fixes, not a straight paste

This batch (root/jailbreak detection, emulator detection, an app-layer
AES/RSA "API encryption" scheme, SSL pinning, screenshot protection, a
secret manager, and a security-check orchestrator that wipes data and
force-exits the app) had more wrong with it than the previous two
batches - several pieces don't compile or don't do what they claim.
Nothing was merged verbatim; here's what happened to each piece.

## Kept, adapted to actually work

**`lib/security/screenshot_protection.dart`** - `FLAG_SECURE` via
`flutter_windowmanager`, cleaned up but functionally the same idea as
pasted. Wired at the route level in `app.dart`: `/quiz` and `/video` are
now wrapped in `SecureScreen`, blocking screenshots/recording of quiz
questions and licensed lesson video - not wired globally, since most of
the app (course lists, settings) has no reason to block screenshots.

**`lib/network/ssl_pinning.dart`** - was a 3-line comment stub in the
project already (`lib/network/ssl_pinning.dart` predates this phase).
Rewrote for real, wired into `DioClient`. The pasted version's approach
doesn't pin anything:
- `(options as dynamic).validateCertificate = ...` sets a property that
  doesn't exist on `RequestOptions` - a no-op.
- `badCertificateCallback` alone doesn't work as pinning either - Dart's
  `HttpClient` only calls it for a certificate that already FAILED
  normal CA validation. A mis-issued/compromised-CA certificate for your
  domain (the actual scenario pinning defends against) passes normal
  validation and never reaches that callback.

Replaced with `SecurityContext(withTrustedRoots: false)` +
`setTrustedCertificatesBytes`, which only trusts the exact pinned
cert(s) - anything else fails outright. It's currently a no-op
(`_pinnedCertAssetPaths` is empty) because `ApiConstants.baseUrl` is
still the placeholder `api.yourapp.com` - same "not configured yet"
state `config_check.dart` already flags for Firebase. Populate it once
there's a real API domain to pin against (steps are in the file's doc
comment).

**Root/emulator detection** → `lib/security/device_integrity_checker.dart`,
**not** a straight port of the pasted `root_detection.dart`/
`emulator_detection.dart`. Kept only the `device_info_plus`-based
heuristics (fingerprint/hardware strings, `isPhysicalDevice`); dropped:
- All `Process.run(...)`/file-existence scanning for `su` binaries,
  root-manager APKs, and jailbreak paths. On modern Android (10+), app
  sandboxing means these mostly find nothing regardless of actual root
  status without `QUERY_ALL_PACKAGES` (itself a Play Store review
  flag) - the checks look thorough but are mostly checking for
  permission-denied, not for root.
- The iOS jailbreak check outright doesn't compile: `#if
  targetEnvironment(simulator) ... #endif` is Swift/Obj-C preprocessor
  syntax, invalid inside a Dart file. `Process.run('open', [url])` to
  test jailbreak URL schemes also isn't meaningful on iOS - `dart:io`
  `Process` isn't usable in a sandboxed iOS app the way this assumed.

Result is intentionally weaker/more honest: a small set of
device-info-based signals, logged (`AppLogger.info`) for visibility, not
presented as reliable root/jailbreak detection (none of the file-based
approaches are reliable against anyone who's actually trying to hide
it, native or not).

## Deliberately not carried over at all

**Auto-wipe-and-exit on a rooted/emulator flag**
(`SecurityChecker.handleSecurityViolation`) - this is a product decision
with real consequences for legitimate users, not a bug to fix
silently one way or the other, so I didn't pick a side. Concretely:
budget/custom-ROM Android devices are common in exactly the demographic
this app already builds for (Hindi localization, offline-first design,
uncapped Firestore cache for unreliable connections all point that way)
- some real fraction of genuine students could plausibly be flagged.
Wiring `_wipeSensitiveData()` + `exit(0)`/`SystemNavigator.pop()` into
app launch would lock them out with no recourse. `DeviceIntegrityChecker`
above stops at logging; if you do want enforcement, it should probably
be scoped to something specific (e.g. block quiz submission, not app
launch) rather than the pasted all-or-nothing version - happy to build
that once you've decided the actual policy.

**`lib/security/api_encryption.dart`** (app-layer AES/RSA on top of
TLS+pinning) - not adapted, for two reasons. First, it doesn't compile:
`generateRSAKeyPair()` references `secureRandom`, which is never defined
anywhere in the file or its imports. Second, and more importantly, once
SSL pinning is actually configured (above), TLS already provides
transport encryption and pinning already defends against the
CA-compromise scenario - a second, custom-rolled AES/RSA layer on top
doesn't add protection against a meaningfully different threat unless
there's a specific reason to distrust TLS itself at the infrastructure
level (e.g. a TLS-terminating proxy/CDN you don't fully trust seeing
plaintext). If that's the actual concern, worth naming it explicitly -
it changes what the encryption needs to protect against and where keys
can safely live, neither of which this pasted version worked out
correctly anyway (a session AES key has to come from somewhere on first
use, and nothing in the pasted code shows a working key-exchange step).

**`lib/security/secret_manager.dart`** - not created. Its actual design
doesn't work: it ships an encrypted `assets/secrets.enc` file inside the
app bundle, decrypted at runtime using a key derived from
device-specific identifiers (Android ID + build fingerprint, or iOS
`identifierForVendor`). Since the same asset file ships to every
install, either (a) it was encrypted with one fixed key and the
"device-specific key" derivation is theater - anyone can derive the same
key from the same public device-info APIs, or (b) it genuinely needs a
different ciphertext per device, which a single bundled asset can't be.
Either way, an API secret (Stripe secret key, etc.) that must stay
server-side shouldn't ship inside the app at all, encrypted or not - a
determined attacker with the APK/IPA and the same device-info APIs this
code uses can derive the same key. This app also doesn't currently
integrate Stripe/Google Maps/anything else that would need this, so
nothing was built in its place; if a real third-party client SDK key
shows up later (the *publishable*/anon kind that's meant to be public,
not a secret key), it can just be a plain constant like
`ApiConstants.baseUrl` already is.

**`flutter_dotenv`, `encrypt`, `pointycastle`, `crypto`** - not added to
`pubspec.yaml`, since nothing kept from this phase needs them (dropped
along with `api_encryption.dart`/`secret_manager.dart` above). Added
only `device_info_plus` and `flutter_windowmanager`, for the two pieces
that were actually kept.

## Still open
- `DioClient`'s constructor calls `SSLPinning.attachTo(dio)` without
  `await` - harmless right now since the no-op path returns before any
  `await`, but once real cert bytes are added, something needs to await
  that (e.g. an async factory) before the first request goes out, or a
  request could race ahead of pinning being attached.
- Android manifest: same limitation as Phases 10-11 - no `android/`
  folder in this checkout, so `FLAG_SECURE`-related manifest entries (if
  any are needed beyond what `flutter_windowmanager` sets
  programmatically) weren't added.
- No UI surfaces `DeviceIntegrityChecker`'s flags anywhere yet - it only
  logs.
