# Phase 10: OS-level background sync (Workmanager)

## Problem
Every sync trigger so far only runs while the app process is alive:
`SyncScheduler` (`lib/sync`) is a `Timer.periodic`, and `ConnectivitySync`'s
listener is a stream subscription - both die the instant the app is
backgrounded or killed. Nothing flushes the queue if a student closes
the app with pending items and doesn't reopen it for a while.

## What changed

**Added `workmanager: ^0.5.2`** to `pubspec.yaml`.

**New `lib/services/background_sync_scheduler.dart`:**
- `BackgroundSyncScheduler.initialize()` - called once from `main.dart`,
  registers a ~20-minute periodic Workmanager task (Android floors this
  at 15 min regardless). Uses `ExistingWorkPolicy.keep` so relaunching
  the app doesn't reset the window each time.
- `BackgroundSyncScheduler.triggerImmediateSync()` - one-off task, wired
  to a new "Sync Now" row in `SettingsScreen`.
- `callbackDispatcher()` - the actual background entry point. Runs in
  its own isolate (Android), so it re-initializes Firebase and
  `LocalDatabase` from scratch and constructs the **real** object graph
  - `QueueManager` -> `QueueProcessor` (with
  `buildRepositorySyncCallback`, same as everywhere else) ->
  `sync.SyncService.startSync()`. Nothing new was invented for "how to
  sync" - this only adds a second trigger for the pipeline that already
  existed.

**`main.dart`:** calls `BackgroundSyncScheduler.initialize()` after the
existing Firebase/LocalDatabase startup block, in its own try/catch so a
Workmanager failure (e.g. unsupported platform) can't block app launch.

**`SettingsScreen`:** added a "Sync Now" row showing `PendingSyncIndicator`
as its subtitle, calling `triggerImmediateSync()` on tap.

## What was rejected from the pasted code, and why
The pasted `sync_service.dart` / `sync_screen.dart` / `workmanager_service.dart`
/ `main.dart` snippet described a **parallel, simpler sync system**, not an
addition to the existing one:

- It defined its own `SyncService` class with raw `http` POST calls and
  string blobs in `SharedPreferences` (`user_data`, `pending_sync_data`,
  `cached_content`). This project already has a `SyncService` (`lib/sync/
  sync_service.dart`) built on the typed, Hive-backed `SyncItem` queue -
  keeping both would mean two same-named classes doing the same job
  differently, and the app's actual course/quiz/profile data going
  through a second, untyped path that bypasses `RetryPolicy`,
  `QueueProcessor`'s dead-letter handling, and `AppLogger`.
- It added `http` as a dependency alongside the project's existing `dio`
  client (`lib/network/dio_client.dart`, with its own auth interceptor,
  SSL pinning, retry logic) rather than using it.
- Its pasted `main.dart` was a from-scratch `main()` with no Firebase,
  Crashlytics, App Check, or `runZonedGuarded` error handling - adopting
  it as-is would have deleted all of Phase 1-9's startup logic.

None of that was carried over. Only the actual new capability -
OS-scheduled background execution - was integrated, as a trigger *into*
the existing pipeline rather than a replacement for it.

## Still open
- Android `RECEIVE_BOOT_COMPLETED` / `FOREGROUND_SERVICE` permissions:
  this repo doesn't include an `android/` folder (source-only checkout),
  so `AndroidManifest.xml` couldn't be edited here. Add both permissions
  once the platform folders exist, or Workmanager's periodic task won't
  survive a device reboot.
- `ConnectivitySync` (Phase 9) is still not constructed anywhere - same
  "deliberately out of scope" item Phase 9 flagged. It and
  `BackgroundSyncScheduler` are complementary (in-app reconnect vs.
  app-closed periodic), not redundant, but nobody assembles either into
  a single `syncManagerProvider` yet.
- No UI shows *when* the last background run happened or whether it
  succeeded - `triggerImmediateSync()` only confirms the task was
  scheduled, not that it ran.
