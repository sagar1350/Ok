# Phase 2: Security & Firebase configuration

## Problem
Phase 1 got real data flowing through Firestore behind repository
interfaces, but nothing stopped abuse of that data:
- Any signed-in client could write whatever shape it wanted to its own
  `users/{uid}` doc or subcollections - forge a role, inject stray
  fields, report a quiz score higher than the quiz's total.
- Firestore/Auth had no App Check - a cloned APK or a bot with a
  scraped API key could call the backend exactly like the real app.
- Logging out only cleared secure storage; a per-user Hive cache
  (`downloads`) would have leaked into the next session on a shared
  device once that box actually gets used.
- The Firestore rules had never been tested against anything - just
  read by eye.
- The CI workflow's default `GITHUB_TOKEN` had broader permissions than
  any of its steps need, and decoded signing material was never
  explicitly cleaned up.

## What changed

**Firebase App Check** (`lib/utils/app_check_init.dart`, wired into
`main.dart` right after `Firebase.initializeApp()`): debug provider in
debug builds, Play Integrity / App Attest in release. This is the
control that actually blocks non-genuine clients - security rules only
govern what a *legitimate* signed-in user can do, not who's allowed to
call Firebase at all. Still needs enabling per-app in the Firebase
console (README "Turn on App Check" section) - the client wiring alone
doesn't enforce anything until you flip that switch.

**Firestore rules** (`firestore.rules`) rewritten from ownership-only
to ownership + shape validation:
- `users/{uid}`: `create` validates every field's type and restricts
  `role` to the known enum; `update` only allows changing `role`
  (nothing else about an existing profile is client-editable anymore).
- `users/{uid}/enrollments/{courseId}`: `progressPercent` must be a
  number in `[0, 1]`; unexpected fields rejected.
- `users/{uid}/quizAttempts/{attemptId}`: `create`-only (no
  `update`/`delete` - a past result can't be rewritten), `score` must be
  `0 <= score <= total`. This still trusts the client's reported score
  (no server-side grading exists) - noted as a follow-up.

**Automated rules tests** (`firestore/rules_test/`, using
`@firebase/rules-unit-testing` against the real emulator): prove a user
can't write another user's data, can't forge a role outside the enum,
can't report an impossible quiz score, and can't edit a past attempt.
Runs as its own `firestore-rules` CI job, independent of the Flutter
build.

**CI hardening** (`.github/workflows/build-apk.yml`):
- Added `permissions: contents: read` at the workflow level (was
  implicitly the broader default).
- Added a step to remove the decoded keystore/`key.properties` off the
  runner after the release build, on top of the runner already being
  ephemeral.
- New `firestore-rules` job runs the tests above on every push.

**Logout hygiene** (`AuthNotifier.logout`): now clears the `downloads`
Hive box in addition to secure storage, since this is a shared-device
app (school/library devices) and per-user cached content shouldn't
survive into the next person's session. `settings` (theme/locale) is
left alone as a device-level preference. Wrapped in try/catch to match
the rest of the codebase's error-resilience style.

**Docs**: README gained sections for enabling App Check, running the
rules tests, and restricting the Firebase API key by package
name/SHA-1/bundle ID (a secondary control - App Check is the stronger
one, since the API key itself isn't a secret once compiled into the
app).

## Deliberately out of scope for this phase
- Server-side quiz grading (Cloud Function) - rules validate
  score/total shape and range, but still trust the client's numbers.
  Only worth the added complexity once quiz results feed into
  something higher-stakes than a personal streak.
- Rate limiting phone-auth *server-side* beyond what Firebase's own
  quotas already provide - App Check is the mitigation here, not a
  custom rate limiter.
- Rotating/regenerating the placeholder Firebase project itself -
  that's still a manual `flutterfire configure` step for whoever runs
  this in production.
