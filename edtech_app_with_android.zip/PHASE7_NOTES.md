# Phase 7: REST network layer (Dio-based)

## Problem
Everything so far talks to Firebase (Firestore/Auth) directly through
the `*Repository` interfaces. There's no client for talking to a
plain REST backend - useful for endpoints that aren't Firestore-backed
(e.g. this could be the missing piece for the `bookmark`/`notes` sync
types that `default_sync_handlers.dart` currently can't sync anywhere
- see the Phase 5 notes).

## What changed (`lib/network/`)
- `api_constants.dart` - base URL + connect/receive timeouts.
- `network_result.dart` - `NetworkResult<T>` success/failure wrapper.
- `token_manager.dart` - reads/writes access+refresh tokens via
  `flutter_secure_storage` (already a dependency, used elsewhere for
  other secrets).
- `dio_client.dart` - builds a `Dio` with `ApiConstants` + the auth
  interceptor attached.
- `api_service.dart` - thin `Future<NetworkResult<Map<String,dynamic>>>
  post(url, body)` wrapper around `dio.post`.
- `auth_interceptor.dart` - **not in the pasted code**
  (`dio_client.dart` referenced `AuthInterceptor()` without it being
  defined anywhere, and it wasn't in the file tree either). Written to
  make the client actually compile/work: attaches
  `Authorization: Bearer <token>` to every request via
  `TokenManager.accessToken()`; on a 401, calls
  `POST /auth/refresh` with `{refreshToken}`, expects
  `{accessToken, refreshToken}` back, saves the new pair, and retries
  the original request once (guarded against looping if the refreshed
  token also 401s). **The refresh endpoint path and both field names
  are assumptions** - there was nothing in what you pasted specifying
  your backend's actual refresh contract, so point `_refreshPath` and
  the field names in `AuthInterceptor._refresh()` at whatever it
  really is.

Also added the imports the pasted `dio_client.dart` (`ApiConstants`,
`AuthInterceptor`) and `api_service.dart` (`NetworkResult`) snippets
were missing, since they wouldn't compile as pasted.

**`pubspec.yaml`:** added `dio: ^5.5.0`.
`flutter_secure_storage: ^9.2.2` was already present at the requested
version.

## Deliberately out of scope for this phase
- `ApiService` only has `post()` - no `get`/`put`/`delete` yet.
- Nothing wires this into Riverpod (`repository_providers.dart`) or
  actually calls it from anywhere - it's a standalone client, not
  connected to the rest of the app yet.
- `auth_interceptor.dart`'s refresh contract is a guess (see above) -
  treat it as a starting point to correct against your real backend,
  not as verified behavior.

## Update: interceptor simplified, logging + error handling added

**`auth_interceptor.dart` replaced.** The refresh-on-401 logic from
the first pass was speculative (its endpoint contract was never
specified) and has been dropped in favor of the simpler version
actually given: attaches `Authorization`/`Content-Type`/`Accept`
headers on request, and on error just calls `handler.next(err)` with
a comment marking auto-refresh as explicit future work ("Part 3").
Nothing currently retries a 401 - that's intentional for now, not a
missed case.

**`lib/network/logging_interceptor.dart`** (new) - prints
method/URL on request, status on response, message on error. Added to
`DioClient` after `AuthInterceptor`. Worth flagging: these `print()`
calls have no `kDebugMode` guard, unlike the rest of this app's
logging (`AppLogger`, Crashlytics/Performance collection) which is
consistently gated to avoid noise/leakage in release builds - add one
here too before shipping if request/response bodies or URLs
(potentially containing tokens or PII) shouldn't reach a production
device's logs.

**`lib/network/network_error_parser.dart`** (new) - `parseNetworkError
(DioException)` maps `connectionTimeout`/`receiveTimeout`/`badResponse`
to short user-facing strings, everything else to `"Unknown Error"`.
`ApiService.post()` now catches `DioException` specifically and uses
this instead of falling through to the generic `e.toString()` (which
still handles any non-Dio exception).

**`lib/network/network_retry.dart`** (new) - `retryRequest(dio,
request)`, a one-line wrapper around `dio.fetch(request)`. Not called
from anywhere yet - it's the piece the deferred Part-3 refresh flow in
`AuthInterceptor.onError` will need to replay the original request
after a token refresh.

## Update: Part 3 - auth refresh wiring + more network stubs

**`refresh_service.dart`** (new) - `RefreshService.refreshToken()`
added exactly as given: a stub that always returns `false`, with the
actual `POST /auth/refresh` call left as a `TODO` on purpose (its
endpoint/response contract still isn't specified anywhere, and
guessing at it was the wrong call last time).

**`auth_interceptor.dart`'s `onError` is now wired to the 401 →
refresh → retry-or-logout diagram**, using that stub:
- 401 + not already retried → calls `RefreshService.refreshToken()`.
- Refresh fails (the only path that runs today, since the stub always
  returns `false`) → `TokenManager.clear()` ("Logout" in the diagram).
  Nothing currently reacts to cleared tokens by routing to the login
  screen - that depends on whatever reads auth state noticing they're
  gone.
- Refresh succeeds → reads the new access token, retries the original
  request once via `retryRequest()` (needed `AuthInterceptor` to hold
  a `Dio` reference now, so its constructor takes one - `dio_client.dart`
  passes its own `dio` in, updated to `AuthInterceptor(dio)`), guarded
  by an `extra['retriedAfterRefresh']` flag so a refreshed token that
  *also* 401s can't loop forever.

**Other new stubs, added as pasted (bodies intentionally empty/TODO,
not implemented):**
- `upload_service.dart` - `UploadService.uploadFile()`, multipart
  upload not yet implemented.
- `download_service.dart` - `DownloadService.download()`,
  progress-tracked download not yet implemented.
- `network_cache.dart` - `NetworkCache.saveResponse()` /
  `readResponse()`, both no-ops.
- `ssl_pinning.dart` - **comments only, no code at all** ("Configure
  Dio HttpClientAdapter" / "Verify server certificate" / "Reject
  unknown certificates"). Left exactly as given rather than writing
  real pinning logic, since that needs your actual server's
  certificate/public-key fingerprint - fabricating one would be
  worse than an empty file that's honest about being unimplemented.

None of `upload_service.dart`/`download_service.dart`/
`network_cache.dart`/`ssl_pinning.dart` are wired into `DioClient` or
called from anywhere yet.
