import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Shown instead of crashing when lib/firebase_options.dart still has
/// placeholder values. Gives the developer (not the end user) a clear
/// next step.
class ConfigErrorScreen extends StatelessWidget {
  final String? message;

  const ConfigErrorScreen({super.key, this.message});

  @override
  Widget build(BuildContext context) {
    final details = message ??
        'Firebase has not been configured for this app yet.';

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.settings_suggest_outlined,
                    size: 72, color: Color(0xFF6C63FF)),
                const SizedBox(height: 24),
                const Text(
                  'Setup needed',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                Text(
                  details,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black54),
                ),
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const SelectableText(
                    'flutterfire configure',
                    style: TextStyle(fontFamily: 'monospace', fontSize: 16),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: () {
                    Clipboard.setData(
                        const ClipboardData(text: 'flutterfire configure'));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Command copied')),
                    );
                  },
                  icon: const Icon(Icons.copy, size: 18),
                  label: const Text('Copy command'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
