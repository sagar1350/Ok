import 'package:flutter/material.dart';
import '../services/offline_lesson_store.dart';

/// Lists lessons the student has saved via the bookmark icon on
/// VideoPlayerScreen. See OfflineLessonStore's doc comment for what
/// "saved" actually means here - metadata only, not a downloaded video
/// file - this screen's empty/description text says the same thing so
/// it isn't a surprise.
class SavedLessonsScreen extends StatefulWidget {
  const SavedLessonsScreen({super.key});

  @override
  State<SavedLessonsScreen> createState() => _SavedLessonsScreenState();
}

class _SavedLessonsScreenState extends State<SavedLessonsScreen> {
  final _store = OfflineLessonStore();
  late List<Map<String, dynamic>> _saved = _store.getAll();

  void _refresh() => setState(() => _saved = _store.getAll());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved for Offline Browsing')),
      body: _saved.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.bookmark_border,
                        size: 48, color: Colors.grey[400]),
                    const SizedBox(height: 12),
                    Text(
                      "No saved lessons yet. Tap the bookmark icon while "
                      "watching a lesson to save its details here for "
                      "offline browsing.",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _saved.length,
              itemBuilder: (context, index) {
                final lesson = _saved[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: const Icon(Icons.play_circle_outline),
                    title: Text(lesson['lessonTitle'] as String),
                    subtitle: Text(lesson['courseTitle'] as String),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await _store.remove(
                          lesson['courseId'] as String,
                          lesson['lessonTitle'] as String,
                        );
                        _refresh();
                      },
                    ),
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/video',
                        arguments: {
                          'url': lesson['videoUrl'] as String,
                          'title': lesson['lessonTitle'] as String,
                        },
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
