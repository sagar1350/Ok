import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/quiz_provider.dart';

class QuizScreen extends ConsumerWidget {
  const QuizScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(quizControllerProvider);
    final controller = ref.read(quizControllerProvider.notifier);

    if (state.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (state.error != null || state.quiz == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Quiz')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              state.error ?? 'No quiz available.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final questions = state.quiz!.questions;

    // Result screen
    if (state.isFinished) {
      return Scaffold(
        appBar: AppBar(title: const Text('Quiz Result')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: state.score >= (questions.length / 2).ceil()
                      ? Colors.green.withOpacity(0.1)
                      : Colors.red.withOpacity(0.1),
                ),
                child: Icon(
                  state.score >= (questions.length / 2).ceil()
                      ? Icons.emoji_events
                      : Icons.sentiment_dissatisfied,
                  size: 60,
                  color: state.score >= (questions.length / 2).ceil()
                      ? Colors.amber
                      : Colors.red,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                state.score >= (questions.length / 2).ceil()
                    ? 'Congratulations!'
                    : 'Keep Practicing!',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                'Your Score: ${state.score} / ${questions.length}',
                style: const TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 8),
              Text(
                '${((state.score / questions.length) * 100).toStringAsFixed(0)}%',
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                  color: state.score >= (questions.length / 2).ceil()
                      ? Colors.green
                      : Colors.red,
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Back to Dashboard'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: controller.retry,
                child: const Text('Retry Quiz'),
              ),
            ],
          ),
        ),
      );
    }

    // Quiz screen
    final question = questions[state.currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: Text(state.quiz!.title),
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (state.currentQuestion + 1) / questions.length,
            backgroundColor: Colors.grey[200],
            valueColor: const AlwaysStoppedAnimation(Color(0xFF6C63FF)),
            minHeight: 4,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Question ${state.currentQuestion + 1}/${questions.length}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  'Score: ${state.score}',
                  style: const TextStyle(
                      color: Color(0xFF6C63FF), fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF6C63FF).withOpacity(0.05),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      question.text,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w500, height: 1.5),
                    ),
                  ),
                  const SizedBox(height: 24),
                  ...List.generate(question.options.length, (index) {
                    final isSelected = state.selectedOption == index;
                    final isCorrect = index == question.correctIndex;

                    Color? bgColor;
                    if (state.isAnswered) {
                      if (isCorrect) {
                        bgColor = Colors.green.withOpacity(0.1);
                      } else if (isSelected && !isCorrect) {
                        bgColor = Colors.red.withOpacity(0.1);
                      }
                    } else if (isSelected) {
                      bgColor = const Color(0xFF6C63FF).withOpacity(0.1);
                    }

                    Color? borderColor;
                    if (state.isAnswered) {
                      if (isCorrect) {
                        borderColor = Colors.green;
                      } else if (isSelected && !isCorrect) {
                        borderColor = Colors.red;
                      }
                    } else if (isSelected) {
                      borderColor = const Color(0xFF6C63FF);
                    }

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        onTap: () => controller.checkAnswer(index),
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: bgColor ?? Theme.of(context).cardTheme.color,
                            border: Border.all(
                              color: borderColor ?? Colors.grey.withOpacity(0.3),
                              width: borderColor != null ? 2 : 1,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isSelected
                                      ? borderColor ?? const Color(0xFF6C63FF)
                                      : Colors.grey[200],
                                ),
                                child: Center(
                                  child: Text(
                                    String.fromCharCode(65 + index),
                                    style: TextStyle(
                                      color: isSelected
                                          ? Colors.white
                                          : Colors.grey[700],
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  question.options[index],
                                  style: const TextStyle(fontSize: 15),
                                ),
                              ),
                              if (state.isAnswered && isCorrect)
                                const Icon(Icons.check_circle, color: Colors.green),
                              if (state.isAnswered && isSelected && !isCorrect)
                                const Icon(Icons.cancel, color: Colors.red),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
          if (state.isAnswered)
            Padding(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: controller.nextQuestion,
                  child: Text(
                    state.currentQuestion < questions.length - 1
                        ? 'Next'
                        : 'See Result',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
