import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../models/course_progress.dart';
import '../providers/course_providers.dart';
import '../translations/app_localizations.dart';
import '../utils/course_visuals.dart';
import '../widgets/shimmer_placeholders.dart';

class StudentDashboard extends ConsumerWidget {
  const StudentDashboard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final continueLearningAsync = ref.watch(continueLearningProvider);
    final recommendedAsync = ref.watch(recommendedCoursesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text('${l10n.dashboard} 👋'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Streak Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C63FF), Color(0xFF3F3D9E)],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '🔥 7 Day Streak!',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          "Keep it up! You're doing great.",
                          style: TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.local_fire_department,
                    color: Colors.orange,
                    size: 48,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Quick Actions
            Row(
              children: [
                _QuickAction(
                  icon: Icons.quiz_outlined,
                  label: 'Daily Quiz',
                  color: Colors.orange,
                  onTap: () => Navigator.pushNamed(context, '/quiz'),
                ),
                const SizedBox(width: 12),
                _QuickAction(
                  icon: Icons.auto_awesome,
                  label: 'AI Tutor',
                  color: Colors.purple,
                  onTap: () {},
                ),
                const SizedBox(width: 12),
                _QuickAction(
                  icon: Icons.leaderboard_outlined,
                  label: 'Rankings',
                  color: Colors.teal,
                  onTap: () {},
                ),
                const SizedBox(width: 12),
                _QuickAction(
                  icon: Icons.calendar_today,
                  label: 'Planner',
                  color: Colors.pink,
                  onTap: () {},
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Continue Learning
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.continueLearning,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, '/courses'),
                  child: Text(l10n.seeAll),
                ),
              ],
            ),

            const SizedBox(height: 12),

            SizedBox(
              height: 180,
              child: continueLearningAsync.when(
                loading: () => ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: 3,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) => const SizedBox(
                    width: 280,
                    child: CourseRowSkeleton(),
                  ),
                ),
                error: (_, __) => Center(
                  child: Text('Could not load your courses.',
                      style: TextStyle(color: Colors.grey[600])),
                ),
                data: (items) {
                  if (items.isEmpty) {
                    return Center(
                      child: Text(
                        "You haven't started a course yet.",
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                    );
                  }
                  return ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, index) =>
                        _ContinueLearningCard(progress: items[index]),
                  );
                },
              ),
            ),

            const SizedBox(height: 24),

            // Recommended Courses
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.recommended,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.pushNamed(context, '/courses'),
                  child: Text(l10n.seeAll),
                ),
              ],
            ),

            const SizedBox(height: 12),

            recommendedAsync.when(
              loading: () => Column(
                children: List.generate(
                  3,
                  (_) => const CourseRowSkeleton(),
                ),
              ),
              error: (_, __) => Text('Could not load recommendations.',
                  style: TextStyle(color: Colors.grey[600])),
              data: (courses) {
                if (courses.isEmpty) {
                  return Text('No recommendations yet.',
                      style: TextStyle(color: Colors.grey[600]));
                }
                return Column(
                  children: courses
                      .map((course) => _RecommendedCourseTile(course: course))
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _ContinueLearningCard extends StatelessWidget {
  final CourseProgress progress;
  const _ContinueLearningCard({required this.progress});

  @override
  Widget build(BuildContext context) {
    final color = CourseVisuals.color(progress.colorKey);
    return SizedBox(
      width: 280,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.pushNamed(
            context,
            '/course-detail',
            arguments: progress.courseId,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 100,
                color: color.withOpacity(0.1),
                child: Center(
                  child: Icon(CourseVisuals.icon(progress.iconKey),
                      size: 40, color: color),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      progress.courseTitle,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${progress.lastLessonLabel} • '
                      '${(progress.progressPercent * 100).toStringAsFixed(0)}% complete',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(
                      value: progress.progressPercent,
                      backgroundColor: Colors.grey[200],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RecommendedCourseTile extends StatelessWidget {
  final Course course;
  const _RecommendedCourseTile({required this.course});

  @override
  Widget build(BuildContext context) {
    final color = CourseVisuals.color(course.colorKey);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => Navigator.pushNamed(
          context,
          '/course-detail',
          arguments: course.id,
        ),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(CourseVisuals.icon(course.iconKey),
                    color: color, size: 32),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      course.title,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${course.lessonsCount} Lessons • ${course.rating.toStringAsFixed(1)} ⭐',
                      style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        course.isFree ? 'Free' : '₹${course.priceInr}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.green,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: color, size: 22),
                ),
                const SizedBox(height: 8),
                Text(
                  label,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
