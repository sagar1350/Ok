import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_role.dart';
import '../providers/user_profile_provider.dart';
import '../providers/repository_providers.dart';
import '../translations/app_localizations.dart';

class RoleSelectionScreen extends ConsumerWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context);
    final setRole = ref.read(setUserRoleProvider);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),

              Text(
                l10n.selectRole,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                'Choose how you want to use the app',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),

              const SizedBox(height: 48),

              // Student Card
              _RoleCard(
                icon: Icons.school,
                title: l10n.student,
                subtitle: 'Access courses, take quizzes,\ntrack your progress',
                color: const Color(0xFF6C63FF),
                onTap: () async {
                  await setRole(UserRole.student);
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/dashboard');
                  }
                },
              ),

              const SizedBox(height: 16),

              // Teacher Card
              _RoleCard(
                icon: Icons.person,
                title: l10n.teacher,
                subtitle: 'Create courses, manage students,\nhost live classes',
                color: const Color(0xFFFF6584),
                onTap: () async {
                  await setRole(UserRole.teacher);
                  // Teacher dashboard - same shell for now, screens can
                  // branch on userProfileProvider's role later.
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/dashboard');
                  }
                },
              ),

              const SizedBox(height: 16),

              // Parent Card
              _RoleCard(
                icon: Icons.family_restroom,
                title: l10n.parent,
                subtitle: 'Monitor your child\'s progress,\nattendance & fees',
                color: const Color(0xFF4CAF50),
                onTap: () async {
                  await setRole(UserRole.parent);
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/dashboard');
                  }
                },
              ),

              const SizedBox(height: 16),

              // Admin Card - deliberately NOT the same as the other
              // three. Admin can't be self-assigned: Firestore rules
              // reject a client trying to write role: 'admin' on its
              // own profile, and access is actually gated on the
              // `admin` custom claim (see admin_access_provider.dart),
              // which only the setAdminRole Cloud Function can grant.
              // This card just checks whether that claim is already
              // there; it never sets it.
              _RoleCard(
                icon: Icons.admin_panel_settings,
                title: l10n.admin,
                subtitle: 'Manage users, courses, quizzes,\nlive classes & payments',
                color: const Color(0xFF14213D),
                onTap: () async {
                  // forceRefresh: true - don't trust a cached token
                  // here, since the whole point of this screen is to
                  // find out the current, real access state.
                  final isAdmin = await ref
                      .read(authRepositoryProvider)
                      .isAdmin(forceRefresh: true);
                  if (!context.mounted) return;
                  if (isAdmin) {
                    Navigator.pushReplacementNamed(context, '/admin');
                  } else {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Admin access required'),
                        content: const Text(
                          'Admin access is granted by an existing admin - '
                          'it isn\'t something you can turn on yourself. '
                          'Ask your organization\'s admin to add your '
                          'account.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('OK'),
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _RoleCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: Colors.grey[400], size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
