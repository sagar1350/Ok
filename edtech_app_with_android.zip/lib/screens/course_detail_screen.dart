import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../providers/course_providers.dart';
import '../providers/payment_controller.dart';
import '../providers/payment_providers.dart';
import '../utils/course_visuals.dart';

class CourseDetailScreen extends ConsumerWidget {
  final String courseId;
  const CourseDetailScreen({super.key, required this.courseId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final courseAsync = ref.watch(courseDetailProvider(courseId));

    return courseAsync.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (err, _) => Scaffold(
        appBar: AppBar(),
        body: Center(child: Text('Could not load this course.\n$err')),
      ),
      data: (course) {
        if (course == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('Course not found.')),
          );
        }
        return _CourseDetailBody(course: course);
      },
    );
  }
}

class _CourseDetailBody extends ConsumerWidget {
  final Course course;
  const _CourseDetailBody({required this.course});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final color = CourseVisuals.color(course.colorKey);
    // Free course, active subscription, or a one-time purchase of
    // this specific course - see hasCourseAccessProvider for the
    // precedence.
    final hasAccess = ref.watch(hasCourseAccessProvider(course));

    ref.listen<AsyncValue<void>>(paymentControllerProvider, (prev, next) {
      next.whenOrNull(
        error: (err, _) => ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment failed: $err')),
        ),
      );
      if (prev is AsyncLoading && next is AsyncData) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("You're enrolled! Lessons are unlocked.")),
        );
      }
    });

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 250,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: color.withOpacity(0.1),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(CourseVisuals.icon(course.iconKey),
                          size: 80, color: color),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text(
                          course.title,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: color,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _InfoChip(
                          icon: Icons.play_circle,
                          text: '${course.lessonsCount} Lessons'),
                      const SizedBox(width: 16),
                      _InfoChip(
                          icon: Icons.timer,
                          text: '${course.durationHours.toStringAsFixed(0)} Hours'),
                      const SizedBox(width: 16),
                      _InfoChip(
                          icon: Icons.star,
                          text: '${course.rating.toStringAsFixed(1)} Rating'),
                      const SizedBox(width: 16),
                      _InfoChip(
                          icon: Icons.people,
                          text: '${course.studentsCount} Students'),
                    ],
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    'About This Course',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    course.description,
                    style: TextStyle(color: Colors.grey[600], height: 1.5),
                  ),

                  if (course.whatYoullLearn.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const Text(
                      "What You'll Learn",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    ...course.whatYoullLearn.map((point) => _LearningPoint(point)),
                  ],

                  if (course.curriculum.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const Text(
                      'Curriculum',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    ...course.curriculum.map((chapter) {
                      return ExpansionTile(
                        title: Text(chapter.title),
                        subtitle: Text('${chapter.lessons.length} lessons'),
                        children: chapter.lessons.map((lesson) {
                          // A lesson authored as `locked: false` is a
                          // free preview and always plays. A `locked:
                          // true` lesson plays once the learner has
                          // access to the course (free/purchased/
                          // subscribed) - see hasCourseAccessProvider.
                          final playable = !lesson.locked || hasAccess;
                          return ListTile(
                            leading: Icon(
                              playable
                                  ? Icons.play_circle_outline
                                  : Icons.lock_outline,
                              size: 20,
                            ),
                            title: Text(lesson.title),
                            subtitle: Text(lesson.durationLabel),
                            trailing: Icon(
                              playable ? Icons.lock_open : Icons.lock,
                              size: 16,
                              color: playable ? Colors.green : Colors.grey,
                            ),
                            onTap: !playable
                                ? null
                                : () {
                                    Navigator.pushNamed(
                                      context,
                                      '/video',
                                      arguments: {
                                        'url': lesson.videoUrl,
                                        'title': lesson.title,
                                        'course': course,
                                      },
                                    );
                                  },
                          );
                        }).toList(),
                      );
                    }),
                  ],

                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      course.isFree ? 'Free' : '₹${course.priceInr}',
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      course.isFree
                          ? 'No cost'
                          : (hasAccess ? 'Purchased' : 'One-time payment'),
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SizedBox(
                  height: 56,
                  child: _EnrollButton(course: course, hasAccess: hasAccess),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// The bottom-bar CTA: "Start Learning" once free/purchased/
/// subscribed, a disabled "Enrolled" state is intentionally skipped
/// in favour of letting them jump back into the curriculum above, and
/// a "Buy Now" that drives `PaymentController.purchaseCourse` while
/// paid otherwise.
class _EnrollButton extends ConsumerWidget {
  final Course course;
  final bool hasAccess;
  const _EnrollButton({required this.course, required this.hasAccess});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final paymentState = ref.watch(paymentControllerProvider);
    final isLoading = paymentState.isLoading;

    if (course.isFree || hasAccess) {
      return ElevatedButton.icon(
        onPressed: null,
        icon: const Icon(Icons.check_circle, size: 18),
        label: const Text(
          'Enrolled',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      );
    }

    return ElevatedButton(
      onPressed: isLoading
          ? null
          : () => ref.read(paymentControllerProvider.notifier).purchaseCourse(course),
      child: isLoading
          ? const SizedBox(
              height: 20,
              width: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
            )
          : const Text(
              'Buy Now',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoChip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: Colors.grey[600]),
        const SizedBox(width: 4),
        Text(text, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }
}

class _LearningPoint extends StatelessWidget {
  final String text;
  const _LearningPoint(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text, style: const TextStyle(fontSize: 14)),
          ),
        ],
      ),
    );
  }
}
