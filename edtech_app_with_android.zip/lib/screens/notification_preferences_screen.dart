import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/notification_prefs.dart';
import '../providers/auth_provider.dart';
import '../providers/repository_providers.dart';

/// Lets a signed-in user opt in/out of each push category individually
/// (see notification_prefs.dart). Read from and written straight to
/// their own `users/{uid}.notificationPrefs` map - the
/// sendNotification Cloud Function checks this before including them
/// in anything but a General announcement, which always goes out.
class NotificationPreferencesScreen extends ConsumerWidget {
  const NotificationPreferencesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(authProvider).uid;

    return Scaffold(
      appBar: AppBar(title: const Text('Notification Preferences')),
      body: uid == null
          ? const Center(child: Text('Sign in to manage notifications'))
          : _PrefsList(uid: uid),
    );
  }
}

class _PrefsList extends ConsumerWidget {
  final String uid;
  const _PrefsList({required this.uid});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final prefsAsync =
        ref.watch(_notificationPrefsStreamProvider(uid));

    return prefsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, st) => Center(child: Text('Could not load preferences: $err')),
      data: (prefs) => ListView(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: Text(
              'Choose which notifications you\'d like to receive. '
              'Important announcements always come through regardless of these settings.',
              style: TextStyle(fontSize: 13, color: Colors.grey),
            ),
          ),
          for (final entry in optionalNotificationCategories.entries)
            SwitchListTile(
              title: Text(entry.value),
              value: prefs[entry.key] ?? true,
              onChanged: (value) async {
                final updated = Map<String, bool>.from(prefs)
                  ..[entry.key] = value;
                try {
                  await ref
                      .read(userRepositoryProvider)
                      .updateNotificationPrefs(uid, updated);
                } catch (e) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Could not save: $e')),
                  );
                }
              },
            ),
        ],
      ),
    );
  }
}

final _notificationPrefsStreamProvider =
    StreamProvider.family<Map<String, bool>, String>((ref, uid) {
  return ref.watch(userRepositoryProvider).watchNotificationPrefs(uid);
});
