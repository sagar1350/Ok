import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../providers/course_providers.dart';
import '../utils/course_visuals.dart';
import '../widgets/shimmer_placeholders.dart';

class CourseListScreen extends ConsumerWidget {
  const CourseListScreen({super.key});

  static const _subjects = [
    'All', 'Mathematics', 'Science', 'English', 'Coding', 'History'
  ];
  static const _levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filter = ref.watch(courseFilterProvider);
    final coursesAsync = ref.watch(courseListProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Courses'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Subject Filter Chips
          SizedBox(
            height: 50,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _subjects.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final subject = _subjects[index];
                final isSelected = filter.subject == subject;
                return FilterChip(
                  label: Text(subject),
                  selected: isSelected,
                  onSelected: (_) {
                    ref.read(courseFilterProvider.notifier).state =
                        filter.copyWith(subject: subject);
                  },
                  selectedColor: const Color(0xFF6C63FF).withOpacity(0.2),
                  checkmarkColor: const Color(0xFF6C63FF),
                );
              },
            ),
          ),

          const SizedBox(height: 4),

          // Level Filter Chips
          SizedBox(
            height: 42,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _levels.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final level = _levels[index];
                final isSelected = filter.level == level;
                return ChoiceChip(
                  label: Text(level, style: const TextStyle(fontSize: 12)),
                  selected: isSelected,
                  onSelected: (_) {
                    ref.read(courseFilterProvider.notifier).state =
                        filter.copyWith(level: level);
                  },
                );
              },
            ),
          ),

          // Course Grid
          Expanded(
            child: coursesAsync.when(
              loading: () => GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: 6,
                itemBuilder: (context, index) => const CourseCardSkeleton(),
              ),
              error: (err, _) => Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Could not load courses.\n$err',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ),
              ),
              data: (courses) {
                if (courses.isEmpty) {
                  return Center(
                    child: Text(
                      'No courses match these filters yet.',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  );
                }
                // The catalog is cached for the whole session
                // (allCoursesProvider), so pull-to-refresh is the only
                // way to see newly-added courses without restarting
                // the app.
                return RefreshIndicator(
                  onRefresh: () async {
                    await ref.refresh(allCoursesProvider.future);
                  },
                  child: GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemCount: courses.length,
                    itemBuilder: (context, index) {
                      return _CourseCard(course: courses[index]);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  final Course course;
  const _CourseCard({required this.course});

  @override
  Widget build(BuildContext context) {
    final color = CourseVisuals.color(course.colorKey);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(
            context,
            '/course-detail',
            arguments: course.id,
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 100,
              color: color.withOpacity(0.15),
              child: Center(
                child: Icon(
                  CourseVisuals.icon(course.iconKey),
                  size: 40,
                  color: color,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    course.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${course.lessonsCount} Lessons',
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.star, size: 14, color: Colors.amber[600]),
                      Text(
                        ' ${course.rating.toStringAsFixed(1)}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                      const Spacer(),
                      Text(
                        course.isFree ? 'Free' : '₹${course.priceInr}',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: course.isFree ? Colors.green : null,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
