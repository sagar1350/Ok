import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../models/course.dart';
import '../providers/auth_provider.dart';
import '../providers/course_providers.dart';
import '../providers/repository_providers.dart';
import '../services/offline_lesson_store.dart';

class VideoPlayerScreen extends ConsumerStatefulWidget {
  final String videoUrl;
  final String lessonTitle;
  final Course? course;

  const VideoPlayerScreen({
    super.key,
    required this.videoUrl,
    required this.lessonTitle,
    this.course,
  });

  @override
  ConsumerState<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends ConsumerState<VideoPlayerScreen> {
  late YoutubePlayerController _controller;
  final _offlineStore = OfflineLessonStore();
  late bool _isSaved = widget.course != null &&
      _offlineStore.isSaved(widget.course!.id, widget.lessonTitle);

  void _toggleSaved() {
    final course = widget.course;
    if (course == null) return; // nothing to key the save off of
    setState(() => _isSaved = !_isSaved);
    if (_isSaved) {
      _offlineStore.save(
        courseId: course.id,
        courseTitle: course.title,
        lessonTitle: widget.lessonTitle,
        videoUrl: widget.videoUrl,
      );
    } else {
      _offlineStore.remove(course.id, widget.lessonTitle);
    }
  }

  @override
  void initState() {
    super.initState();

    // YouTube video ID nikalna
    final videoId = YoutubePlayer.convertUrlToId(widget.videoUrl) ?? '';

    _controller = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: true,
      ),
    );

    // Opening a lesson counts as "started" - mark it in the user's
    // enrollment record so it shows up in the dashboard's Continue
    // Learning row. Real completion % would need playback tracking;
    // this is a reasonable starting signal until that's built.
    final uid = ref.read(authProvider).uid;
    final course = widget.course;
    if (uid != null && course != null) {
      ref
          .read(courseRepositoryProvider)
          .recordLessonProgress(
            uid: uid,
            course: course,
            lessonLabel: widget.lessonTitle,
            progressPercent: 0.1,
          )
          .then((_) {
        // So the dashboard's Continue Learning row reflects this visit
        // without needing an app restart.
        if (mounted) ref.invalidate(continueLearningProvider);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.lessonTitle,
          style: const TextStyle(fontSize: 16),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isSaved ? Icons.bookmark : Icons.bookmark_border,
              color: _isSaved ? const Color(0xFF6C63FF) : Colors.white,
            ),
            tooltip: widget.course == null
                ? null
                : (_isSaved
                    ? 'Remove from saved lessons'
                    : 'Save for offline browsing'),
            onPressed: widget.course == null ? null : _toggleSaved,
          ),
        ],
      ),
      body: Column(
        children: [
          // Video Player
          YoutubePlayer(
            controller: _controller,
            showVideoProgressIndicator: true,
            progressIndicatorColor: const Color(0xFF6C63FF),
            progressColors: const ProgressBarColors(
              playedColor: Color(0xFF6C63FF),
              handleColor: Color(0xFF6C63FF),
            ),
          ),

          // Notes & Discussion tabs
          Expanded(
            child: DefaultTabController(
              length: 3,
              child: Column(
                children: [
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    child: const TabBar(
                      labelColor: Color(0xFF6C63FF),
                      unselectedLabelColor: Colors.grey,
                      tabs: [
                        Tab(text: 'Notes'),
                        Tab(text: 'Discussion'),
                        Tab(text: 'Resources'),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Theme.of(context).scaffoldBackgroundColor,
                      child: TabBarView(
                        children: [
                          // Notes Tab
                          ListView(
                            padding: const EdgeInsets.all(16),
                            children: [
                              _NoteCard(
                                title: 'Key Points',
                                content: '• Important concept 1\n• Important concept 2\n• Remember this formula',
                              ),
                              _NoteCard(
                                title: 'Summary',
                                content: 'This lesson covers the basics of the topic. Make sure to practice the exercises.',
                              ),
                            ],
                          ),
                          // Discussion Tab
                          const Center(
                            child: Text('Discussion coming soon...',
                                style: TextStyle(color: Colors.grey)),
                          ),
                          // Resources Tab
                          ListView(
                            padding: const EdgeInsets.all(16),
                            children: [
                              ListTile(
                                leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
                                title: const Text('Lesson Notes PDF'),
                                trailing: const Icon(Icons.download),
                                onTap: () {},
                              ),
                              ListTile(
                                leading: const Icon(Icons.quiz, color: Colors.orange),
                                title: const Text('Practice Quiz'),
                                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                                onTap: () {
                                  Navigator.pushNamed(context, '/quiz');
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

class _NoteCard extends StatelessWidget {
  final String title;
  final String content;

  const _NoteCard({required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              content,
              style: TextStyle(color: Colors.grey[600], height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
