import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/subscription_status.dart';
import '../providers/payment_controller.dart';
import '../providers/payment_providers.dart';

/// Reachable from Settings → "Subscription". Lets a student unlock
/// every paid course at once instead of buying one at a time -
/// `hasCourseAccessProvider` treats an active subscription the same
/// as owning each course individually.
class SubscriptionPlansScreen extends ConsumerWidget {
  const SubscriptionPlansScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final subscription = ref.watch(subscriptionStatusProvider).valueOrNull;
    final paymentState = ref.watch(paymentControllerProvider);
    final isLoading = paymentState.isLoading;

    ref.listen<AsyncValue<void>>(paymentControllerProvider, (prev, next) {
      next.whenOrNull(
        error: (err, _) => ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment failed: $err')),
        ),
      );
      if (prev is AsyncLoading && next is AsyncData) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Subscribed! All paid courses are unlocked.')),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Subscription')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (subscription?.isActive == true)
            Card(
              color: Colors.green.withOpacity(0.08),
              child: ListTile(
                leading: const Icon(Icons.verified, color: Colors.green),
                title: Text('${subscription!.plan.id[0].toUpperCase()}${subscription.plan.id.substring(1)} plan active'),
                subtitle: Text('Renews/expires ${subscription.expiresAt.split('T').first}'),
              ),
            ),
          const SizedBox(height: 12),
          _PlanCard(
            plan: SubscriptionPlan.monthly,
            isCurrent: subscription?.isActive == true &&
                subscription?.plan == SubscriptionPlan.monthly,
            isLoading: isLoading,
            onBuy: () => ref.read(paymentControllerProvider.notifier)
                .subscribe(SubscriptionPlan.monthly),
          ),
          const SizedBox(height: 12),
          _PlanCard(
            plan: SubscriptionPlan.yearly,
            isCurrent: subscription?.isActive == true &&
                subscription?.plan == SubscriptionPlan.yearly,
            isLoading: isLoading,
            badge: 'Best value',
            onBuy: () => ref.read(paymentControllerProvider.notifier)
                .subscribe(SubscriptionPlan.yearly),
          ),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final SubscriptionPlan plan;
  final bool isCurrent;
  final bool isLoading;
  final String? badge;
  final VoidCallback onBuy;

  const _PlanCard({
    required this.plan,
    required this.isCurrent,
    required this.isLoading,
    required this.onBuy,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final title = plan == SubscriptionPlan.monthly ? 'Monthly' : 'Yearly';
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(title,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF6C63FF).withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(badge!,
                              style: const TextStyle(
                                  fontSize: 11, color: Color(0xFF6C63FF))),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text('₹${plan.priceInr} / ${plan.durationDays >= 365 ? "year" : "month"}',
                      style: TextStyle(color: Colors.grey[600])),
                  const SizedBox(height: 4),
                  const Text('Unlocks every paid course',
                      style: TextStyle(fontSize: 12)),
                ],
              ),
            ),
            SizedBox(
              height: 40,
              child: ElevatedButton(
                onPressed: isCurrent || isLoading ? null : onBuy,
                child: Text(isCurrent ? 'Active' : 'Subscribe'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
