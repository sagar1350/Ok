import '../database/local_database.dart';
import '../models/sync_item.dart';
import 'queue_stream.dart';

class QueueManager {
  final box = LocalDatabase.syncBox;

  /// O(1) key lookup - box.put(item.id, item) already uses `id` as the
  /// Hive key, so this replaces a full box.values.any() scan with a
  /// direct containsKey check.
  bool exists(String id) => box.containsKey(id);

  Future<void> add(SyncItem item) async {
    if (exists(item.id)) return;
    await box.put(item.id, item);
    await refreshQueueCount();
  }

  List<SyncItem> pending() {
    return box.values
        .where((e) => e.status == "pending")
        .toList();
  }

  Future<void> remove(String id) async {
    await box.delete(id);
    await refreshQueueCount();
  }

  Future<void> markSynced(String id) async {
    final item = box.get(id);
    if (item == null) return;
    item.status = "synced";
    await item.save();
    await refreshQueueCount();
  }

  Future<void> markFailed(String id) async {
    final item = box.get(id);
    if (item == null) return;
    item.status = "failed";
    item.retryCount++;
    await item.save();
    await refreshQueueCount();
  }

  /// Pushes the current pending count to QueueStream so any
  /// StreamBuilder<int> listening (e.g. a "Pending Sync: N" label)
  /// updates immediately. Called automatically at the end of every
  /// mutation above, so callers never need to remember to trigger it
  /// themselves.
  Future<void> refreshQueueCount() async {
    QueueStream.instance.update(pending().length);
  }
}
