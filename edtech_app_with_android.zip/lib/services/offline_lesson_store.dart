import 'package:hive_flutter/hive_flutter.dart';

/// Local-only store for lessons a student has chosen to keep available
/// offline. Lives in the `downloads` Hive box that was already declared
/// (and cleared on logout) but never actually used until now.
///
/// Important honesty note: this stores lesson *metadata* (title,
/// course, video URL) so it can still be listed/browsed with no
/// connection - it does **not** download the video file itself.
/// `VideoPlayerScreen` streams from YouTube via `youtube_player_flutter`,
/// which has no offline playback mode, and YouTube's own terms don't
/// allow caching video streams outside their app anyway. A real "watch
/// this lesson offline" feature would need lesson videos hosted as
/// files Firebase/your own CDN controls, not YouTube URLs - that's a
/// content-pipeline change, not something this store can paper over.
/// The UI reflects this distinction: it's labelled "Save for offline
/// browsing", not "Download".
class OfflineLessonStore {
  static const _boxName = 'downloads';

  Box get _box => Hive.box(_boxName);

  String _key(String courseId, String lessonTitle) => '$courseId::$lessonTitle';

  bool isSaved(String courseId, String lessonTitle) {
    return _box.containsKey(_key(courseId, lessonTitle));
  }

  Future<void> save({
    required String courseId,
    required String courseTitle,
    required String lessonTitle,
    required String videoUrl,
  }) {
    return _box.put(_key(courseId, lessonTitle), {
      'courseId': courseId,
      'courseTitle': courseTitle,
      'lessonTitle': lessonTitle,
      'videoUrl': videoUrl,
      'savedAt': DateTime.now().toIso8601String(),
    });
  }

  Future<void> remove(String courseId, String lessonTitle) {
    return _box.delete(_key(courseId, lessonTitle));
  }

  /// All saved lessons, most-recently-saved first.
  List<Map<String, dynamic>> getAll() {
    final entries = _box.values
        .whereType<Map>()
        .map((m) => Map<String, dynamic>.from(m))
        .toList();
    entries.sort((a, b) =>
        (b['savedAt'] as String).compareTo(a['savedAt'] as String));
    return entries;
  }
}
