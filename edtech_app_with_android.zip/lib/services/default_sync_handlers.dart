import '../models/sync_item.dart';
import '../models/sync_type.dart';
import '../models/user_role.dart';
import '../repositories/quiz_repository.dart';
import '../repositories/user_repository.dart';
import '../utils/logger.dart';
import 'queue_processor.dart';

/// Builds a [SyncCallback] that dispatches each [SyncItem] to the real
/// repository call for its [SyncType]. Wire this into
/// `QueueProcessor(syncCallback: ...)` instead of a stub that always
/// returns `true`, e.g. via Riverpod:
///
/// ```dart
/// final queueProcessorProvider = Provider((ref) => QueueProcessor(
///   queueManager: QueueManager(),
///   syncCallback: buildRepositorySyncCallback(
///     quizRepository: ref.read(quizRepositoryProvider),
///     userRepository: ref.read(userRepositoryProvider),
///   ),
/// ));
/// ```
SyncCallback buildRepositorySyncCallback({
  required QuizRepository quizRepository,
  required UserRepository userRepository,
}) {
  return (SyncItem item) async {
    final type = SyncType.values.byName(item.type);
    final payload = item.payload;

    try {
      switch (type) {
        case SyncType.quiz:
          await quizRepository.submitResult(
            uid: payload['uid'] as String,
            quizId: payload['quizId'] as String,
            score: payload['score'] as int,
            total: payload['total'] as int,
          );
          return true;

        case SyncType.profile:
          await userRepository.setRole(
            payload['uid'] as String,
            UserRole.fromStorage(payload['role'] as String?),
          );
          return true;

        case SyncType.bookmark:
        case SyncType.notes:
        case SyncType.download:
          // In teeno ke liye koi backend repository method abhi
          // exist nahi karta (see PHASE5_NOTES.md) - false return
          // karo taaki item pending/retry mein hi rahe, "synced" na
          // ho jaye bina actually kuch sync kiye.
          return false;
      }
    } catch (e, st) {
      AppLogger.recordError(
        e,
        st,
        reason: 'Sync failed for ${type.name}:${item.id}',
      );
      return false;
    }
  };
}
