import 'dart:async';

import '../models/sync_item.dart';
import '../utils/logger.dart';
import 'queue_constants.dart';
import 'queue_manager.dart';
import 'retry_policy.dart';

/// Performs the actual sync call for one item. Return `true` on
/// success, `false` on failure - avoid throwing, since an uncaught
/// error here would skip the retry/mark-failed handling below
/// entirely (see `buildRepositorySyncCallback` in
/// `default_sync_handlers.dart` for a callback that already
/// catches/logs and converts errors to `false`).
typedef SyncCallback = Future<bool> Function(SyncItem item);

/// Reports (completed, total) after each item in a batch finishes
/// processing - regardless of whether it synced, got queued for
/// retry, or was dropped as a dead letter, so `completed` always
/// reaches `total` by the end of a batch. Not present before Phase 9;
/// `QueueProcessor` had no way to report progress, so nothing fed
/// `SyncStream`/`SyncProgress` (see `sync/sync_controller.dart`).
typedef SyncProgressCallback = void Function(int completed, int total);

class QueueProcessor {
  QueueProcessor({
    required this.queueManager,
    required this.syncCallback,
    this.onProgress,
  });

  final QueueManager queueManager;
  final SyncCallback syncCallback;
  final SyncProgressCallback? onProgress;

  bool _isRunning = false;

  /// Processes up to [QueueConstants.batchSize] pending items per
  /// call. Re-entrant calls while a batch is already running are a
  /// no-op instead of racing the same items.
  Future<void> processQueue() async {
    if (_isRunning) return;
    _isRunning = true;

    try {
      final items =
          queueManager.pending().take(QueueConstants.batchSize).toList();

      var completed = 0;

      for (final item in items) {
        final success = await syncCallback(item);

        if (success) {
          await queueManager.markSynced(item.id);
        } else if (RetryPolicy.canRetry(item.retryCount)) {
          // Retries baaki hain - retryCount badhao, status "pending"
          // hi rehne do. QueueManager.markFailed() status ko "failed"
          // set kar deta hai, aur QueueManager.pending() sirf
          // status == "pending" wale items return karta hai -
          // markFailed() yahan bulane se yeh item permanently
          // pending() se bahar ho jaata aur RetryPolicy allow karne
          // ke bawajood kabhi retry na hota.
          item.retryCount++;
          await item.save();

          // RetryPolicy.nextDelay() ko yahan *await* nahi kar rahe -
          // ek failed item ka 2s/4s/8s... backoff poore batch ke
          // baaki items ko block kar deta (agla item tab tak wait
          // karta). Yeh delay sirf itna signal karta hai "itni jaldi
          // dobara mat try karo" - agli processQueue() call (jab bhi
          // aaye, e.g. connectivity restore) is item ko turant retry
          // kar degi. Strict per-item backoff chahiye to `createdAt`/
          // `retryCount` se elapsed time check karo loop shuru karne
          // se pehle, delay ke andar poora batch rokne ke bajaye.
        } else {
          // Retries khatam (retryCount >= QueueConstants.maxRetry) -
          // ab is item ko box mein "failed" status ke saath hamesha
          // ke liye baithne dene ke bajaye seedha remove kar rahe
          // hain, taaki sync_queue box waqt ke saath permanently-
          // broken items se bloat na ho. Removal se pehle log zaroor
          // karo - yeh permanent data loss hai (ek baar remove hone
          // ke baad, agar kal backend fix bhi ho jaye jo isse retry
          // kara sakta, wo mauka bhi chala gaya).
          AppLogger.recordError(
            StateError('Sync item exhausted retries and was dropped'),
            StackTrace.current,
            reason:
                'Dropping ${item.type}:${item.id} after ${item.retryCount} retries',
          );
          await queueManager.remove(item.id);
        }

        completed++;
        onProgress?.call(completed, items.length);
      }
    } finally {
      _isRunning = false;
    }
  }
}
