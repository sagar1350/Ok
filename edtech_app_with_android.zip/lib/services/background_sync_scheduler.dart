import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:workmanager/workmanager.dart';

import '../database/local_database.dart';
import '../firebase_options.dart';
import '../repositories/impl/firestore_quiz_repository.dart';
import '../repositories/impl/firestore_user_repository.dart';
import '../sync/sync_service.dart' as sync;
import '../utils/logger.dart';
import 'default_sync_handlers.dart';
import 'queue_manager.dart';
import 'queue_processor.dart';

/// OS-level scheduling for the sync pipeline that already exists
/// (QueueManager -> QueueProcessor -> SyncService in lib/sync +
/// lib/services). Everything up to this point only ran while the app
/// process was alive: SyncScheduler's Timer.periodic (lib/sync) and
/// ConnectivitySync's listener both die the moment the app is
/// backgrounded/killed, which is fine for "sync while I'm using the
/// app" but not for "flush the queue overnight so it's not sitting on
/// a student's phone for days." Workmanager fills that specific gap -
/// it does NOT replace SyncScheduler/ConnectivitySync, which still
/// handle the in-app cases.
///
/// Deliberately does not reintroduce a second `SyncService` class or a
/// raw `http`/`SharedPreferences` sync path - `lib/sync/sync_service.dart`
/// already exists and does this by delegating to QueueManager/
/// QueueProcessor against the real Hive-backed SyncItem queue. This
/// file's only job is to construct that same object graph inside the
/// background isolate WorkManager runs `callbackDispatcher` in (a
/// separate isolate on Android, so Firebase/Hive have to be
/// initialized again there - nothing carries over from the running app).
class BackgroundSyncScheduler {
  BackgroundSyncScheduler._();

  static const String periodicTaskName = 'background_periodic_sync';
  static const String immediateTaskName = 'background_immediate_sync';

  /// Call once from main.dart, after the usual startup sequence.
  /// Registering the periodic task is safe to call every app launch -
  /// `existingWorkPolicy: keep` below means it's a no-op if one is
  /// already scheduled, rather than resetting the 20-minute window
  /// each time the app opens.
  static Future<void> initialize() async {
    try {
      await Workmanager().initialize(
        callbackDispatcher,
        isInDebugMode: kDebugMode,
      );

      await Workmanager().registerPeriodicTask(
        periodicTaskName,
        periodicTaskName,
        // Android enforces a 15-minute floor regardless of what's
        // passed here; 20 leaves a little headroom above that floor.
        frequency: const Duration(minutes: 20),
        constraints: Constraints(
          networkType: NetworkType.connected,
          requiresBatteryNotLow: true,
        ),
        existingWorkPolicy: ExistingWorkPolicy.keep,
      );
    } catch (e, st) {
      // Same pattern as the rest of main.dart's startup: log and keep
      // going rather than blocking app launch on a background-sync
      // feature. Workmanager is unsupported on some platforms (web,
      // desktop) - this keeps it from crashing app boot there too.
      AppLogger.recordError(e, st, reason: 'BackgroundSyncScheduler.initialize failed');
    }
  }

  /// For a manual "Sync now" action (see SettingsScreen) - runs once,
  /// as soon as the OS will allow it, separately from the periodic
  /// schedule above.
  static Future<void> triggerImmediateSync() async {
    try {
      await Workmanager().registerOneOffTask(
        immediateTaskName,
        immediateTaskName,
        constraints: Constraints(networkType: NetworkType.connected),
        existingWorkPolicy: ExistingWorkPolicy.replace,
      );
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'BackgroundSyncScheduler.triggerImmediateSync failed');
    }
  }

  static Future<void> cancelAll() async {
    try {
      await Workmanager().cancelAll();
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'BackgroundSyncScheduler.cancelAll failed');
    }
  }
}

/// Runs in a separate background isolate (Android) - none of the
/// running app's state (ProviderScope, an already-initialized Firebase
/// app, an already-open Hive box) is available here, so the minimum
/// needed to call SyncService.startSync() has to be brought up from
/// scratch, same as main.dart does on a cold app launch.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      }

      await LocalDatabase.init();

      final queueManager = QueueManager();
      final processor = QueueProcessor(
        queueManager: queueManager,
        syncCallback: buildRepositorySyncCallback(
          quizRepository: FirestoreQuizRepository(),
          userRepository: FirestoreUserRepository(),
        ),
      );
      final syncService = sync.SyncService(
        queueManager: queueManager,
        processor: processor,
      );

      await syncService.startSync();
      return Future.value(true);
    } catch (e, st) {
      // Returning false tells Workmanager to apply its retry/backoff
      // policy for this task rather than treating it as done -
      // individual item retries are still governed separately by
      // RetryPolicy inside QueueProcessor.
      AppLogger.recordError(e, st, reason: 'Background sync task ($taskName) failed');
      return Future.value(false);
    }
  });
}
