import 'dart:async';

class QueueStream {
  QueueStream._();

  static final QueueStream instance = QueueStream._();

  final StreamController<int> _controller =
      StreamController<int>.broadcast();

  Stream<int> get stream => _controller.stream;

  void update(int pendingCount) {
    if (!_controller.isClosed) {
      _controller.add(pendingCount);
    }
  }

  void dispose() {
    _controller.close();
  }
}
