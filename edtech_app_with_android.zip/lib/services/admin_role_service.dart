import 'package:cloud_functions/cloud_functions.dart';

/// Calls the `setAdminRole` Cloud Function (functions/index.js) - the
/// only path that can grant or revoke the `admin` custom claim.
///
/// The function itself re-checks that the caller is already an admin
/// (via their ID token's claim), so this class isn't a security
/// boundary by itself - it's just a typed wrapper. A non-admin caller
/// gets a `permission-denied` FirebaseFunctionsException back from
/// Firebase regardless of whether this class is used correctly.
///
/// Not yet wired into an admin dashboard screen - lib/admin still
/// runs on mock data (see README). This exists so that whenever the
/// User Management screen is connected to real data, "make this user
/// an admin" has a real, already-secured call to reach for instead of
/// writing role: 'admin' to Firestore directly (which firestore.rules
/// will reject from the client on purpose).
class AdminRoleService {
  final FirebaseFunctions _functions;

  AdminRoleService({FirebaseFunctions? functions})
      : _functions = functions ?? FirebaseFunctions.instance;

  /// Throws [FirebaseFunctionsException] on failure - e.g. code
  /// 'permission-denied' if the caller isn't an admin, 'not-found' if
  /// [uid] doesn't exist, or 'failed-precondition' if an admin tries
  /// to revoke their own access (must be done by a different admin).
  Future<void> setAdminRole({required String uid, required bool makeAdmin}) async {
    await _functions.httpsCallable('setAdminRole').call({
      'uid': uid,
      'makeAdmin': makeAdmin,
    });
  }
}
