class QueueConstants {
  static const int maxRetry = 5;
  static const int batchSize = 20;
}
