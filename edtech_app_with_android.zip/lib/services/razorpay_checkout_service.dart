import 'dart:async';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../repositories/payment_repository.dart';

/// What a completed Razorpay checkout hands back - exactly the three
/// fields `PaymentRepository.verifyPayment` needs to confirm the
/// signature server-side.
class RazorpayCheckoutResult {
  final String razorpayOrderId;
  final String razorpayPaymentId;
  final String razorpaySignature;

  const RazorpayCheckoutResult({
    required this.razorpayOrderId,
    required this.razorpayPaymentId,
    required this.razorpaySignature,
  });
}

class RazorpayPaymentCancelled implements Exception {
  final String message;
  RazorpayPaymentCancelled(this.message);
  @override
  String toString() => message;
}

/// `razorpay_flutter`'s `Razorpay` object reports success/failure
/// through event callbacks rather than a Future, and its checkout
/// sheet is a one-shot thing (open once, get one event, throw it
/// away) - this wraps that in a `Future` so callers (the payment
/// controller) can just `await` a checkout the same way they await
/// everything else, and creates a fresh `Razorpay` instance per call
/// so a second purchase in the same session isn't listening to a
/// disposed one.
class RazorpayCheckoutService {
  Future<RazorpayCheckoutResult> open({
    required CheckoutOrder order,
    required String contactPhone,
    String? contactName,
  }) {
    final razorpay = Razorpay();
    final completer = Completer<RazorpayCheckoutResult>();

    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, (PaymentSuccessResponse r) {
      if (!completer.isCompleted) {
        completer.complete(RazorpayCheckoutResult(
          razorpayOrderId: r.orderId ?? order.razorpayOrderId,
          razorpayPaymentId: r.paymentId ?? '',
          razorpaySignature: r.signature ?? '',
        ));
      }
      razorpay.clear();
    });

    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, (PaymentFailureResponse r) {
      if (!completer.isCompleted) {
        completer.completeError(
          RazorpayPaymentCancelled(r.message ?? 'Payment was not completed.'),
        );
      }
      razorpay.clear();
    });

    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, (ExternalWalletResponse r) {
      // User picked a wallet Razorpay hands off to externally (e.g.
      // Paytm) - not success or failure yet from our side, so leave
      // the completer pending; EVENT_PAYMENT_SUCCESS/ERROR still
      // fires once that flow resolves.
    });

    razorpay.open({
      'key': order.razorpayKeyId,
      'order_id': order.razorpayOrderId,
      'amount': order.amountInPaise,
      'currency': order.currency,
      'name': 'EdTech App',
      'description': order.description,
      'prefill': {
        'contact': contactPhone,
        if (contactName != null) 'name': contactName,
      },
      'theme': {'color': '#6C63FF'},
    });

    return completer.future;
  }
}
