class RetryPolicy {
  static bool canRetry(int retryCount) {
    return retryCount < 5;
  }

  static Duration nextDelay(int retryCount) {
    return Duration(seconds: 1 << retryCount); // 2,4,8,16...
  }
}
