import 'dart:convert';
import 'dart:io' show Platform;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../firebase_options.dart';
import '../utils/logger.dart';

/// Push notifications (FCM) + local notification display + deep-link
/// navigation on tap.
///
/// Adapted from a pasted FCM demo rather than dropped in as-is - the
/// demo assumed a route table (`/home`, `/profile`, `/post/:id`,
/// `/chat/:id`) that doesn't exist in this app. This app's real routes
/// live in `app.dart`'s `_generateRoute` (`/course-detail`, `/quiz`,
/// `/dashboard`, `/saved-lessons`, `/settings`, ...), so deep links are
/// mapped to those instead. `/video` is deliberately NOT a deep-link
/// target - `VideoPlayerScreen` requires a full `Course` object as a
/// route argument (see app.dart), which a push payload can't carry;
/// linking to `/course-detail` and letting the student pick the lesson
/// from there is the closest safe equivalent.
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  /// Set this to the same key passed to `MaterialApp(navigatorKey: ...)`
  /// in app.dart - needed so a notification tap from a
  /// backgrounded/terminated app can navigate before any screen's
  /// `BuildContext` exists yet.
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static const String _pendingDeepLinkKey = 'pending_deep_link';
  static const String _channelId = 'default_channel';

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    try {
      await _requestPermission();
      await _initLocalNotifications();

      FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
      FirebaseMessaging.onMessageOpenedApp.listen(
        (message) => _navigate(message.data),
      );
      _messaging.onTokenRefresh.listen(_saveToken);

      final token = await _messaging.getToken();
      if (token != null) await _saveToken(token);

      final initialMessage = await _messaging.getInitialMessage();
      if (initialMessage != null) _navigate(initialMessage.data);

      await processPendingDeepLink();
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'NotificationService.initialize failed');
    }
  }

  Future<void> _requestPermission() async {
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    AppLogger.info('Notification permission: ${settings.authorizationStatus}');
  }

  Future<void> _initLocalNotifications() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _localNotifications.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (response) {
        if (response.payload == null) return;
        final data = jsonDecode(response.payload!) as Map<String, dynamic>;
        _navigate(data);
      },
    );
  }

  void _handleForegroundMessage(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;

    _localNotifications.show(
      notification.hashCode,
      notification.title,
      notification.body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          'Default Notifications',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true),
      ),
      payload: jsonEncode(message.data),
    );
  }

  /// Deep-link a notification's `data` payload (expects a `screen` key
  /// plus whatever id that screen needs) to one of `app.dart`'s real
  /// routes. Anything unrecognized (or missing required args, e.g.
  /// `course-detail` without a `courseId`) falls back to `/dashboard`
  /// rather than a broken navigation attempt - same "don't crash on bad
  /// input" approach as `_generateRoute`'s own try/catch.
  void _navigate(Map<String, dynamic> data) {
    final state = navigatorKey.currentState;
    if (state == null) {
      // No navigator yet (cold start, first frame not built) - stash
      // it and let processPendingDeepLink() run it once the app's up.
      _storePendingDeepLink(data);
      return;
    }

    final screen = data['screen'] as String?;
    switch (screen) {
      case 'course-detail':
        final courseId = data['courseId'] as String?;
        if (courseId == null || courseId.isEmpty) {
          state.pushNamedAndRemoveUntil('/dashboard', (r) => false);
          return;
        }
        state.pushNamed('/course-detail', arguments: courseId);
        break;
      case 'quiz':
        state.pushNamed('/quiz');
        break;
      case 'saved-lessons':
        state.pushNamed('/saved-lessons');
        break;
      case 'settings':
        state.pushNamed('/settings');
        break;
      default:
        state.pushNamedAndRemoveUntil('/dashboard', (r) => false);
    }
  }

  Future<void> _storePendingDeepLink(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_pendingDeepLinkKey, jsonEncode(data));
  }

  /// Call once a navigator exists (e.g. from splash/dashboard's
  /// initState) to replay a deep link that arrived before the app had
  /// somewhere to navigate to.
  Future<void> processPendingDeepLink() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_pendingDeepLinkKey);
    if (stored == null) return;
    await prefs.remove(_pendingDeepLinkKey);
    _navigate(jsonDecode(stored) as Map<String, dynamic>);
  }

  /// Saved at `users/{uid}/deviceTokens/{token}` - one doc per device,
  /// not a single field on the profile, so a user signed in on more
  /// than one device gets pushes on all of them (a flat field would
  /// only ever remember the most recently-refreshed token). Skipped
  /// silently if nobody's signed in yet (token still arrives
  /// pre-login; nothing to attach it to until
  /// `createProfileIfMissing` runs).
  Future<void> _saveToken(String token) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('deviceTokens')
          .doc(token)
          .set({
        'token': token,
        'platform': _platformLabel,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'Saving FCM token failed');
    }
  }

  String get _platformLabel {
    if (kIsWeb) return 'web';
    return Platform.isIOS ? 'ios' : 'android';
  }

  Future<void> subscribeToTopic(String topic) => _messaging.subscribeToTopic(topic);

  Future<void> unsubscribeFromTopic(String topic) =>
      _messaging.unsubscribeFromTopic(topic);

  /// Call on logout (alongside the Hive-clearing/Crashlytics-uid-clearing
  /// `AuthNotifier.logout` already does) so the next signed-in user on a
  /// shared device doesn't keep receiving the previous user's pushes.
  /// Removes only *this* device's token doc - other devices this user
  /// is signed into keep working.
  Future<void> deleteToken() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      final token = await _messaging.getToken();
      if (uid != null && token != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('deviceTokens')
            .doc(token)
            .delete();
      }
      await _messaging.deleteToken();
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'Deleting FCM token failed');
    }
  }
}

/// Background message handler - must be a top-level (or static)
/// function per the firebase_messaging plugin contract, called from a
/// separate isolate when a push arrives while the app is fully
/// terminated. Registered from main.dart via
/// `FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler)`.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  if (Firebase.apps.isEmpty) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  }

  // Local-notification display for a terminated-app background message
  // is intentionally NOT done here (unlike the pasted version) - FCM
  // notification-type payloads are already surfaced by the OS itself in
  // this state without any app code running; showing a second local
  // notification on top would duplicate it. This handler's only job is
  // logging + stashing the deep link for processPendingDeepLink() to
  // pick up once the app is actually opened.
  // ignore: avoid_print
  print('Background message received: ${message.messageId}');
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString(
    'pending_deep_link',
    jsonEncode(message.data),
  );
}
