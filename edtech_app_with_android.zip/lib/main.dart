import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_performance/firebase_performance.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'app.dart';
import 'firebase_options.dart';
import 'utils/logger.dart';
import 'utils/config_check.dart';
import 'utils/app_check_init.dart';
import 'database/local_database.dart';
import 'services/queue_manager.dart';
import 'services/background_sync_scheduler.dart';
import 'services/notification_service.dart';
import 'security/device_integrity_checker.dart';

void main() {
  // Sab kuch runZonedGuarded ke andar rakha hai taaki koi bhi uncaught
  // async error crash na kare, balki log ho jaye (Crashlytics/Sentry ke
  // liye hook yahin add karna - AppLogger.recordError dekho).
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();

    // Flutter framework errors (widget build errors, layout errors, etc.)
    // ko bhi catch karke log karo instead of silently failing in release.
    FlutterError.onError = (FlutterErrorDetails details) {
      FlutterError.presentError(details);
      AppLogger.recordError(details.exception, details.stack, fatal: true);
    };

    bool firebaseReady = false;
    String? firebaseInitError;

    try {
      // Agar firebase_options.dart mein abhi bhi placeholder values hain
      // (YOUR_API_KEY_HERE waghera), to Firebase.initializeApp() ek raw,
      // confusing exception throw karta hai jo app ko crash kar deta hai.
      // Isliye pehle validate karo aur ek clear message do.
      if (!isFirebaseConfigured(DefaultFirebaseOptions.currentPlatform)) {
        throw StateError(
          'Firebase is not configured yet. Replace the placeholder values '
          'in lib/firebase_options.dart with real values from your Firebase '
          'project (Project settings > General > Your apps), or run '
          '`flutterfire configure`.',
        );
      }

      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      firebaseReady = true;

      // Crashlytics ab available hai - AppLogger ke saare future
      // recordError/info calls (including the runZonedGuarded handler
      // and FlutterError.onError below) Crashlytics ko bhi forward
      // honge. Isse pehle recordError sirf console pe print karta tha,
      // taaki Firebase init hone se pehle ke errors crash na karein
      // Crashlytics missing hone ki wajah se.
      await AppLogger.attachCrashlytics();

      // Performance Monitoring - network requests (Firestore) aur
      // screen rendering auto-instrument ho jaate hain bina extra code
      // ke; custom traces (see utils/perf_trace.dart) sirf specific
      // operations ke liye hain jahan ek dashboard number actually
      // useful hai. Debug builds mein off, taaki local dev ka data
      // production dashboard mein na mix ho - same reasoning as
      // Crashlytics collection above.
      try {
        await FirebasePerformance.instance
            .setPerformanceCollectionEnabled(!kDebugMode);
      } catch (e, st) {
        AppLogger.recordError(e, st, reason: 'Performance Monitoring setup failed');
      }

      // Firestore already persists to disk by default on mobile, but the
      // default cache cap (40MB) is small for a course catalog with
      // curriculum/video metadata plus a student's own progress - once
      // it fills up, older cached documents get evicted and silently
      // stop being available offline. Uncapping it trades disk space
      // (which is cheap) for offline reliability (which matters more
      // for a student on an unreliable connection).
      //
      // Native iOS/Android SDKs have deprecated persistenceEnabled/
      // cacheSizeBytes in favor of a `cacheSettings`/`PersistentCacheSettings`
      // API - check the cloud_firestore changelog when upgrading, since
      // at the pinned version here the Flutter plugin's Settings class
      // only exposes the fields below.
      FirebaseFirestore.instance.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );

      // Firebase is up - lock it down before anything calls Auth/Firestore.
      await activateAppCheck();

      // Background message handler must be registered here, at
      // top-level main() before runApp - the plugin dispatches
      // terminated-app messages to this exact top-level function in a
      // separate isolate, so it can't be a NotificationService instance
      // method (see notification_service.dart's comment on it).
      FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
      await NotificationService().initialize();
    } catch (e, st) {
      firebaseInitError = e.toString();
      AppLogger.recordError(e, st);
      // Note: app abhi bhi launch hogi, but auth/course/quiz screens jo
      // Firebase pe depend karte hain unhe ConfigErrorScreen dikhega
      // (crash hone ki jagah).
    }

    // Local storage start karo - yeh Firebase pe depend nahi karta.
    // LocalDatabase.init() ab settings/downloads (Phase 3/4) ke saath
    // saath sync_queue box (Phase 5 - offline sync) bhi khol deta hai,
    // aur SyncItemAdapter register karta hai.
    try {
      await LocalDatabase.init();
      // Box khulte hi ek baar QueueStream ko current pending count
      // bhej do - warna agar pichle session se items already queued
      // pade hain, PendingSyncIndicator tab tak 0 dikhata rahega jab
      // tak koi naya mutation (add/sync/remove) na ho.
      await QueueManager().refreshQueueCount();
    } catch (e, st) {
      AppLogger.recordError(e, st);
    }

    // Workmanager registration - purely OS-level scheduling setup, so
    // this doesn't depend on firebaseReady/LocalDatabase having
    // succeeded above. The actual sync work only runs later, in
    // callbackDispatcher's own isolate (see background_sync_scheduler.dart),
    // which brings up its own Firebase/Hive rather than relying on
    // what was just initialized in this isolate.
    await BackgroundSyncScheduler.initialize();

    // Advisory-only - logs flags (rooted/emulator-like signals) for
    // later pattern-spotting, doesn't block anything. See
    // device_integrity_checker.dart's doc comment for why this stops
    // short of the pasted code's auto-wipe-and-exit behaviour.
    await DeviceIntegrityChecker.check();

    // App ko run karo
    runApp(
      ProviderScope(
        child: MyApp(
          firebaseReady: firebaseReady,
          firebaseInitError: firebaseInitError,
        ),
      ),
    );
  }, (Object error, StackTrace stack) {
    // Koi bhi error jo upar wale try/catch se bhi bach gaya
    AppLogger.recordError(error, stack, fatal: true);
    if (kDebugMode) {
      // Debug build mein terminal pe dikhna chahiye
      // ignore: avoid_print
      print('Uncaught error: $error\n$stack');
    }
  });
}
