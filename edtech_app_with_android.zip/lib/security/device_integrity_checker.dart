import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';

import '../utils/logger.dart';

/// Best-effort, advisory-only signal for "this looks like a rooted
/// device or an emulator" - reported via `AppLogger.info` so it shows
/// up in Crashlytics breadcrumbs/logs for pattern-spotting (e.g. a
/// spike in quiz submissions from flagged devices), NOT wired to any
/// automatic block/wipe/exit. See PHASE12_NOTES.md for why that part of
/// the pasted `SecurityChecker` was deliberately not carried over -
/// it's a product decision, not a technical one, and this app's own
/// localization (Hindi support, low-end-device-friendly patterns
/// elsewhere in the codebase) suggests a meaningful share of genuine
/// students are on rooted/custom-ROM budget devices, not just people
/// trying to cheat.
///
/// Only device_info_plus heuristics are used - the pasted version's
/// file-path/su-binary scanning and `Process.run('pm', ['list', ...])`
/// package queries were dropped: modern Android (10+) sandboxes app
/// filesystem access and requires the `QUERY_ALL_PACKAGES` permission
/// (itself a Play Store red flag) to enumerate other apps at all, so
/// most of those checks silently find nothing on a real modern device
/// regardless of root status - false confidence, not a working check.
class DeviceIntegrityChecker {
  static Future<DeviceIntegrityReport> check() async {
    final flags = <String>[];

    try {
      final info = DeviceInfoPlugin();

      if (Platform.isAndroid) {
        final android = await info.androidInfo;
        if (!android.isPhysicalDevice) flags.add('not a physical device');

        final fingerprint = android.fingerprint.toLowerCase();
        for (final marker in ['generic', 'sdk_gphone', 'vbox', 'ranchu']) {
          if (fingerprint.contains(marker)) {
            flags.add('emulator-like build fingerprint');
            break;
          }
        }

        final hardware = android.hardware.toLowerCase();
        for (final marker in ['goldfish', 'ranchu', 'vbox86']) {
          if (hardware.contains(marker)) {
            flags.add('emulator-like hardware ($hardware)');
            break;
          }
        }
      } else if (Platform.isIOS) {
        final ios = await info.iosInfo;
        if (!ios.isPhysicalDevice) flags.add('iOS Simulator');
      }
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'DeviceIntegrityChecker.check failed');
    }

    final report = DeviceIntegrityReport(flags: flags);
    if (flags.isNotEmpty) {
      AppLogger.info('Device integrity flags: ${flags.join(', ')}');
    }
    if (kDebugMode) {
      // ignore: avoid_print
      print('[DeviceIntegrityChecker] $report');
    }
    return report;
  }
}

class DeviceIntegrityReport {
  final List<String> flags;
  DeviceIntegrityReport({required this.flags});

  bool get looksSuspicious => flags.isNotEmpty;

  @override
  String toString() =>
      looksSuspicious ? 'flagged: ${flags.join(', ')}' : 'no flags';
}
