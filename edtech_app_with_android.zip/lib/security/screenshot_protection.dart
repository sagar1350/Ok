import 'package:flutter/material.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';

import '../utils/logger.dart';

/// FLAG_SECURE on Android - blocks screenshots, screen recording, and
/// hides the screen's content in the recent-apps thumbnail. No iOS
/// equivalent exists (the pasted code's `isScreenRecording()` and any
/// notion of an iOS "blur on background" flag were dropped - iOS has no
/// public API to block screenshots at all, only a
/// `UIApplicationUserDidTakeScreenshotNotification` you can react to
/// *after* the fact, which isn't prevention and wasn't part of what was
/// pasted anyway).
class ScreenshotProtection {
  static Future<void> enable() async {
    try {
      await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'ScreenshotProtection.enable failed');
    }
  }

  static Future<void> disable() async {
    try {
      await FlutterWindowManager.clearFlags(FlutterWindowManager.FLAG_SECURE);
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'ScreenshotProtection.disable failed');
    }
  }
}

/// Wraps a single screen with FLAG_SECURE for as long as it's on
/// screen, clearing it on dispose so screenshots work normally
/// elsewhere in the app. Intended for `/quiz` (exam integrity - a
/// screenshotted question bank is the actual threat model for a course
/// app, unlike generic "screenshot protection" for its own sake) and
/// `/video` (licensed lesson content) - wired at the route level in
/// `app.dart` rather than inside `QuizScreen`/`VideoPlayerScreen`
/// themselves, so those screens don't need to know this exists.
///
/// Deliberately does NOT re-enable on `AppLifecycleState.resumed` the
/// way the pasted version did for every state transition - FLAG_SECURE
/// is a window flag that persists on its own through background/
/// foreground cycles without needing to be reapplied; the only actual
/// transitions that matter are "this screen mounted" (enable) and "this
/// screen unmounted, possibly navigating to a non-sensitive screen"
/// (disable).
class SecureScreen extends StatefulWidget {
  final Widget child;

  const SecureScreen({super.key, required this.child});

  @override
  State<SecureScreen> createState() => _SecureScreenState();
}

class _SecureScreenState extends State<SecureScreen> {
  @override
  void initState() {
    super.initState();
    ScreenshotProtection.enable();
  }

  @override
  void dispose() {
    ScreenshotProtection.disable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
