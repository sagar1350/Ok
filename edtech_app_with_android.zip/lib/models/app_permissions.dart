import 'user_role.dart';

/// Granular per-role capability flags, derived from [UserRole].
///
/// ## This is a UI convenience layer, NOT a security boundary
/// Every flag here is computed from the Firestore `role` field, which
/// (except for `admin`) is entirely self-reported by the client - see
/// the `isSelfServiceRole` comment in `firestore.rules`. Use this to
/// decide what buttons/screens to *show*, never to decide what a
/// write is *allowed* to do - that's Firestore rules' job, and for
/// anything genuinely admin-gated, `isAdminProvider`'s job (the real
/// `admin` custom claim), not this class.
///
/// Concretely: `canManageUsers` being true is a reason to render a
/// "Manage users" button. It is not, by itself, a reason to trust
/// that the resulting Firestore write will succeed - the rules (or a
/// Cloud Function) still have the final say.
class AppPermissions {
  final UserRole role;

  const AppPermissions(this.role);

  // ---- Admin-level UI ----
  // Mirrors what an admin-claim-holding user should see. Actual data
  // access for these features must still go through isAdminProvider/
  // the setAdminRole-issued claim, not this flag.
  bool get canManageUsers => role.isAdmin;
  bool get canManageSystemSettings => role.isAdmin;
  bool get canViewAuditLog => role.isAdmin;

  // ---- Teacher-level UI (teacher and admin) ----
  // None of these have server-side enforcement yet - the app doesn't
  // have a teacher-authoring backend today (see README's "Catalog
  // content... only trusted server-side writes" note on `courses`).
  // These flags exist so teacher-facing screens have something
  // principled to gate on once that backend lands, instead of ad hoc
  // role checks scattered around.
  bool get canCreateCourses => role.hasMinimumRole(UserRole.teacher);
  bool get canGradeStudents => role.hasMinimumRole(UserRole.teacher);
  bool get canViewClassAnalytics => role.hasMinimumRole(UserRole.teacher);

  // ---- Parent-level UI ----
  bool get canViewChildProgress => role == UserRole.parent;

  // ---- Everyone signed in ----
  bool get canEnrollInCourses => true;
  bool get canTakeQuizzes => true;
  bool get canViewOwnProgress => true;
}
