/// An enrollment/progress record, stored at
/// `users/{uid}/enrollments/{courseId}` in Firestore.
class CourseProgress {
  final String courseId;
  final String courseTitle;
  final String iconKey;
  final String colorKey;
  final String lastLessonLabel;
  final double progressPercent; // 0.0 - 1.0
  final DateTime? lastAccessedAt;

  const CourseProgress({
    required this.courseId,
    required this.courseTitle,
    required this.iconKey,
    required this.colorKey,
    required this.lastLessonLabel,
    required this.progressPercent,
    this.lastAccessedAt,
  });

  factory CourseProgress.fromMap(String courseId, Map<String, dynamic> map) {
    return CourseProgress(
      courseId: courseId,
      courseTitle: map['courseTitle'] as String? ?? 'Untitled course',
      iconKey: map['iconKey'] as String? ?? 'code',
      colorKey: map['colorKey'] as String? ?? 'deepPurple',
      lastLessonLabel: map['lastLessonLabel'] as String? ?? '',
      progressPercent: (map['progressPercent'] as num?)?.toDouble() ?? 0,
      lastAccessedAt: map['lastAccessedAt'] != null
          ? DateTime.tryParse(map['lastAccessedAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'courseTitle': courseTitle,
        'iconKey': iconKey,
        'colorKey': colorKey,
        'lastLessonLabel': lastLessonLabel,
        'progressPercent': progressPercent,
        'lastAccessedAt': (lastAccessedAt ?? DateTime.now()).toIso8601String(),
      };
}
