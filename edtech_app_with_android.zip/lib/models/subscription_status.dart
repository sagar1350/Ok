/// The two subscription plans on offer. Prices live here (mirrored
/// server-side in `functions/index.js`) purely for display - the
/// client's price is never trusted for the actual charge. See
/// `createOrder` in `functions/index.js` for the source of truth.
enum SubscriptionPlan { monthly, yearly }

extension SubscriptionPlanX on SubscriptionPlan {
  String get id => this == SubscriptionPlan.monthly ? 'monthly' : 'yearly';

  int get priceInr => this == SubscriptionPlan.monthly ? 199 : 1499;

  int get durationDays => this == SubscriptionPlan.monthly ? 30 : 365;

  static SubscriptionPlan fromId(String id) {
    return id == 'yearly' ? SubscriptionPlan.yearly : SubscriptionPlan.monthly;
  }
}

/// A user's subscription state, stored as the single doc
/// `users/{uid}/subscription/current` in Firestore. Only written by
/// the `verifyPayment` Cloud Function (or the Razorpay webhook) -
/// never by the client, same as `CoursePurchase`.
class SubscriptionStatus {
  final SubscriptionPlan plan;
  final String status; // 'active' | 'expired' | 'cancelled'
  final String startedAt; // ISO 8601
  final String expiresAt; // ISO 8601

  const SubscriptionStatus({
    required this.plan,
    required this.status,
    required this.startedAt,
    required this.expiresAt,
  });

  /// Whether this grants access right now. Checked against the local
  /// clock for UI purposes only - `hasCourseAccess` treats it as
  /// advisory and a stale/rolled-back client clock can't forge access
  /// to anything server-side ever checks (there isn't one yet; this
  /// app has no paid server API beyond the payment functions
  /// themselves).
  bool get isActive =>
      status == 'active' && DateTime.tryParse(expiresAt)?.isAfter(DateTime.now()) == true;

  factory SubscriptionStatus.fromMap(Map<String, dynamic> map) {
    return SubscriptionStatus(
      plan: SubscriptionPlanX.fromId(map['plan'] as String? ?? 'monthly'),
      status: map['status'] as String? ?? 'expired',
      startedAt: map['startedAt'] as String? ?? '',
      expiresAt: map['expiresAt'] as String? ?? '',
    );
  }
}
