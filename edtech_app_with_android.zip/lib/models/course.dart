import 'course_chapter.dart';

/// A course document, stored at `courses/{courseId}` in Firestore.
///
/// `iconKey` and `colorKey` are small string identifiers (not raw Flutter
/// types) so this model has no Flutter/UI dependency and the screens
/// decide how to render them - see `CourseVisuals` in course_list_screen.
class Course {
  final String id;
  final String title;
  final String subject;
  final String level;
  final String description;
  final String iconKey;
  final String colorKey;
  final int lessonsCount;
  final double durationHours;
  final double rating;
  final int studentsCount;
  final int priceInr; // 0 means free
  final List<String> whatYoullLearn;
  final List<CourseChapter> curriculum;

  /// 'draft' | 'published' | 'archived' - set from the admin dashboard
  /// (Module 3). Defaults to 'published' for older seeded docs that
  /// predate this field, so nothing already live gets hidden.
  final String status;
  final String? thumbnailUrl;
  final String? notesUrl;
  final String? lectureVideoUrl;
  final DateTime? createdAt;

  const Course({
    required this.id,
    required this.title,
    required this.subject,
    required this.level,
    required this.description,
    required this.iconKey,
    required this.colorKey,
    required this.lessonsCount,
    required this.durationHours,
    required this.rating,
    required this.studentsCount,
    required this.priceInr,
    this.whatYoullLearn = const [],
    this.curriculum = const [],
    this.status = 'published',
    this.thumbnailUrl,
    this.notesUrl,
    this.lectureVideoUrl,
    this.createdAt,
  });

  bool get isFree => priceInr <= 0;
  bool get isPublished => status == 'published';

  factory Course.fromMap(String id, Map<String, dynamic> map) {
    final rawCurriculum = (map['curriculum'] as List<dynamic>? ?? [])
        .cast<Map<String, dynamic>>();
    final rawLearn = (map['whatYoullLearn'] as List<dynamic>? ?? [])
        .cast<String>();
    return Course(
      id: id,
      title: map['title'] as String? ?? 'Untitled course',
      subject: map['subject'] as String? ?? 'General',
      level: map['level'] as String? ?? 'Beginner',
      description: map['description'] as String? ?? '',
      iconKey: map['iconKey'] as String? ?? 'code',
      colorKey: map['colorKey'] as String? ?? 'deepPurple',
      lessonsCount: (map['lessonsCount'] as num?)?.toInt() ?? 0,
      durationHours: (map['durationHours'] as num?)?.toDouble() ?? 0,
      rating: (map['rating'] as num?)?.toDouble() ?? 0,
      studentsCount: (map['studentsCount'] as num?)?.toInt() ?? 0,
      priceInr: (map['priceInr'] as num?)?.toInt() ?? 0,
      whatYoullLearn: rawLearn,
      curriculum: rawCurriculum.map(CourseChapter.fromMap).toList(),
      status: map['status'] as String? ?? 'published',
      thumbnailUrl: map['thumbnailUrl'] as String?,
      notesUrl: map['notesUrl'] as String?,
      lectureVideoUrl: map['lectureVideoUrl'] as String?,
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'subject': subject,
        'level': level,
        'description': description,
        'iconKey': iconKey,
        'colorKey': colorKey,
        'lessonsCount': lessonsCount,
        'durationHours': durationHours,
        'rating': rating,
        'studentsCount': studentsCount,
        'priceInr': priceInr,
        'whatYoullLearn': whatYoullLearn,
        'curriculum': curriculum.map((c) => c.toMap()).toList(),
        'status': status,
        'thumbnailUrl': thumbnailUrl,
        'notesUrl': notesUrl,
        'lectureVideoUrl': lectureVideoUrl,
        if (createdAt != null) 'createdAt': createdAt!.toIso8601String(),
      };
}
