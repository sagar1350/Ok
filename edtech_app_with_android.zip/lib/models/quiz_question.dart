class QuizQuestion {
  final String text;
  final List<String> options;
  final int correctIndex;

  // Admin-only metadata (Module 4: Quiz Management). Ignored by the
  // student QuizController, which only ever reads question/options/
  // correctIndex - kept here, not in a parallel shape, so the admin
  // question bank and the student-facing quiz are the same array.
  final String? id;
  final String? difficulty;
  final int? marks;

  /// Which quiz this instance came from - set by AdminQuizRepository
  /// when it flattens a Quiz's `questions` array for display, NOT
  /// stored in Firestore (redundant there: the question already lives
  /// inside that quiz's own document). Null for a question built fresh
  /// in a form before it's attached to a quiz.
  final String? quizId;

  const QuizQuestion({
    required this.text,
    required this.options,
    required this.correctIndex,
    this.id,
    this.difficulty,
    this.marks,
    this.quizId,
  });

  QuizQuestion copyWith({String? quizId}) => QuizQuestion(
        text: text,
        options: options,
        correctIndex: correctIndex,
        id: id,
        difficulty: difficulty,
        marks: marks,
        quizId: quizId ?? this.quizId,
      );

  factory QuizQuestion.fromMap(Map<String, dynamic> map) {
    return QuizQuestion(
      text: map['question'] as String? ?? '',
      options: (map['options'] as List<dynamic>? ?? []).cast<String>(),
      correctIndex: (map['correctIndex'] as num?)?.toInt() ?? 0,
      id: map['id'] as String?,
      difficulty: map['difficulty'] as String?,
      marks: (map['marks'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toMap() => {
        'question': text,
        'options': options,
        'correctIndex': correctIndex,
        if (id != null) 'id': id,
        if (difficulty != null) 'difficulty': difficulty,
        if (marks != null) 'marks': marks,
      };
}
