import 'course_lesson.dart';

class CourseChapter {
  final String title;
  final List<CourseLesson> lessons;

  const CourseChapter({
    required this.title,
    required this.lessons,
  });

  factory CourseChapter.fromMap(Map<String, dynamic> map) {
    final rawLessons = (map['lessons'] as List<dynamic>? ?? [])
        .cast<Map<String, dynamic>>();
    return CourseChapter(
      title: map['title'] as String? ?? 'Untitled chapter',
      lessons: rawLessons.map(CourseLesson.fromMap).toList(),
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'lessons': lessons.map((l) => l.toMap()).toList(),
      };
}
