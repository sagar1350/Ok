import 'user_role.dart';

/// App-level user profile, stored at `users/{uid}` in Firestore.
///
/// This is separate from Firebase's own `User` object (which only has
/// auth-related fields like uid/phoneNumber) - this model holds the
/// app-specific profile data (role, display name, etc).
class AppUser {
  final String uid;
  final String? phoneNumber;
  final String? name;
  final UserRole role;
  final DateTime? createdAt;

  const AppUser({
    required this.uid,
    this.phoneNumber,
    this.name,
    this.role = UserRole.student,
    this.createdAt,
  });

  AppUser copyWith({
    String? name,
    UserRole? role,
  }) {
    return AppUser(
      uid: uid,
      phoneNumber: phoneNumber,
      name: name ?? this.name,
      role: role ?? this.role,
      createdAt: createdAt,
    );
  }

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      phoneNumber: map['phoneNumber'] as String?,
      name: map['name'] as String?,
      role: UserRole.fromStorage(map['role'] as String?),
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'phoneNumber': phoneNumber,
      'name': name,
      'role': role.storageValue,
      'createdAt': (createdAt ?? DateTime.now()).toIso8601String(),
    };
  }
}
