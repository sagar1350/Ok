/// Categories a user can opt in/out of - mirrors
/// functions/index.js's NOTIFICATION_CATEGORIES minus 'general',
/// which always goes out regardless of preference (see that
/// function's doc comment). Stored as `notificationPrefs` on the
/// user's own profile doc; missing = opted in (default true).
const Map<String, String> optionalNotificationCategories = {
  'liveClasses': 'Live class reminders',
  'courseUpdates': 'Course updates',
  'quizReminders': 'Quiz reminders',
  'promotions': 'Promotions & offers',
};
