enum SyncType {
  quiz,
  notes,
  bookmark,
  download,
  profile,
}
