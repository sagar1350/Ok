/// The roles the app supports. Stored as a plain string in
/// Firestore (`role` field on the user profile doc) so it stays
/// human-readable in the console.
///
/// IMPORTANT: this field (and everything derived from it in
/// AppPermissions) is a UI convenience label, not a security
/// boundary - see the isSelfServiceRole comment in firestore.rules.
/// The only role with real server-side enforcement is admin, gated
/// on the `admin` custom claim (see admin_access_provider.dart /
/// PHASE14_NOTES.md), never on this field.
enum UserRole {
  student(1),
  teacher(2),
  parent(1),
  admin(3);

  /// Coarse ordering for UI-level gating only (e.g. "show the create-
  /// course button to teacher and above"). Parent sits alongside
  /// student deliberately - the app doesn't have a real
  /// student-vs-parent hierarchy, they're just different-shaped
  /// accounts, not ranked relative to each other.
  final int hierarchyLevel;

  const UserRole(this.hierarchyLevel);

  String get storageValue => name;

  static UserRole fromStorage(String? value) {
    return UserRole.values.firstWhere(
      (r) => r.name == value,
      orElse: () => UserRole.student,
    );
  }

  bool get isAdmin => this == UserRole.admin;
  bool get isTeacher => this == UserRole.teacher;

  /// UI-level check only. Real admin-gated screens/data must use
  /// isAdminProvider (the actual claim), not this.
  bool hasMinimumRole(UserRole minimum) => hierarchyLevel >= minimum.hierarchyLevel;
}
