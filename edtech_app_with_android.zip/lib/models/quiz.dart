import 'quiz_question.dart';

/// A quiz document, stored at `quizzes/{quizId}` in Firestore.
/// The dashboard's "Daily Quiz" action loads the quiz with id `daily`.
class Quiz {
  final String id;
  final String title;
  final List<QuizQuestion> questions;

  /// Exam track this quiz belongs to (mirrors courseCategories) - set
  /// from the admin dashboard's Quiz Management module, used there to
  /// filter the question bank/results/leaderboard by track. Optional
  /// so older seeded quizzes without it still load.
  final String? category;

  /// Optional link to a course (Module 3) so per-course analytics
  /// (average score, quiz completion) can be computed - not every
  /// quiz needs one (e.g. a general daily quiz).
  final String? courseId;

  const Quiz({
    required this.id,
    required this.title,
    this.questions = const [],
    this.category,
    this.courseId,
  });

  factory Quiz.fromMap(String id, Map<String, dynamic> map) {
    final rawQuestions =
        (map['questions'] as List<dynamic>? ?? []).cast<Map<String, dynamic>>();
    return Quiz(
      id: id,
      title: map['title'] as String? ?? 'Quiz',
      questions: rawQuestions.map(QuizQuestion.fromMap).toList(),
      category: map['category'] as String?,
      courseId: map['courseId'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'questions': questions.map((q) => q.toMap()).toList(),
        if (category != null) 'category': category,
        if (courseId != null) 'courseId': courseId,
      };
}
