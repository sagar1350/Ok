class CourseLesson {
  final String title;
  final String durationLabel;
  final String videoUrl;
  final bool locked;

  const CourseLesson({
    required this.title,
    required this.durationLabel,
    required this.videoUrl,
    this.locked = false,
  });

  factory CourseLesson.fromMap(Map<String, dynamic> map) {
    return CourseLesson(
      title: map['title'] as String? ?? 'Untitled lesson',
      durationLabel: map['durationLabel'] as String? ?? '',
      videoUrl: map['videoUrl'] as String? ?? '',
      locked: map['locked'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'durationLabel': durationLabel,
        'videoUrl': videoUrl,
        'locked': locked,
      };
}
