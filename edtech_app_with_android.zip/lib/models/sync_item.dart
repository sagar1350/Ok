import 'package:hive/hive.dart';

part 'sync_item.g.dart';

// type/status yahan intentionally String hain, SyncType/SyncStatus enum nahi -
// isse ek extra Hive TypeAdapter (aur enum ordinal-shift ka risk jab kabhi
// naya enum value beech mein add ho) avoid ho jata hai. Read/write karte
// waqt SyncType.name / SyncType.values.byName(...) se convert karo
// (see repository layer jo isse consume karega).
@HiveType(typeId: 1)
class SyncItem extends HiveObject {

  @HiveField(0)
  String id;

  @HiveField(1)
  String type;

  @HiveField(2)
  Map<String, dynamic> payload;

  @HiveField(3)
  String status;

  @HiveField(4)
  DateTime createdAt;

  @HiveField(5)
  int retryCount;

  SyncItem({
    required this.id,
    required this.type,
    required this.payload,
    required this.status,
    required this.createdAt,
    this.retryCount = 0,
  });
}
