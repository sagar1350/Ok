/// A completed course purchase, stored at
/// `users/{uid}/purchases/{courseId}` in Firestore.
///
/// This doc only ever exists once `verifyPayment` (Cloud Function) has
/// confirmed the Razorpay payment signature server-side - the client
/// never writes it directly (see `firestore.rules`). Its mere
/// existence *is* the entitlement: `PaymentRepository.hasCourseAccess`
/// checks for this doc, not a field on the course or a local flag.
class CoursePurchase {
  final String courseId;
  final String courseTitle;
  final int amountInr;
  final String razorpayOrderId;
  final String razorpayPaymentId;
  final String purchasedAt; // ISO 8601

  const CoursePurchase({
    required this.courseId,
    required this.courseTitle,
    required this.amountInr,
    required this.razorpayOrderId,
    required this.razorpayPaymentId,
    required this.purchasedAt,
  });

  factory CoursePurchase.fromMap(String courseId, Map<String, dynamic> map) {
    return CoursePurchase(
      courseId: courseId,
      courseTitle: map['courseTitle'] as String? ?? '',
      amountInr: (map['amountInr'] as num?)?.toInt() ?? 0,
      razorpayOrderId: map['razorpayOrderId'] as String? ?? '',
      razorpayPaymentId: map['razorpayPaymentId'] as String? ?? '',
      purchasedAt: map['purchasedAt'] as String? ?? '',
    );
  }
}
