import 'sync_progress.dart';
import 'sync_stream.dart';

class SyncController {

  void updateProgress(
      int total,
      int completed,
  ) {

    SyncStream.instance.update(

      SyncProgress(
        total: total,
        completed: completed,
      ),

    );

  }

}
