enum ConflictStrategy {
  serverWins,
  clientWins,
  latestTimestamp,
}

class ConflictResolver {

  final ConflictStrategy strategy;

  ConflictResolver(this.strategy);

}
