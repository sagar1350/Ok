import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

import 'retry_scheduler.dart';

/// Listens for the device going offline -> online and calls
/// [onReconnected]. The pasted `startListening()` had no parameters
/// and only comments (`// connectivity_plus`, `// Internet
/// Available`, `// Start Sync`) - as written it couldn't actually
/// start a sync since it had no reference to what "sync" means, so a
/// constructor callback was added. Wire it to whatever eventually
/// assembles SyncManager/SyncService, e.g.:
///
/// ```dart
/// final connectivitySyncProvider = Provider((ref) {
///   final syncManager = ref.read(syncManagerProvider); // doesn't exist yet
///   return ConnectivitySync(onReconnected: syncManager.service.startSync)
///     ..startListening();
/// });
/// ```
///
/// `providers/connectivity_provider.dart` already exposes online/offline
/// as a Riverpod stream for the UI (OfflineBanner watches it) - this is
/// deliberately separate. That one is watched/rebuilt by widgets; this
/// one is a plain service meant to be started once and left running,
/// not tied to a widget's lifecycle.
class ConnectivitySync {

  ConnectivitySync({
    required this.onReconnected,
  });

  final Future<void> Function() onReconnected;

  final _retryScheduler = RetryScheduler();

  StreamSubscription<List<ConnectivityResult>>? _subscription;

  bool _wasOffline = false;

  Future<void> startListening() async {

    // connectivity_plus

    final connectivity = Connectivity();

    final initial = await connectivity.checkConnectivity();
    _wasOffline = !_isOnline(initial);

    _subscription =
        connectivity.onConnectivityChanged.listen((results) async {

      final isOnline = _isOnline(results);

      // Internet Available - sirf offline->online transition pe fire
      // karo, har event pe nahi. Warna wifi<->cellular handoff jaisa
      // "already online, bas network path badla" bhi baar baar sync
      // trigger kar deta.
      if (isOnline && _wasOffline) {

        // Start Sync
        await _triggerSync();

      }

      _wasOffline = !isOnline;

    });

  }

  Future<void> _triggerSync() async {

    try {
      await onReconnected();
    } catch (_) {
      // Poora sync attempt hi start hote hi fail hua (e.g. reconnect
      // ke turant baad connectivity abhi bhi flaky hai) - RetryScheduler
      // se ek hi delayed dobara try. Baar baar loop nahi karte yahan;
      // agar yeh bhi fail hua to agla real reconnect event ya
      // SyncScheduler ka periodic timer hi agla mauka hoga.
      await _retryScheduler.retry(onReconnected);
    }

  }

  void dispose() {
    _subscription?.cancel();
  }

}

bool _isOnline(List<ConnectivityResult> results) {
  // providers/connectivity_provider.dart mein bhi yehi check hai,
  // lekin wahan private (_isOnline) hai isliye reuse nahi ho sakta -
  // itna chhota helper hai ki duplicate karna us function ko public
  // banane se better laga.
  return results.any((r) => r != ConnectivityResult.none);
}
