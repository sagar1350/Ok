import 'dart:async';

import 'sync_progress.dart';

class SyncStream {
  SyncStream._();

  static final SyncStream instance = SyncStream._();

  final _controller =
      StreamController<SyncProgress>.broadcast();

  Stream<SyncProgress> get stream =>
      _controller.stream;

  void update(
      SyncProgress progress,
  ) {
    if (!_controller.isClosed) {
      _controller.add(progress);
    }
  }

  void dispose() {
    _controller.close();
  }
}
