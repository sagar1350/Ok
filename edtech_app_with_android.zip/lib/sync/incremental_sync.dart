class IncrementalSync {

  DateTime? lastSync;

  bool shouldSync(
      DateTime updatedAt,
  ) {

    if (lastSync == null) {
      return true;
    }

    return updatedAt.isAfter(lastSync!);

  }

  /// Not in the pasted version - `lastSync` had a getter-by-field but
  /// no way to ever be *set*, so `shouldSync` would return true
  /// forever. Call this after a successful pull so later calls can
  /// actually compare against something.
  void markSynced([DateTime? at]) {

    lastSync = at ?? DateTime.now();

  }

}
