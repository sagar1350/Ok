import 'sync_scheduler.dart';
import 'sync_service.dart';

class SyncManager {

  final SyncService service;

  final SyncScheduler scheduler;

  SyncManager({
    required this.service,
    required this.scheduler,
  });

  Future<void> initialize() async {

    scheduler.start(() async {

      await service.startSync();

    });

  }

}
