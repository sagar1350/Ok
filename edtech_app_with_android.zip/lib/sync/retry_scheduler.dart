import 'dart:async';

/// Waits 5s, then runs [task] once. Note this does NOT catch or
/// inspect success/failure of [task] itself - it's a plain "delay,
/// then run" primitive, not a self-retrying loop. Per-item retry
/// with exponential backoff already exists (`services/retry_policy.dart`,
/// used inside `QueueProcessor.processQueue()`) - this is for a
/// different situation: giving a whole sync *attempt* one delayed
/// second try after it fails to even start (see `connectivity_sync.dart`).
class RetryScheduler {

  Future<void> retry(
      Future<void> Function() task,
  ) async {

    await Future.delayed(

      const Duration(seconds: 5),

    );

    await task();

  }

}
