class SyncProgress {

  final int total;

  final int completed;

  const SyncProgress({
    required this.total,
    required this.completed,
  });

  double get percent =>
      total == 0 ? 0 : completed / total;

}
