import 'dart:async';

class SyncScheduler {

  Timer? _timer;

  void start(
      Future<void> Function() sync,
  ) {

    _timer = Timer.periodic(

      const Duration(minutes: 5),

      (_) => sync(),

    );

  }

  void stop() {

    _timer?.cancel();

  }

}
