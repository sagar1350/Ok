enum SyncState {
  idle,
  syncing,
  completed,
  failed,
}
