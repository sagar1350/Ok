import '../services/queue_manager.dart';
import '../services/queue_processor.dart';

class SyncService {

  final QueueManager queueManager;

  final QueueProcessor processor;

  SyncService({
    required this.queueManager,
    required this.processor,
  });

  Future<void> startSync() async {

    await processor.processQueue();

  }

}
