import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repositories/admin_analytics_repository.dart';
import '../repositories/admin_course_repository.dart';
import '../repositories/admin_live_class_repository.dart';
import '../repositories/admin_notification_repository.dart';
import '../repositories/admin_payment_repository.dart';
import '../repositories/admin_quiz_repository.dart';
import '../repositories/admin_settings_repository.dart';
import '../repositories/admin_user_repository.dart';
import '../repositories/impl/firestore_admin_analytics_repository.dart';
import '../repositories/impl/firestore_admin_course_repository.dart';
import '../repositories/impl/firestore_admin_live_class_repository.dart';
import '../repositories/impl/firestore_admin_notification_repository.dart';
import '../repositories/impl/firestore_admin_payment_repository.dart';
import '../repositories/impl/firestore_admin_quiz_repository.dart';
import '../repositories/impl/firestore_admin_settings_repository.dart';
import '../repositories/impl/firestore_admin_user_repository.dart';

/// Single place where the admin dashboard's repository interfaces are
/// bound to concrete Firestore implementations - mirrors
/// lib/providers/repository_providers.dart's pattern. Override these
/// in tests to inject fakes instead of hitting Firestore.
final adminUserRepositoryProvider = Provider<AdminUserRepository>((ref) {
  return FirestoreAdminUserRepository();
});

final adminCourseRepositoryProvider = Provider<AdminCourseRepository>((ref) {
  return FirestoreAdminCourseRepository();
});

final adminQuizRepositoryProvider = Provider<AdminQuizRepository>((ref) {
  return FirestoreAdminQuizRepository();
});

final adminPaymentRepositoryProvider = Provider<AdminPaymentRepository>((ref) {
  return FirestoreAdminPaymentRepository();
});

final adminLiveClassRepositoryProvider =
    Provider<AdminLiveClassRepository>((ref) {
  return FirestoreAdminLiveClassRepository();
});

final adminSettingsRepositoryProvider =
    Provider<AdminSettingsRepository>((ref) {
  return FirestoreAdminSettingsRepository();
});

final adminAnalyticsRepositoryProvider =
    Provider<AdminAnalyticsRepository>((ref) {
  return FirestoreAdminAnalyticsRepository();
});

final adminNotificationRepositoryProvider =
    Provider<AdminNotificationRepository>((ref) {
  return FirestoreAdminNotificationRepository();
});
