import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/analytics_model.dart';
import '../models/course_model.dart' show Course;
import '../models/live_class_model.dart';
import '../models/notification_model.dart';
import '../models/payment_model.dart';
import '../models/quiz_model.dart' show QuizResult, LeaderboardEntry;
import '../models/settings_model.dart';
import '../models/user_model.dart';
import '../../models/quiz.dart';
import '../../models/quiz_question.dart';
import 'admin_repository_providers.dart';

// ---- Users (Module 2) ----
final adminUsersStreamProvider = StreamProvider<List<UserAccount>>((ref) {
  return ref.watch(adminUserRepositoryProvider).watchUsers();
});

// ---- Courses (Module 3) ----
final adminCoursesStreamProvider =
    StreamProvider<List<Course>>((ref) {
  return ref.watch(adminCourseRepositoryProvider).watchCourses();
});

// ---- Quizzes (Module 4) ----
final adminQuizzesStreamProvider = StreamProvider<List<Quiz>>((ref) {
  return ref.watch(adminQuizRepositoryProvider).watchQuizzes();
});

final adminQuestionBankStreamProvider =
    StreamProvider<List<QuizQuestion>>((ref) {
  return ref.watch(adminQuizRepositoryProvider).watchQuestionBank();
});

final adminQuizResultsProvider = FutureProvider.autoDispose<List<QuizResult>>((ref) {
  return ref.watch(adminQuizRepositoryProvider).getResults();
});

final adminQuizLeaderboardProvider =
    FutureProvider.autoDispose<List<LeaderboardEntry>>((ref) {
  return ref.watch(adminQuizRepositoryProvider).getLeaderboard();
});

// ---- Payments (Module 5) ----
final adminPlansStreamProvider =
    StreamProvider<List<SubscriptionPlan>>((ref) {
  return ref.watch(adminPaymentRepositoryProvider).watchPlans();
});

final adminTransactionsProvider =
    FutureProvider.autoDispose<List<PaymentTransaction>>((ref) {
  return ref.watch(adminPaymentRepositoryProvider).getTransactions();
});

final adminMonthlyRevenueProvider =
    FutureProvider.autoDispose<List<MonthlyRevenue>>((ref) {
  return ref.watch(adminPaymentRepositoryProvider).getMonthlyRevenue();
});

final adminRevenueByItemProvider =
    FutureProvider.autoDispose<List<PlanRevenueSlice>>((ref) {
  return ref.watch(adminPaymentRepositoryProvider).getRevenueByItem();
});

// ---- Live Classes (Module 6) ----
final adminLiveClassesStreamProvider =
    StreamProvider<List<LiveClass>>((ref) {
  return ref.watch(adminLiveClassRepositoryProvider).watchLiveClasses();
});

// ---- Settings (Module 7) ----
final adminAppSettingsStreamProvider = StreamProvider<AppSettings>((ref) {
  return ref.watch(adminSettingsRepositoryProvider).watchAppSettings();
});

final adminPrivacyPolicyStreamProvider =
    StreamProvider<LegalDocument>((ref) {
  return ref.watch(adminSettingsRepositoryProvider).watchPrivacyPolicy();
});

final adminTermsStreamProvider = StreamProvider<LegalDocument>((ref) {
  return ref.watch(adminSettingsRepositoryProvider).watchTerms();
});

final adminContactDetailsStreamProvider =
    StreamProvider<ContactDetails>((ref) {
  return ref.watch(adminSettingsRepositoryProvider).watchContactDetails();
});

// ---- Analytics (Module 8) ----
final adminAnalyticsOverviewProvider =
    FutureProvider.autoDispose<AnalyticsOverview>((ref) {
  return ref.watch(adminAnalyticsRepositoryProvider).getOverview();
});

final adminDailyUsageProvider =
    FutureProvider.autoDispose<List<DailyUsage>>((ref) {
  return ref.watch(adminAnalyticsRepositoryProvider).getDailyUsage();
});

final adminMonthlyUsageProvider =
    FutureProvider.autoDispose<List<MonthlyUsage>>((ref) {
  return ref.watch(adminAnalyticsRepositoryProvider).getMonthlyUsage();
});

final adminRevenueTrendProvider =
    FutureProvider.autoDispose<List<RevenuePoint>>((ref) {
  return ref.watch(adminAnalyticsRepositoryProvider).getRevenueTrend();
});

final adminCoursePerformanceProvider =
    FutureProvider.autoDispose<List<CoursePerformance>>((ref) {
  return ref.watch(adminAnalyticsRepositoryProvider).getCoursePerformance();
});

// ---- Notifications (Module 9) ----
final adminNotificationHistoryProvider =
    StreamProvider<List<NotificationRecord>>((ref) {
  return ref.watch(adminNotificationRepositoryProvider).watchHistory();
});
