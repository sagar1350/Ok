import '../models/course_model.dart';

/// Read/write access to the catalog for the admin dashboard's Course
/// Management screen. Operates on the same `courses/{courseId}`
/// documents the student app reads (via CourseRepository) - saving
/// here only ever touches the fields the admin form actually edits;
/// everything else on the document (curriculum, pricing, stats) is
/// preserved as-is.
abstract class AdminCourseRepository {
  Stream<List<Course>> watchCourses();

  Future<Course?> getCourseById(String id);

  /// Creates a new course document. New courses start with no
  /// curriculum/pricing (Beginner level, free, 0 lessons) - fill
  /// those in via a future curriculum editor or by hand in Firestore
  /// until one exists.
  Future<String> createCourse(Course course);

  /// Updates only title/category/description/status/media on an
  /// existing course - never touches curriculum/pricing/stats.
  Future<void> updateCourse(Course course);

  Future<void> setStatus(String id, String status);

  Future<void> deleteCourse(String id);

  /// Uploads a picked thumbnail/PDF/video to Firebase Storage under
  /// `courses/{courseId}/...` and returns its download URL. Callers
  /// should call this before createCourse/updateCourse so the
  /// resulting URL can be included in that write.
  Future<String> uploadThumbnail(String courseId, List<int> bytes);
  Future<String> uploadNotesPdf(String courseId, List<int> bytes);
  Future<String> uploadLectureVideo(String courseId, List<int> bytes);
}
