import '../models/settings_model.dart';

/// Module 7 — app config, legal docs, and contact details. All four
/// documents live under `settings/*` (see settings_model.dart's doc
/// comment) - publicly readable, admin-only writable.
abstract class AdminSettingsRepository {
  Stream<AppSettings> watchAppSettings();
  Future<void> updateAppSettings(AppSettings settings);

  Stream<LegalDocument> watchPrivacyPolicy();
  Future<void> updatePrivacyPolicy(LegalDocument doc);

  Stream<LegalDocument> watchTerms();
  Future<void> updateTerms(LegalDocument doc);

  Stream<ContactDetails> watchContactDetails();
  Future<void> updateContactDetails(ContactDetails details);
}
