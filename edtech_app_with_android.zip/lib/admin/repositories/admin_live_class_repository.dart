import '../models/live_class_model.dart';

abstract class AdminLiveClassRepository {
  Stream<List<LiveClass>> watchLiveClasses();

  /// Returns the new class's generated id.
  Future<String> createLiveClass(LiveClass liveClass);

  Future<void> updateLiveClass(LiveClass liveClass);

  Future<void> deleteLiveClass(String id);

  /// Overwrites the full attendance map for [classId].
  Future<void> saveAttendance(String classId, List<Attendee> attendees);
}
