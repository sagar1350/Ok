import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/analytics_model.dart';
import '../admin_analytics_repository.dart';

class FirestoreAdminAnalyticsRepository implements AdminAnalyticsRepository {
  final FirebaseFirestore _db;

  FirestoreAdminAnalyticsRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');
  CollectionReference<Map<String, dynamic>> get _courses =>
      _db.collection('courses');
  CollectionReference<Map<String, dynamic>> get _quizzes =>
      _db.collection('quizzes');

  @override
  Future<AnalyticsOverview> getOverview() async {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final thirtyDaysAgo = now.subtract(const Duration(days: 30));

    final results = await Future.wait([
      _users.count().get(),
      _courses.count().get(),
      _quizzes.count().get(),
      _db
          .collectionGroup('subscription')
          .where('status', isEqualTo: 'active')
          .count()
          .get(),
      _users
          .where('lastActiveAt', isGreaterThanOrEqualTo: thirtyDaysAgo.toIso8601String())
          .count()
          .get(),
      _users
          .where('createdAt', isGreaterThanOrEqualTo: todayStart.toIso8601String())
          .count()
          .get(),
      _db
          .collectionGroup('quizAttempts')
          .where('submittedAt', isGreaterThanOrEqualTo: todayStart.toIso8601String())
          .count()
          .get(),
    ]);
    final revenue = await _sumPaidOrders();
    return AnalyticsOverview(
      totalUsers: results[0].count ?? 0,
      totalCourses: results[1].count ?? 0,
      totalQuizzes: results[2].count ?? 0,
      activeSubscriptions: results[3].count ?? 0,
      totalRevenueInr: revenue,
      activeUsersLast30d: results[4].count ?? 0,
      newSignupsToday: results[5].count ?? 0,
      quizAttemptsToday: results[6].count ?? 0,
    );
  }

  Future<double> _sumPaidOrders() async {
    final snap =
        await _db.collectionGroup('orders').where('status', isEqualTo: 'paid').get();
    double total = 0;
    for (final doc in snap.docs) {
      total += (doc.data()['amountInr'] as num?)?.toDouble() ?? 0;
    }
    return total;
  }

  Future<int> _countActiveSince(DateTime since) async {
    final count = await _users
        .where('lastActiveAt', isGreaterThanOrEqualTo: since.toIso8601String())
        .count()
        .get();
    return count.count ?? 0;
  }

  Future<int> _countNewSince(DateTime since, DateTime until) async {
    final count = await _users
        .where('createdAt', isGreaterThanOrEqualTo: since.toIso8601String())
        .where('createdAt', isLessThan: until.toIso8601String())
        .count()
        .get();
    return count.count ?? 0;
  }

  @override
  Future<List<DailyUsage>> getDailyUsage() async {
    final today = DateTime.now();
    final days = List.generate(30, (i) => today.subtract(Duration(days: 29 - i)));
    final results = await Future.wait(days.map((day) async {
      final dayStart = DateTime(day.year, day.month, day.day);
      final dayEnd = dayStart.add(const Duration(days: 1));
      final active = await _countActiveSince(dayStart);
      final newUsers = await _countNewSince(dayStart, dayEnd);
      return DailyUsage(date: dayStart, activeUsers: active, newUsers: newUsers);
    }));
    return results;
  }

  @override
  Future<List<MonthlyUsage>> getMonthlyUsage() async {
    final now = DateTime.now();
    const labels = [
      '', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final months = List.generate(12, (i) => 11 - i);
    final results = await Future.wait(months.map((i) async {
      final monthStart = DateTime(now.year, now.month - i, 1);
      final monthEnd = DateTime(now.year, now.month - i + 1, 1);
      final active = await _countActiveSince(monthStart);
      final newUsers = await _countNewSince(monthStart, monthEnd);
      return MonthlyUsage(
        month: labels[monthStart.month],
        activeUsers: active,
        newUsers: newUsers,
      );
    }));
    return results;
  }

  @override
  Future<List<RevenuePoint>> getRevenueTrend() async {
    final now = DateTime.now();
    final yearAgo = DateTime(now.year - 1, now.month, 1);
    final snap =
        await _db.collectionGroup('orders').where('status', isEqualTo: 'paid').get();

    final byMonth = <String, double>{};
    for (final doc in snap.docs) {
      final data = doc.data();
      final raw = data['paidAt'] ?? data['createdAt'];
      DateTime paidAt;
      if (raw is Timestamp) {
        paidAt = raw.toDate();
      } else if (raw is String) {
        paidAt = DateTime.tryParse(raw) ?? now;
      } else {
        continue;
      }
      if (paidAt.isBefore(yearAgo)) continue;
      final key = '${paidAt.year}-${paidAt.month.toString().padLeft(2, '0')}';
      byMonth[key] = (byMonth[key] ?? 0) + ((data['amountInr'] as num?)?.toDouble() ?? 0);
    }

    const labels = [
      '', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final out = <RevenuePoint>[];
    for (int i = 11; i >= 0; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final key = '${month.year}-${month.month.toString().padLeft(2, '0')}';
      out.add(RevenuePoint(month: labels[month.month], amountInr: byMonth[key] ?? 0));
    }
    return out;
  }

  @override
  Future<List<CoursePerformance>> getCoursePerformance() async {
    final courseSnap = await _courses.get();
    final quizSnap = await _quizzes.get();
    final enrollSnap = await _db.collectionGroup('enrollments').get();

    // Group quiz ids, and enrollment progress values, by the course
    // they're linked to - one pass over each collection instead of a
    // re-query per course.
    final quizIdsByCourse = <String, List<String>>{};
    for (final doc in quizSnap.docs) {
      final courseId = doc.data()['courseId'] as String?;
      if (courseId == null) continue;
      quizIdsByCourse.putIfAbsent(courseId, () => []).add(doc.id);
    }

    final progressByCourse = <String, List<double>>{};
    for (final doc in enrollSnap.docs) {
      // Enrollment doc id IS the courseId (users/{uid}/enrollments/{courseId}).
      final progress = (doc.data()['progressPercent'] as num?)?.toDouble() ?? 0;
      progressByCourse.putIfAbsent(doc.id, () => []).add(progress);
    }

    final out = <CoursePerformance>[];
    for (final doc in courseSnap.docs) {
      final data = doc.data();
      final courseId = doc.id;

      final progressValues = progressByCourse[courseId] ?? const <double>[];
      final completionRate = progressValues.isEmpty
          ? 0.0
          : (progressValues.reduce((a, b) => a + b) / progressValues.length) * 100;

      double? avgQuizScore;
      final linkedQuizIds = quizIdsByCourse[courseId] ?? [];
      if (linkedQuizIds.isNotEmpty) {
        final attemptSnap = await _db
            .collectionGroup('quizAttempts')
            .where('quizId', whereIn: linkedQuizIds.take(30).toList())
            .get();
        if (attemptSnap.docs.isNotEmpty) {
          double pctSum = 0;
          int n = 0;
          for (final a in attemptSnap.docs) {
            final score = (a.data()['score'] as num?)?.toDouble() ?? 0;
            final total = (a.data()['total'] as num?)?.toDouble() ?? 0;
            if (total <= 0) continue;
            pctSum += (score / total) * 100;
            n++;
          }
          if (n > 0) avgQuizScore = pctSum / n;
        }
      }

      out.add(CoursePerformance(
        title: data['title'] as String? ?? 'Untitled course',
        category: data['subject'] as String? ?? 'General',
        enrollments: (data['studentsCount'] as num?)?.toInt() ?? 0,
        completionRatePct: completionRate,
        avgQuizScorePct: avgQuizScore,
        rating: (data['rating'] as num?)?.toDouble() ?? 0,
      ));
    }
    return out;
  }
}
