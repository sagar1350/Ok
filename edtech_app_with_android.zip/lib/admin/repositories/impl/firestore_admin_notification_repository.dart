import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../../models/notification_model.dart';
import '../admin_notification_repository.dart';

class FirestoreAdminNotificationRepository
    implements AdminNotificationRepository {
  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  FirestoreAdminNotificationRepository({
    FirebaseFirestore? db,
    FirebaseFunctions? functions,
  })  : _db = db ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  @override
  Future<NotificationSendResult> send({
    required String title,
    required String body,
    required String category,
    required NotificationTargetType targetType,
    String? targetValue,
    String? deepLinkScreen,
    String? deepLinkCourseId,
  }) async {
    final result = await _functions.httpsCallable('sendNotification').call({
      'title': title,
      'body': body,
      'category': category,
      'targetType': targetType.storageValue,
      if (targetValue != null) 'targetValue': targetValue,
      if (deepLinkScreen != null && deepLinkScreen.isNotEmpty)
        'deepLink': {
          'screen': deepLinkScreen,
          if (deepLinkCourseId != null) 'courseId': deepLinkCourseId,
        },
    });
    final data = Map<String, dynamic>.from(result.data as Map);
    return NotificationSendResult(
      recipientCount: (data['recipientCount'] as num?)?.toInt() ?? 0,
      devicesSent: (data['devicesSent'] as num?)?.toInt() ?? 0,
      devicesFailed: (data['devicesFailed'] as num?)?.toInt() ?? 0,
    );
  }

  @override
  Stream<List<NotificationRecord>> watchHistory() {
    return _db
        .collection('notifications')
        .orderBy('sentAt', descending: true)
        .limit(200)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => NotificationRecord.fromMap(d.id, d.data()))
            .toList());
  }
}
