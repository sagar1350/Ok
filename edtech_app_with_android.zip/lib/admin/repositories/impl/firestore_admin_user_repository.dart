import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../services/admin_role_service.dart';
import '../../models/user_model.dart';
import '../admin_user_repository.dart';

class FirestoreAdminUserRepository implements AdminUserRepository {
  final FirebaseFirestore _db;
  final AdminRoleService _adminRoleService;

  FirestoreAdminUserRepository({
    FirebaseFirestore? db,
    AdminRoleService? adminRoleService,
  })  : _db = db ?? FirebaseFirestore.instance,
        _adminRoleService = adminRoleService ?? AdminRoleService();

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');

  @override
  Stream<List<UserAccount>> watchUsers() {
    return _users
        .orderBy('createdAt', descending: true)
        .snapshots()
        .asyncMap((snapshot) async {
      // One subscription-doc read per user to resolve `isPremium`.
      // Firestore batches these concurrently; fine for an admin
      // console's list sizes. If this ever needs to scale past a few
      // thousand users, mirror `premium: bool` onto the profile doc
      // from the subscription-fulfilling Cloud Function instead of
      // reading it live here.
      final futures = snapshot.docs.map((doc) async {
        final subSnap = await doc.reference
            .collection('subscription')
            .doc('current')
            .get();
        final isPremium = subSnap.exists &&
            (subSnap.data()?['status'] as String?) == 'active';
        return UserAccount.fromMap(doc.id, doc.data(), isPremium: isPremium);
      });
      return Future.wait(futures);
    });
  }

  @override
  Future<UserAccount?> getUserById(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    final subSnap =
        await _users.doc(uid).collection('subscription').doc('current').get();
    final isPremium =
        subSnap.exists && (subSnap.data()?['status'] as String?) == 'active';
    return UserAccount.fromMap(doc.id, doc.data()!, isPremium: isPremium);
  }

  @override
  Future<void> setBlocked(String uid, bool blocked) async {
    await _users.doc(uid).update({'blocked': blocked});
  }

  @override
  Future<void> setExamTrack(String uid, String examTrack) async {
    await _users.doc(uid).update({'examTrack': examTrack});
  }

  @override
  Future<void> setAdminRole(String uid, bool makeAdmin) async {
    await _adminRoleService.setAdminRole(uid: uid, makeAdmin: makeAdmin);
  }
}
