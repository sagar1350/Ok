import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../../models/payment_model.dart';
import '../admin_payment_repository.dart';

class FirestoreAdminPaymentRepository implements AdminPaymentRepository {
  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  FirestoreAdminPaymentRepository({
    FirebaseFirestore? db,
    FirebaseFunctions? functions,
  })  : _db = db ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  CollectionReference<Map<String, dynamic>> get _plans =>
      _db.collection('subscriptionPlans');

  @override
  Stream<List<SubscriptionPlan>> watchPlans() {
    return _plans.snapshots().asyncMap((snap) async {
      final futures = snap.docs.map((doc) async {
        final count = await _db
            .collectionGroup('subscription')
            .where('plan', isEqualTo: doc.id)
            .where('status', isEqualTo: 'active')
            .count()
            .get();
        return SubscriptionPlan.fromMap(doc.id, doc.data(),
            subscriberCount: count.count ?? 0);
      });
      return Future.wait(futures);
    });
  }

  @override
  Future<void> createPlan(SubscriptionPlan plan) async {
    await _plans.doc(plan.id).set(plan.toMap());
  }

  @override
  Future<void> updatePlan(SubscriptionPlan plan) async {
    await _plans.doc(plan.id).set(plan.toMap(), SetOptions(merge: true));
  }

  @override
  Future<void> deletePlan(String id) async {
    await _plans.doc(id).delete();
  }

  @override
  Future<List<PaymentTransaction>> getTransactions({int limit = 100}) async {
    final snap = await _db
        .collectionGroup('orders')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .get();

    final planNames = <String, String>{};
    final userNames = <String, String>{};
    final out = <PaymentTransaction>[];

    for (final doc in snap.docs) {
      final data = doc.data();
      final userId = doc.reference.parent.parent?.id ?? 'unknown';
      final type = data['type'] as String? ?? 'course';
      final status = _mapStatus(data['status'] as String?);

      String itemName;
      if (type == 'subscription') {
        final plan = data['plan'] as String? ?? '';
        itemName = planNames[plan] ??
            await _plans.doc(plan).get().then((d) {
              final n = (d.data()?['name'] as String?) ??
                  '${plan[0].toUpperCase()}${plan.substring(1)} plan';
              planNames[plan] = n;
              return n;
            });
      } else {
        final courseId = data['courseId'] as String? ?? '';
        itemName = planNames['course_$courseId'] ??
            await _db.collection('courses').doc(courseId).get().then((d) {
              final n = d.data()?['title'] as String? ?? 'Course';
              planNames['course_$courseId'] = n;
              return n;
            });
      }

      final userName = userNames[userId] ??
          await _db.collection('users').doc(userId).get().then((d) {
            final n = d.data()?['name'] as String? ?? 'Unknown user';
            userNames[userId] = n;
            return n;
          });

      out.add(PaymentTransaction(
        id: doc.id,
        userId: userId,
        userName: userName,
        planName: itemName,
        amountInr: (data['amountInr'] as num?)?.toDouble() ?? 0,
        method: 'Razorpay',
        status: status,
        paidOn: _parseTimestamp(data['paidAt'] ?? data['createdAt']),
      ));
    }
    return out;
  }

  String _mapStatus(String? raw) {
    switch (raw) {
      case 'paid':
        return 'Success';
      case 'refunded':
        return 'Refunded';
      case 'failed':
        return 'Failed';
      default:
        return 'Pending';
    }
  }

  DateTime _parseTimestamp(dynamic value) {
    if (value is Timestamp) return value.toDate();
    if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
    return DateTime.now();
  }

  @override
  Future<void> refundTransaction(PaymentTransaction txn) async {
    await _functions.httpsCallable('refundOrder').call({
      'uid': txn.userId,
      'orderId': txn.id,
    });
  }

  @override
  Future<List<MonthlyRevenue>> getMonthlyRevenue() async {
    final sixMonthsAgo = DateTime.now().subtract(const Duration(days: 183));
    final snap = await _db
        .collectionGroup('orders')
        .where('status', isEqualTo: 'paid')
        .get();

    final byMonth = <String, ({double amount, int count})>{};
    for (final doc in snap.docs) {
      final data = doc.data();
      final paidAt = _parseTimestamp(data['paidAt'] ?? data['createdAt']);
      if (paidAt.isBefore(sixMonthsAgo)) continue;
      final key = '${paidAt.year}-${paidAt.month.toString().padLeft(2, '0')}';
      final prev = byMonth[key] ?? (amount: 0.0, count: 0);
      byMonth[key] = (
        amount: prev.amount + ((data['amountInr'] as num?)?.toDouble() ?? 0),
        count: prev.count + 1,
      );
    }

    const monthLabels = [
      '', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final sortedKeys = byMonth.keys.toList()..sort();
    return sortedKeys.map((key) {
      final month = int.parse(key.split('-')[1]);
      final v = byMonth[key]!;
      return MonthlyRevenue(monthLabels[month], v.amount, v.count);
    }).toList();
  }

  @override
  Future<List<PlanRevenueSlice>> getRevenueByItem() async {
    final snap = await _db
        .collectionGroup('orders')
        .where('status', isEqualTo: 'paid')
        .get();

    final byPlan = <String, double>{};
    for (final doc in snap.docs) {
      final data = doc.data();
      final label = data['type'] == 'subscription'
          ? '${data['plan'] ?? 'subscription'} plan'
          : 'Course purchases';
      byPlan[label] =
          (byPlan[label] ?? 0) + ((data['amountInr'] as num?)?.toDouble() ?? 0);
    }

    var i = 0;
    return byPlan.entries
        .map((e) => PlanRevenueSlice(e.key, e.value, i++))
        .toList();
  }
}
