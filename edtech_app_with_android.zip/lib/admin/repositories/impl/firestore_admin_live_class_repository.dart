import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/live_class_model.dart';
import '../admin_live_class_repository.dart';

class FirestoreAdminLiveClassRepository implements AdminLiveClassRepository {
  final FirebaseFirestore _db;

  FirestoreAdminLiveClassRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _classes =>
      _db.collection('live_classes');

  @override
  Stream<List<LiveClass>> watchLiveClasses() {
    return _classes
        .orderBy('scheduledAt')
        .snapshots()
        .asyncMap((snap) async {
      // Resolve every attendee's display name in one batch instead of
      // per-class - live-class rosters overlap heavily (most of the
      // cohort), so this avoids re-fetching the same user doc many
      // times over.
      final allUserIds = <String>{};
      for (final doc in snap.docs) {
        final attendance =
            doc.data()['attendance'] as Map<String, dynamic>? ?? {};
        allUserIds.addAll(attendance.keys);
      }
      final names = await _resolveNames(allUserIds);
      return snap.docs
          .map((d) => LiveClass.fromMap(d.id, d.data(), names))
          .toList();
    });
  }

  Future<Map<String, String>> _resolveNames(Set<String> userIds) async {
    final names = <String, String>{};
    // Firestore whereIn caps at 30 - chunk if a class roster is huge.
    final ids = userIds.toList();
    for (var i = 0; i < ids.length; i += 30) {
      final chunk = ids.sublist(i, i + 30 > ids.length ? ids.length : i + 30);
      if (chunk.isEmpty) continue;
      final snap = await _db
          .collection('users')
          .where(FieldPath.documentId, whereIn: chunk)
          .get();
      for (final doc in snap.docs) {
        names[doc.id] = doc.data()['name'] as String? ?? 'Unknown user';
      }
    }
    return names;
  }

  @override
  Future<String> createLiveClass(LiveClass liveClass) async {
    final ref = await _classes.add(liveClass.toMap());
    return ref.id;
  }

  @override
  Future<void> updateLiveClass(LiveClass liveClass) async {
    await _classes.doc(liveClass.id).set(liveClass.toMap());
  }

  @override
  Future<void> deleteLiveClass(String id) async {
    await _classes.doc(id).delete();
  }

  @override
  Future<void> saveAttendance(String classId, List<Attendee> attendees) async {
    await _classes.doc(classId).update({
      'attendance': {for (final a in attendees) a.userId: a.present},
    });
  }
}
