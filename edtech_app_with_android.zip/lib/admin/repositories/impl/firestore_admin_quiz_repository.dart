import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../models/quiz.dart';
import '../../../models/quiz_question.dart';
import '../../models/quiz_model.dart';
import '../admin_quiz_repository.dart';

class FirestoreAdminQuizRepository implements AdminQuizRepository {
  final FirebaseFirestore _db;

  FirestoreAdminQuizRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _quizzes =>
      _db.collection('quizzes');

  @override
  Stream<List<Quiz>> watchQuizzes() {
    return _quizzes
        .snapshots()
        .map((snap) => snap.docs.map((d) => Quiz.fromMap(d.id, d.data())).toList());
  }

  @override
  Stream<List<QuizQuestion>> watchQuestionBank() {
    return watchQuizzes().map((quizzes) => [
          for (final quiz in quizzes)
            for (final q in quiz.questions) q.copyWith(quizId: quiz.id),
        ]);
  }

  Future<Quiz> _getQuiz(String quizId) async {
    final doc = await _quizzes.doc(quizId).get();
    if (!doc.exists || doc.data() == null) {
      throw StateError('Quiz $quizId not found.');
    }
    return Quiz.fromMap(doc.id, doc.data()!);
  }

  @override
  Future<void> addQuestion(String quizId, QuizQuestion question) async {
    final quiz = await _getQuiz(quizId);
    final withId = QuizQuestion(
      text: question.text,
      options: question.options,
      correctIndex: question.correctIndex,
      id: question.id ?? _quizzes.doc().id,
      difficulty: question.difficulty,
      marks: question.marks,
    );
    final updated = [...quiz.questions, withId];
    await _quizzes.doc(quizId).update({
      'questions': updated.map((q) => q.toMap()).toList(),
    });
  }

  @override
  Future<void> updateQuestion(String quizId, QuizQuestion question) async {
    final quiz = await _getQuiz(quizId);
    final updated = quiz.questions
        .map((q) => q.id == question.id ? question : q)
        .toList();
    await _quizzes.doc(quizId).update({
      'questions': updated.map((q) => q.toMap()).toList(),
    });
  }

  @override
  Future<void> removeQuestion(String quizId, String questionId) async {
    final quiz = await _getQuiz(quizId);
    final updated = quiz.questions.where((q) => q.id != questionId).toList();
    await _quizzes.doc(quizId).update({
      'questions': updated.map((q) => q.toMap()).toList(),
    });
  }

  @override
  Future<List<QuizResult>> getResults({int limit = 100}) async {
    final snap = await _db
        .collectionGroup('quizAttempts')
        .orderBy('submittedAt', descending: true)
        .limit(limit)
        .get();

    final quizTitleCache = <String, String>{};
    final userNameCache = <String, String>{};
    final out = <QuizResult>[];

    for (final doc in snap.docs) {
      final data = doc.data();
      final userId = doc.reference.parent.parent?.id ?? 'unknown';
      final quizId = data['quizId'] as String? ?? '';

      final quizTitle = quizTitleCache[quizId] ??
          await _quizzes.doc(quizId).get().then((d) {
            final t = d.data()?['title'] as String? ?? quizId;
            quizTitleCache[quizId] = t;
            return t;
          });

      final userName = userNameCache[userId] ??
          await _db.collection('users').doc(userId).get().then((d) {
            final n = d.data()?['name'] as String? ?? 'Unknown user';
            userNameCache[userId] = n;
            return n;
          });

      out.add(QuizResult(
        id: doc.id,
        userId: userId,
        userName: userName,
        quizId: quizId,
        quizTitle: quizTitle,
        score: (data['score'] as num?)?.toInt() ?? 0,
        totalMarks: (data['total'] as num?)?.toInt() ?? 0,
        attemptedOn: data['submittedAt'] != null
            ? DateTime.tryParse(data['submittedAt'] as String) ?? DateTime.now()
            : DateTime.now(),
      ));
    }
    return out;
  }

  @override
  Future<List<LeaderboardEntry>> getLeaderboard({int attemptLimit = 500}) async {
    final snap = await _db
        .collectionGroup('quizAttempts')
        .orderBy('submittedAt', descending: true)
        .limit(attemptLimit)
        .get();

    final userNameCache = <String, String>{};
    final userTrackCache = <String, String>{};
    final totals = <String, ({int score, int total, int taken})>{};

    for (final doc in snap.docs) {
      final data = doc.data();
      final userId = doc.reference.parent.parent?.id ?? 'unknown';
      final score = (data['score'] as num?)?.toInt() ?? 0;
      final total = (data['total'] as num?)?.toInt() ?? 0;
      final prev = totals[userId] ?? (score: 0, total: 0, taken: 0);
      totals[userId] = (
        score: prev.score + score,
        total: prev.total + total,
        taken: prev.taken + 1,
      );
    }

    final out = <LeaderboardEntry>[];
    for (final entry in totals.entries) {
      if (!userNameCache.containsKey(entry.key)) {
        final userDoc = await _db.collection('users').doc(entry.key).get();
        userNameCache[entry.key] = userDoc.data()?['name'] as String? ?? 'Unknown user';
        userTrackCache[entry.key] = userDoc.data()?['examTrack'] as String? ?? '—';
      }
      final t = entry.value;
      out.add(LeaderboardEntry(
        userName: userNameCache[entry.key]!,
        examTrack: userTrackCache[entry.key]!,
        totalScore: t.score,
        quizzesTaken: t.taken,
        avgAccuracy: t.total == 0 ? 0 : (t.score / t.total) * 100,
      ));
    }
    out.sort((a, b) => b.totalScore.compareTo(a.totalScore));
    return out;
  }
}
