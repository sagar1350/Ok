import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/settings_model.dart';
import '../admin_settings_repository.dart';

class FirestoreAdminSettingsRepository implements AdminSettingsRepository {
  final FirebaseFirestore _db;

  FirestoreAdminSettingsRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  DocumentReference<Map<String, dynamic>> get _appConfig =>
      _db.collection('settings').doc('app_config');
  DocumentReference<Map<String, dynamic>> get _privacy =>
      _db.collection('settings').doc('privacy_policy');
  DocumentReference<Map<String, dynamic>> get _terms =>
      _db.collection('settings').doc('terms');
  DocumentReference<Map<String, dynamic>> get _contact =>
      _db.collection('settings').doc('contact_details');

  @override
  Stream<AppSettings> watchAppSettings() {
    return _appConfig.snapshots().map((doc) => doc.exists && doc.data() != null
        ? AppSettings.fromMap(doc.data()!)
        : AppSettings.defaults());
  }

  @override
  Future<void> updateAppSettings(AppSettings settings) async {
    await _appConfig.set(settings.toMap(), SetOptions(merge: true));
  }

  @override
  Stream<LegalDocument> watchPrivacyPolicy() {
    return _privacy.snapshots().map((doc) => LegalDocument.fromMap(
          doc.data() ?? {},
          fallbackTitle: 'Privacy Policy',
          fallbackTitleHindi: 'गोपनीयता नीति',
        ));
  }

  @override
  Future<void> updatePrivacyPolicy(LegalDocument doc) async {
    await _privacy.set(doc.toMap(), SetOptions(merge: true));
  }

  @override
  Stream<LegalDocument> watchTerms() {
    return _terms.snapshots().map((doc) => LegalDocument.fromMap(
          doc.data() ?? {},
          fallbackTitle: 'Terms & Conditions',
          fallbackTitleHindi: 'नियम और शर्तें',
        ));
  }

  @override
  Future<void> updateTerms(LegalDocument doc) async {
    await _terms.set(doc.toMap(), SetOptions(merge: true));
  }

  @override
  Stream<ContactDetails> watchContactDetails() {
    return _contact.snapshots().map((doc) => doc.exists && doc.data() != null
        ? ContactDetails.fromMap(doc.data()!)
        : ContactDetails.empty());
  }

  @override
  Future<void> updateContactDetails(ContactDetails details) async {
    await _contact.set(details.toMap(), SetOptions(merge: true));
  }
}
