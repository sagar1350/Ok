import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../models/course.dart' as core;
import '../../../network/upload_service.dart';
import '../../models/course_model.dart';
import '../admin_course_repository.dart';

class FirestoreAdminCourseRepository implements AdminCourseRepository {
  final FirebaseFirestore _db;
  final UploadService _uploads;

  FirestoreAdminCourseRepository({
    FirebaseFirestore? db,
    UploadService? uploads,
  })  : _db = db ?? FirebaseFirestore.instance,
        _uploads = uploads ?? UploadService();

  CollectionReference<Map<String, dynamic>> get _courses =>
      _db.collection('courses');

  @override
  Stream<List<Course>> watchCourses() {
    return _courses.orderBy('createdAt', descending: true).snapshots().map(
        (snap) => snap.docs
            .map((d) => Course.fromCore(core.Course.fromMap(d.id, d.data())))
            .toList());
  }

  @override
  Future<Course?> getCourseById(String id) async {
    final doc = await _courses.doc(id).get();
    if (!doc.exists || doc.data() == null) return null;
    return Course.fromCore(core.Course.fromMap(doc.id, doc.data()!));
  }

  @override
  Future<String> createCourse(Course course) async {
    final ref = _courses.doc();
    await ref.set({
      'title': course.title,
      'subject': course.category,
      'level': 'Beginner',
      'description': course.description,
      'iconKey': 'code',
      'colorKey': 'deepPurple',
      'lessonsCount': 0,
      'durationHours': 0.0,
      'rating': 0.0,
      'studentsCount': 0,
      'priceInr': 0,
      'whatYoullLearn': <String>[],
      'curriculum': <Map<String, dynamic>>[],
      'status': course.status,
      'thumbnailUrl': course.thumbnailUrl,
      'notesUrl': course.pdfUrl,
      'lectureVideoUrl': course.videoUrl,
      'createdAt': DateTime.now().toIso8601String(),
    });
    return ref.id;
  }

  @override
  Future<void> updateCourse(Course course) async {
    // Merge so curriculum/pricing/stats set elsewhere survive an edit
    // made from this simplified form.
    await _courses.doc(course.id).set({
      'title': course.title,
      'subject': course.category,
      'description': course.description,
      'status': course.status,
      'thumbnailUrl': course.thumbnailUrl,
      'notesUrl': course.pdfUrl,
      'lectureVideoUrl': course.videoUrl,
    }, SetOptions(merge: true));
  }

  @override
  Future<void> setStatus(String id, String status) async {
    await _courses.doc(id).update({'status': status});
  }

  @override
  Future<void> deleteCourse(String id) async {
    await _courses.doc(id).delete();
  }

  @override
  Future<String> uploadThumbnail(String courseId, List<int> bytes) {
    return _uploads.uploadBytes(
      'courses/$courseId/thumbnail.jpg',
      Uint8List.fromList(bytes),
      contentType: 'image/jpeg',
    );
  }

  @override
  Future<String> uploadNotesPdf(String courseId, List<int> bytes) {
    return _uploads.uploadBytes(
      'courses/$courseId/materials/notes.pdf',
      Uint8List.fromList(bytes),
      contentType: 'application/pdf',
    );
  }

  @override
  Future<String> uploadLectureVideo(String courseId, List<int> bytes) {
    return _uploads.uploadBytes(
      'courses/$courseId/videos/lecture.mp4',
      Uint8List.fromList(bytes),
      contentType: 'video/mp4',
    );
  }
}
