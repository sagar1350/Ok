import '../models/payment_model.dart';

/// Read access to real payment data (`users/*/orders`, derived
/// revenue) plus CRUD over `subscriptionPlans` for Module 5. Orders
/// themselves are never written by the client - see
/// functions/index.js's createOrder/verifyPayment/refundOrder, which
/// firestore.rules requires for every write to that collection.
abstract class AdminPaymentRepository {
  Stream<List<SubscriptionPlan>> watchPlans();

  Future<void> createPlan(SubscriptionPlan plan);
  Future<void> updatePlan(SubscriptionPlan plan);
  Future<void> deletePlan(String id);

  /// Most recent transactions across all users, newest first.
  Future<List<PaymentTransaction>> getTransactions({int limit = 100});

  /// Calls the refundOrder Cloud Function - the only path that can
  /// mark an order refunded and revoke what it granted.
  Future<void> refundTransaction(PaymentTransaction txn);

  /// Paid-order totals for the last 6 months, for the revenue chart.
  Future<List<MonthlyRevenue>> getMonthlyRevenue();

  /// Paid-order totals grouped by plan/course, for the revenue donut.
  Future<List<PlanRevenueSlice>> getRevenueByItem();
}
