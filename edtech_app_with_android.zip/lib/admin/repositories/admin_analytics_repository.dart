import '../models/analytics_model.dart';

/// Module 8 — read-only aggregate views over real platform data. See
/// analytics_model.dart's doc comment for exactly what's a genuine
/// signal today vs. what needs a future scheduled Cloud Function.
abstract class AdminAnalyticsRepository {
  Future<AnalyticsOverview> getOverview();

  /// Last 30 days. [activeUsers]/[newUsers] on each point both answer
  /// "as measured right now" (see class doc comment), not a retained
  /// historical snapshot.
  Future<List<DailyUsage>> getDailyUsage();

  /// Last 12 months, same caveat as [getDailyUsage].
  Future<List<MonthlyUsage>> getMonthlyUsage();

  /// Last 12 months of paid-order revenue.
  Future<List<RevenuePoint>> getRevenueTrend();

  Future<List<CoursePerformance>> getCoursePerformance();
}
