import '../models/notification_model.dart';

/// Module 9 - composing and sending pushes, and reading what's already
/// gone out. Sending is a Cloud Function call (sendNotification), not
/// a direct Firestore write - see that function's doc comment for why.
abstract class AdminNotificationRepository {
  /// Sends a push now. Throws if the Cloud Function rejects it
  /// (validation error, or the caller isn't an admin).
  Future<NotificationSendResult> send({
    required String title,
    required String body,
    required String category,
    required NotificationTargetType targetType,
    String? targetValue,
    String? deepLinkScreen,
    String? deepLinkCourseId,
  });

  Stream<List<NotificationRecord>> watchHistory();
}

class NotificationSendResult {
  final int recipientCount;
  final int devicesSent;
  final int devicesFailed;

  const NotificationSendResult({
    required this.recipientCount,
    required this.devicesSent,
    required this.devicesFailed,
  });
}
