import '../../models/quiz.dart';
import '../../models/quiz_question.dart';
import '../models/quiz_model.dart';

/// Read/write access to quizzes, their question banks, learner
/// results, and the leaderboard for Module 4. Quizzes and their
/// questions live at `quizzes/{quizId}` (the same document the
/// student QuizController reads); results/leaderboard are derived
/// from `users/*/quizAttempts` via a collectionGroup query.
abstract class AdminQuizRepository {
  Stream<List<Quiz>> watchQuizzes();

  /// Every question across every quiz, flattened into one list with
  /// [QuizQuestion.quizId] filled in - what the "Add Questions" tab
  /// displays. Derived from [watchQuizzes]; not a separate collection.
  Stream<List<QuizQuestion>> watchQuestionBank();

  /// Adds a question to [quizId]'s bank (appends to its `questions`
  /// array). Generates and assigns a fresh id on [question].
  Future<void> addQuestion(String quizId, QuizQuestion question);

  /// Replaces the question with a matching id inside [quizId]'s bank.
  Future<void> updateQuestion(String quizId, QuizQuestion question);

  Future<void> removeQuestion(String quizId, String questionId);

  /// Most recent quiz attempts across all users, newest first, joined
  /// with quiz title and user display name. [limit] bounds how many
  /// attempts are fetched/joined - this does a per-attempt user-doc
  /// read, so keep it modest for an admin list view.
  Future<List<QuizResult>> getResults({int limit = 100});

  /// Aggregates the last [attemptLimit] attempts into a per-user
  /// leaderboard, ranked by total score. See LeaderboardEntry's doc
  /// comment for the scaling caveat.
  Future<List<LeaderboardEntry>> getLeaderboard({int attemptLimit = 500});
}
