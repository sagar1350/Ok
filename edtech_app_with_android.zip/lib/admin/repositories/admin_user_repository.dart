import '../models/user_model.dart';

/// Read/write access to platform users for the admin dashboard's User
/// Management screen. Operates on the *same* `users/{uid}` documents
/// the student app owns (see UserAccount's doc comment) - this is a
/// second window onto that data, not a separate admin dataset.
abstract class AdminUserRepository {
  /// Live list of all users, most-recently-joined first. [isPremium]
  /// on each entry reflects `users/{uid}/subscription/current` at
  /// stream-build time.
  Stream<List<UserAccount>> watchUsers();

  Future<UserAccount?> getUserById(String uid);

  /// Sets/clears the admin-only `blocked` flag on a user's profile.
  Future<void> setBlocked(String uid, bool blocked);

  /// Updates the free-text exam-track note admins can attach to an
  /// account (bookkeeping only - not read by the student app).
  Future<void> setExamTrack(String uid, String examTrack);

  /// Grants or revokes the `admin` custom claim via the secured
  /// setAdminRole Cloud Function. Thin pass-through to
  /// AdminRoleService, exposed here so screens depend on one
  /// interface for all user-management actions.
  Future<void> setAdminRole(String uid, bool makeAdmin);
}
