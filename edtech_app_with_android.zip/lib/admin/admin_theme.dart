import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palette: "ink & marigold" — a deep exam-ledger indigo paired with a
/// marigold accent (the flower used to garland toppers' photos on Indian
/// results day), a teal for secondary series, and a soft coral for alerts.
/// Chosen deliberately to avoid the generic cream+terracotta / dark+neon
/// defaults and to root the dashboard in its actual subject: Hindi-medium
/// competitive-exam content.
class AppColors {
  static const Color canvas = Color(0xFFF5F6FB);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color ink = Color(0xFF14213D);
  static const Color inkSoft = Color(0xFF4A5578);
  static const Color marigold = Color(0xFFFFB627);
  static const Color marigoldDeep = Color(0xFFE8960B);
  static const Color teal = Color(0xFF2EC4B6);
  static const Color coral = Color(0xFFEF6461);
  static const Color violet = Color(0xFF6C63FF);
  static const Color border = Color(0xFFE6E8F2);
  static const Color textPrimary = Color(0xFF14213D);
  static const Color textSecondary = Color(0xFF6B7280);
}

class AppTheme {
  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.canvas,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.ink,
        primary: AppColors.ink,
        secondary: AppColors.marigold,
        surface: AppColors.surface,
      ),
    );

    final headingFont = GoogleFonts.poppinsTextTheme(base.textTheme);
    final bodyFont = GoogleFonts.interTextTheme(base.textTheme);

    return base.copyWith(
      textTheme: bodyFont.copyWith(
        displayLarge: headingFont.displayLarge,
        displayMedium: headingFont.displayMedium,
        headlineLarge: headingFont.headlineLarge?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        headlineMedium: headingFont.headlineMedium?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        headlineSmall: headingFont.headlineSmall?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        titleLarge: headingFont.titleLarge?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        titleMedium: headingFont.titleMedium?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: bodyFont.bodyLarge?.copyWith(color: AppColors.textPrimary),
        bodyMedium:
            bodyFont.bodyMedium?.copyWith(color: AppColors.textSecondary),
        labelLarge: bodyFont.labelLarge?.copyWith(color: AppColors.textPrimary),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.border),
        ),
      ),
    );
  }
}
