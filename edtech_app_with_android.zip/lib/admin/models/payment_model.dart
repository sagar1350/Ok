import 'course_model.dart' show courseCategories;

const List<String> billingCycles = ['Monthly', 'Yearly'];
const List<String> transactionStatuses = [
  'Success',
  'Failed',
  'Refunded',
  'Pending',
];

/// A subscription tier learners can buy, stored at
/// `subscriptionPlans/{planId}` - id is 'monthly' or 'yearly' to match
/// functions/index.js's SUBSCRIPTION_PLANS keys, since createOrder
/// reads its price from here (falling back to a hardcoded default if
/// an admin hasn't configured this collection yet). [category] is
/// kept for the UI's filter chips but isn't enforced server-side -
/// every course purchase goes through its own price on the course
/// document, not a plan.
class SubscriptionPlan {
  String id;
  String name;
  double priceInr;
  String billingCycle;
  String category;
  List<String> features;
  bool isActive;
  int subscriberCount;

  SubscriptionPlan({
    required this.id,
    required this.name,
    required this.priceInr,
    required this.billingCycle,
    required this.category,
    required this.features,
    this.isActive = true,
    this.subscriberCount = 0,
  });

  factory SubscriptionPlan.fromMap(String id, Map<String, dynamic> map,
      {int subscriberCount = 0}) {
    return SubscriptionPlan(
      id: id,
      name: map['name'] as String? ?? id,
      priceInr: (map['priceInr'] as num?)?.toDouble() ?? 0,
      billingCycle: map['billingCycle'] as String? ?? 'Monthly',
      category: map['category'] as String? ?? 'All Exams',
      features: (map['features'] as List<dynamic>? ?? []).cast<String>(),
      isActive: map['isActive'] as bool? ?? true,
      subscriberCount: subscriberCount,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'priceInr': priceInr,
        'billingCycle': billingCycle,
        'durationDays': billingCycle == 'Yearly' ? 365 : 30,
        'category': category,
        'features': features,
        'isActive': isActive,
      };
}

/// One payment record, derived from a `users/{uid}/orders/{orderId}`
/// document - backs the Transactions view. Not a separately-stored
/// shape; AdminPaymentRepository projects the real order doc into
/// this for display.
class PaymentTransaction {
  final String id;
  final String userId;
  final String userName;
  final String planName;
  final double amountInr;
  final String method;
  final String status;
  final DateTime paidOn;

  PaymentTransaction({
    required this.id,
    required this.userId,
    required this.userName,
    required this.planName,
    required this.amountInr,
    required this.method,
    required this.status,
    required this.paidOn,
  });
}

/// One bar in the Revenue Reports monthly chart - aggregated
/// client-side from paid orders. For real production volume, replace
/// with a scheduled Cloud Function that maintains running monthly
/// totals instead of summing every order on each read.
class MonthlyRevenue {
  final String month;
  final double amountInr;
  final int transactionCount;
  const MonthlyRevenue(this.month, this.amountInr, this.transactionCount);
}

/// One slice of the Revenue Reports "revenue by plan" donut.
class PlanRevenueSlice {
  final String planName;
  final double amountInr;
  final int colorSeed;
  const PlanRevenueSlice(this.planName, this.amountInr, this.colorSeed);
}

/// Re-exported so the screen can build category filter chips without
/// importing course_model.dart directly.
const List<String> paymentCourseCategories = courseCategories;
