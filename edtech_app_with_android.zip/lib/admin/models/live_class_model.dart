import 'course_model.dart' show courseCategories;

/// Video platform a live class is hosted on.
enum LiveClassPlatform { zoom, googleMeet }

extension LiveClassPlatformLabel on LiveClassPlatform {
  String get label =>
      this == LiveClassPlatform.zoom ? 'Zoom' : 'Google Meet';
}

/// One learner's attendance record for a single live class, stored in
/// the `attendance` map field on the `live_classes/{classId}` doc
/// (userId -> present).
class Attendee {
  final String userId;
  final String name;
  bool present;

  Attendee({required this.userId, required this.name, this.present = false});
}

/// A scheduled (or past) live class, stored at
/// `live_classes/{classId}` in Firestore.
class LiveClass {
  String id;
  String title;
  String category;
  DateTime scheduledAt;
  int durationMinutes;
  String instructor;
  LiveClassPlatform platform;
  String meetingLink;
  List<Attendee> attendees;

  LiveClass({
    required this.id,
    required this.title,
    required this.category,
    required this.scheduledAt,
    required this.durationMinutes,
    required this.instructor,
    required this.platform,
    required this.meetingLink,
    required this.attendees,
  });

  int get presentCount => attendees.where((a) => a.present).length;
  bool get isUpcoming => scheduledAt.isAfter(DateTime.now());

  /// [rosterNames] maps userId -> display name for everyone recorded
  /// in the `attendance` map, since the doc itself only stores
  /// userId -> present booleans - the repository resolves names via
  /// a batched `users` lookup before building this.
  factory LiveClass.fromMap(String id, Map<String, dynamic> map,
      Map<String, String> rosterNames) {
    final attendanceMap =
        (map['attendance'] as Map<String, dynamic>? ?? {});
    return LiveClass(
      id: id,
      title: map['title'] as String? ?? 'Untitled class',
      category: map['category'] as String? ?? courseCategories.first,
      scheduledAt: map['scheduledAt'] != null
          ? DateTime.tryParse(map['scheduledAt'] as String) ?? DateTime.now()
          : DateTime.now(),
      durationMinutes: (map['durationMinutes'] as num?)?.toInt() ?? 60,
      instructor: map['instructor'] as String? ?? 'TBA',
      platform: (map['platform'] as String?) == 'zoom'
          ? LiveClassPlatform.zoom
          : LiveClassPlatform.googleMeet,
      meetingLink: map['meetingLink'] as String? ?? '',
      attendees: attendanceMap.entries
          .map((e) => Attendee(
                userId: e.key,
                name: rosterNames[e.key] ?? 'Unknown user',
                present: e.value as bool? ?? false,
              ))
          .toList(),
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'category': category,
        'scheduledAt': scheduledAt.toIso8601String(),
        'durationMinutes': durationMinutes,
        'instructor': instructor,
        'platform': platform == LiveClassPlatform.zoom ? 'zoom' : 'googleMeet',
        'meetingLink': meetingLink,
        'attendance': {for (final a in attendees) a.userId: a.present},
      };
}

/// Builds a realistic-looking meeting link for the given platform.
/// There's no video-conferencing API integration yet, so this is a
/// stand-in the admin can edit by hand after creating the class - swap
/// for a real Zoom/Meet API call once one exists.
String generateMeetingLinkPlaceholder(LiveClassPlatform platform, String seed) {
  final n = seed.hashCode.abs();
  if (platform == LiveClassPlatform.zoom) {
    final id = 800000000 + (n % 100000000);
    return 'https://zoom.us/j/$id';
  }
  const letters = 'abcdefghijklmnopqrstuvwxyz';
  String chunk(int start, int len) {
    final buf = StringBuffer();
    for (int i = 0; i < len; i++) {
      buf.write(letters[(n + start + i * 7) % letters.length]);
    }
    return buf.toString();
  }
  return 'https://meet.google.com/${chunk(0, 3)}-${chunk(3, 4)}-${chunk(7, 3)}';
}
