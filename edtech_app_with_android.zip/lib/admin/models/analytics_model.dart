import '../models/course_model.dart' show courseCategories;

/// Module 8 — computed from real Firestore data (see
/// AdminAnalyticsRepository), not stored in this shape anywhere.
///
/// Active-user counts come from `users.lastActiveAt`, stamped once
/// per app session by AuthNotifier - the only real signal available
/// without a dedicated analytics-events pipeline. New-user counts
/// come from `users.createdAt`. There is currently no historical
/// daily/monthly *snapshot* being retained (e.g. "what was DAU on a
/// date three months ago") - queries like `getDailyActiveUsers` only
/// answer "active at some point within this window, as of now"; for
/// true historical trend lines, add a scheduled Cloud Function that
/// writes daily counts into `analyticsDaily/{date}` (already covered
/// by firestore.rules, unwritten so far) and read from that instead.

class DailyUsage {
  final DateTime date;
  final int activeUsers;
  final int newUsers;
  const DailyUsage(
      {required this.date, required this.activeUsers, required this.newUsers});
}

class MonthlyUsage {
  final String month;
  final int activeUsers;
  final int newUsers;
  const MonthlyUsage({
    required this.month,
    required this.activeUsers,
    required this.newUsers,
  });
}

class RevenuePoint {
  final String month;
  final double amountInr;
  const RevenuePoint({required this.month, required this.amountInr});
}

class CoursePerformance {
  final String title;
  final String category;
  final int enrollments;

  /// Average of every enrollee's `progressPercent`
  /// (`users/*/enrollments/{courseId}`), as a percentage.
  final double completionRatePct;

  /// Average score across every attempt of every quiz whose
  /// `courseId` points at this course. Null if no quiz is linked to
  /// it yet (see Quiz.courseId).
  final double? avgQuizScorePct;
  final double rating;

  const CoursePerformance({
    required this.title,
    required this.category,
    required this.enrollments,
    required this.completionRatePct,
    required this.avgQuizScorePct,
    required this.rating,
  });
}

class AnalyticsOverview {
  final int totalUsers;
  final int totalCourses;
  final int totalQuizzes;
  final int activeSubscriptions;
  final double totalRevenueInr;

  /// Users with `lastActiveAt` in the last 30 days.
  final int activeUsersLast30d;
  final int newSignupsToday;
  final int quizAttemptsToday;

  const AnalyticsOverview({
    required this.totalUsers,
    required this.totalCourses,
    required this.totalQuizzes,
    required this.activeSubscriptions,
    required this.totalRevenueInr,
    required this.activeUsersLast30d,
    required this.newSignupsToday,
    required this.quizAttemptsToday,
  });
}

/// Re-exported so the screen can build category filter chips without
/// importing `course_model.dart` directly.
const List<String> analyticsCourseCategories = courseCategories;
