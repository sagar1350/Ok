/// Categories a push can belong to - matches functions/index.js's
/// NOTIFICATION_CATEGORIES exactly. A user can opt out of any of
/// these except 'general' (see notificationPrefs on their profile).
const List<String> notificationCategories = [
  'general',
  'liveClasses',
  'courseUpdates',
  'quizReminders',
  'promotions',
];

String categoryLabel(String category) => switch (category) {
      'general' => 'General announcement',
      'liveClasses' => 'Live class reminder',
      'courseUpdates' => 'Course update',
      'quizReminders' => 'Quiz reminder',
      'promotions' => 'Promotion',
      _ => category,
    };

/// Who a push goes to. Mirrors sendNotification's targetType values.
enum NotificationTargetType { all, role, examTrack, user }

extension NotificationTargetTypeLabel on NotificationTargetType {
  String get storageValue => name;
  String get label => switch (this) {
        NotificationTargetType.all => 'Everyone',
        NotificationTargetType.role => 'By role',
        NotificationTargetType.examTrack => 'By exam track',
        NotificationTargetType.user => 'One user',
      };
}

/// Where tapping the push should take the user - matches
/// NotificationService._navigate's supported screens exactly. Kept
/// deliberately narrow (rather than a free-text route string) so the
/// composer can never produce a deep link the app doesn't know how to
/// handle.
const Map<String, String> deepLinkScreens = {
  '': 'No deep link (just opens the app)',
  'course-detail': 'Course detail',
  'quiz': 'Daily quiz',
  'saved-lessons': 'Saved lessons',
  'settings': 'Settings',
};

/// One row in Notification History - a `notifications/{id}` document
/// written by the sendNotification Cloud Function, never by the
/// client (see firestore.rules).
class NotificationRecord {
  final String id;
  final String title;
  final String body;
  final String category;
  final String targetType;
  final String? targetValue;
  final String? deepLinkScreen;
  final String status; // sending | sent | failed
  final DateTime sentAt;
  final int recipientCount;
  final int successCount;
  final int failureCount;
  final String? error;

  NotificationRecord({
    required this.id,
    required this.title,
    required this.body,
    required this.category,
    required this.targetType,
    required this.targetValue,
    required this.deepLinkScreen,
    required this.status,
    required this.sentAt,
    required this.recipientCount,
    required this.successCount,
    required this.failureCount,
    this.error,
  });

  factory NotificationRecord.fromMap(String id, Map<String, dynamic> map) {
    final sentAtRaw = map['sentAt'];
    DateTime sentAt;
    if (sentAtRaw == null) {
      sentAt = DateTime.now();
    } else if (sentAtRaw is DateTime) {
      sentAt = sentAtRaw;
    } else {
      // Firestore Timestamp - avoid importing cloud_firestore here so
      // this model stays a plain data class; the repository converts
      // before calling this factory... except we accept dynamic and
      // duck-type toDate() for convenience.
      try {
        sentAt = (sentAtRaw as dynamic).toDate() as DateTime;
      } catch (_) {
        sentAt = DateTime.now();
      }
    }
    return NotificationRecord(
      id: id,
      title: map['title'] as String? ?? '',
      body: map['body'] as String? ?? '',
      category: map['category'] as String? ?? 'general',
      targetType: map['targetType'] as String? ?? 'all',
      targetValue: map['targetValue'] as String?,
      deepLinkScreen: (map['deepLink'] as Map?)?['screen'] as String?,
      status: map['status'] as String? ?? 'sending',
      sentAt: sentAt,
      recipientCount: (map['recipientCount'] as num?)?.toInt() ?? 0,
      successCount: (map['successCount'] as num?)?.toInt() ?? 0,
      failureCount: (map['failureCount'] as num?)?.toInt() ?? 0,
      error: map['error'] as String?,
    );
  }
}
