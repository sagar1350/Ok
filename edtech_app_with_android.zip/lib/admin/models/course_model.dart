import 'dart:typed_data';
import '../../models/course.dart' as core;

/// The exam tracks courses are organized under. Shared with the course
/// filter chips and the Add/Edit Course form's category picker.
const List<String> courseCategories = [
  'UP Police Constable',
  'UP TET',
  'NCERT Class 11',
  'SSC CGL',
];

const List<String> courseStatuses = ['draft', 'published', 'archived'];

/// The admin dashboard's editable view of a `courses/{courseId}`
/// document (Module 3). Deliberately a *simplified* projection of the
/// real `core.Course` model (lib/models/course.dart) that the student
/// app reads: this form only edits title/category/description/
/// status/media, not the curriculum, pricing, or rating fields -
/// those are seeded separately (firestore/seed.js) or via a future
/// curriculum editor. AdminCourseRepository preserves every field
/// this class doesn't expose when saving, so editing a course here
/// never wipes its lessons/pricing/stats.
class Course {
  String id;
  String title;
  String category;
  String description;
  String status;

  // Thumbnail: kept in memory as bytes (web-safe) plus the original
  // file name for a freshly-picked image so it can be previewed before
  // upload; [thumbnailUrl]/[pdfUrl]/[videoUrl] hold what's already
  // stored in Firebase Storage for an existing course.
  Uint8List? thumbnailBytes;
  String? thumbnailName;
  String? thumbnailUrl;

  Uint8List? pdfBytes;
  String? pdfName;
  String? pdfUrl;

  Uint8List? videoBytes;
  String? videoName;
  String? videoUrl;

  final DateTime createdOn;

  Course({
    required this.id,
    required this.title,
    required this.category,
    required this.description,
    this.status = 'draft',
    this.thumbnailBytes,
    this.thumbnailName,
    this.thumbnailUrl,
    this.pdfBytes,
    this.pdfName,
    this.pdfUrl,
    this.videoBytes,
    this.videoName,
    this.videoUrl,
    required this.createdOn,
  });

  factory Course.fromCore(core.Course c) => Course(
        id: c.id,
        title: c.title,
        category: c.subject,
        description: c.description,
        status: c.status,
        thumbnailName:
            c.thumbnailUrl != null ? c.thumbnailUrl!.split('/').last : null,
        thumbnailUrl: c.thumbnailUrl,
        pdfName: c.notesUrl != null ? c.notesUrl!.split('/').last : null,
        pdfUrl: c.notesUrl,
        videoName: c.lectureVideoUrl != null
            ? c.lectureVideoUrl!.split('/').last
            : null,
        videoUrl: c.lectureVideoUrl,
        createdOn: c.createdAt ?? DateTime.now(),
      );
}
