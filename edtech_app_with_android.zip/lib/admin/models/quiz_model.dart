import 'course_model.dart' show courseCategories;

/// Admin Quiz Management (Module 4) reuses the real `Quiz`/
/// `QuizQuestion` models (lib/models/quiz.dart) directly - the
/// question bank IS the `questions` array on the same `quizzes/{id}`
/// document the student QuizController reads, not a parallel dataset.
export '../../models/quiz.dart' show Quiz;
export '../../models/quiz_question.dart' show QuizQuestion;

/// Exam tracks a quiz can belong to — reuses the same set Module 3 uses
/// so a quiz always maps onto an existing course category.
List<String> get quizCategories => courseCategories;

const List<String> quizDifficulties = ['Easy', 'Medium', 'Hard'];

/// One learner's completed attempt at a quiz — backs the Results view.
/// Derived from `users/{uid}/quizAttempts/{attemptId}` joined against
/// the quiz title and the user's display name; not stored in this
/// shape anywhere itself.
class QuizResult {
  final String id;
  final String userId;
  final String userName;
  final String quizId;
  final String quizTitle;
  final int score;
  final int totalMarks;
  final DateTime attemptedOn;

  QuizResult({
    required this.id,
    required this.userId,
    required this.userName,
    required this.quizId,
    required this.quizTitle,
    required this.score,
    required this.totalMarks,
    required this.attemptedOn,
  });

  double get percentage => totalMarks == 0 ? 0 : (score / totalMarks) * 100;
}

/// One row on the overall Leaderboard - aggregated client-side from
/// recent QuizResult rows (see AdminQuizRepository.watchLeaderboard).
/// For a platform with heavy quiz traffic, replace this aggregation
/// with a scheduled Cloud Function that maintains running totals
/// instead of summing attempts on every read.
class LeaderboardEntry {
  final String userName;
  final String examTrack;
  final int totalScore;
  final int quizzesTaken;
  final double avgAccuracy;

  LeaderboardEntry({
    required this.userName,
    required this.examTrack,
    required this.totalScore,
    required this.quizzesTaken,
    required this.avgAccuracy,
  });
}
