/// Module 7 — app-wide configuration, the two legal documents shown
/// in-app, and support contact details. Stored at:
///   settings/app_config       -> AppSettings
///   settings/privacy_policy   -> LegalDocument
///   settings/terms            -> LegalDocument
///   settings/contact_details  -> ContactDetails
/// All four documents are publicly readable (see firestore.rules) -
/// maintenance mode and the legal docs need to be visible even to a
/// signed-out user - and writable only by an admin.

class AppSettings {
  String appName;
  String supportEmail;
  String defaultLanguage;
  int freeMockTestsPerDay;
  String minAppVersion;
  bool maintenanceMode;
  bool allowNewRegistrations;
  bool pushNotificationsEnabled;
  bool forceUpdateEnabled;

  AppSettings({
    required this.appName,
    required this.supportEmail,
    required this.defaultLanguage,
    required this.freeMockTestsPerDay,
    required this.minAppVersion,
    required this.maintenanceMode,
    required this.allowNewRegistrations,
    required this.pushNotificationsEnabled,
    required this.forceUpdateEnabled,
  });

  factory AppSettings.fromMap(Map<String, dynamic> map) => AppSettings(
        appName: map['appName'] as String? ?? 'Exam Prep',
        supportEmail: map['supportEmail'] as String? ?? 'support@examprep.in',
        defaultLanguage: map['defaultLanguage'] as String? ?? 'Hindi',
        freeMockTestsPerDay: (map['freeMockTestsPerDay'] as num?)?.toInt() ?? 3,
        minAppVersion: map['minAppVersion'] as String? ?? '1.0.0',
        maintenanceMode: map['maintenanceMode'] as bool? ?? false,
        allowNewRegistrations: map['allowNewRegistrations'] as bool? ?? true,
        pushNotificationsEnabled:
            map['pushNotificationsEnabled'] as bool? ?? true,
        forceUpdateEnabled: map['forceUpdateEnabled'] as bool? ?? false,
      );

  Map<String, dynamic> toMap() => {
        'appName': appName,
        'supportEmail': supportEmail,
        'defaultLanguage': defaultLanguage,
        'freeMockTestsPerDay': freeMockTestsPerDay,
        'minAppVersion': minAppVersion,
        'maintenanceMode': maintenanceMode,
        'allowNewRegistrations': allowNewRegistrations,
        'pushNotificationsEnabled': pushNotificationsEnabled,
        'forceUpdateEnabled': forceUpdateEnabled,
      };

  factory AppSettings.defaults() => AppSettings(
        appName: 'Exam Prep',
        supportEmail: 'support@examprep.in',
        defaultLanguage: 'Hindi',
        freeMockTestsPerDay: 3,
        minAppVersion: '1.0.0',
        maintenanceMode: false,
        allowNewRegistrations: true,
        pushNotificationsEnabled: true,
        forceUpdateEnabled: false,
      );
}

const List<String> appLanguages = ['Hindi', 'English', 'Hinglish'];

/// A generic legal document (Privacy Policy or Terms & Conditions) —
/// both are just a titled block of editable text with a last-updated
/// stamp, so one model/view covers both.
class LegalDocument {
  final String title;
  final String titleHindi;
  String content;
  DateTime lastUpdated;

  LegalDocument({
    required this.title,
    required this.titleHindi,
    required this.content,
    required this.lastUpdated,
  });

  factory LegalDocument.fromMap(Map<String, dynamic> map,
      {required String fallbackTitle, required String fallbackTitleHindi}) {
    return LegalDocument(
      title: map['title'] as String? ?? fallbackTitle,
      titleHindi: map['titleHindi'] as String? ?? fallbackTitleHindi,
      content: map['content'] as String? ?? '',
      lastUpdated: map['lastUpdated'] != null
          ? DateTime.tryParse(map['lastUpdated'] as String) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'titleHindi': titleHindi,
        'content': content,
        'lastUpdated': lastUpdated.toIso8601String(),
      };
}

class ContactDetails {
  String supportEmail;
  String supportPhone;
  String whatsappNumber;
  String officeAddress;
  String websiteUrl;
  String facebookUrl;
  String instagramUrl;
  String youtubeUrl;

  ContactDetails({
    required this.supportEmail,
    required this.supportPhone,
    required this.whatsappNumber,
    required this.officeAddress,
    required this.websiteUrl,
    required this.facebookUrl,
    required this.instagramUrl,
    required this.youtubeUrl,
  });

  factory ContactDetails.fromMap(Map<String, dynamic> map) => ContactDetails(
        supportEmail: map['supportEmail'] as String? ?? '',
        supportPhone: map['supportPhone'] as String? ?? '',
        whatsappNumber: map['whatsappNumber'] as String? ?? '',
        officeAddress: map['officeAddress'] as String? ?? '',
        websiteUrl: map['websiteUrl'] as String? ?? '',
        facebookUrl: map['facebookUrl'] as String? ?? '',
        instagramUrl: map['instagramUrl'] as String? ?? '',
        youtubeUrl: map['youtubeUrl'] as String? ?? '',
      );

  Map<String, dynamic> toMap() => {
        'supportEmail': supportEmail,
        'supportPhone': supportPhone,
        'whatsappNumber': whatsappNumber,
        'officeAddress': officeAddress,
        'websiteUrl': websiteUrl,
        'facebookUrl': facebookUrl,
        'instagramUrl': instagramUrl,
        'youtubeUrl': youtubeUrl,
      };

  factory ContactDetails.empty() => ContactDetails(
        supportEmail: '',
        supportPhone: '',
        whatsappNumber: '',
        officeAddress: '',
        websiteUrl: '',
        facebookUrl: '',
        instagramUrl: '',
        youtubeUrl: '',
      );
}
