/// A single point on the user-growth line chart.
class GrowthPoint {
  final String label; // e.g. "D1"
  final double users;
  final double active;
  const GrowthPoint(this.label, this.users, this.active);
}

/// A single bar in the revenue-by-month chart.
class RevenueBar {
  final String month;
  final double amountInr;
  const RevenueBar(this.month, this.amountInr);
}

/// A slice in the "Today's Activity" donut.
class ActivitySlice {
  final String label;
  final double value;
  final int colorSeed; // maps to a palette color in the widget
  const ActivitySlice(this.label, this.value, this.colorSeed);
}
