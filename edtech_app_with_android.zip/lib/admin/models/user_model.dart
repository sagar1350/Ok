import '../../models/user_role.dart';

/// A single platform user, as managed from Module 2 (User Management).
///
/// Backed by the *same* `users/{uid}` document the student app writes
/// via `AppUser` (lib/models/app_user.dart) - this isn't a parallel
/// dataset. `blocked` and `examTrack` are admin-only additions to that
/// document (see firestore.rules: only an admin caller may touch
/// those two keys). `isPremium` is derived, read-only here - it comes
/// from `users/{uid}/subscription/current`, which only the payment
/// Cloud Functions may write (see AdminUserRepository.watchUsers).
class UserAccount {
  final String id;
  final String name;
  final String? phoneNumber;
  final String examTrack;
  final UserRole role;
  final DateTime joinedOn;
  final bool isBlocked;
  final bool isPremium;

  UserAccount({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.examTrack,
    required this.role,
    required this.joinedOn,
    this.isBlocked = false,
    this.isPremium = false,
  });

  /// Display-only fallback for screens still expecting an "email"-
  /// shaped identifier - the app is actually phone/OTP authenticated
  /// (see AuthRepository.sendOtp), there is no email field.
  String get contact => phoneNumber ?? 'No phone on file';

  UserAccount copyWith({
    bool? isBlocked,
    String? examTrack,
  }) {
    return UserAccount(
      id: id,
      name: name,
      phoneNumber: phoneNumber,
      examTrack: examTrack ?? this.examTrack,
      role: role,
      joinedOn: joinedOn,
      isBlocked: isBlocked ?? this.isBlocked,
      isPremium: isPremium,
    );
  }

  /// [isPremium] is looked up separately (a subcollection read per
  /// user) - see AdminUserRepository - so it isn't part of this
  /// factory; callers merge it in afterwards.
  factory UserAccount.fromMap(String id, Map<String, dynamic> map,
      {bool isPremium = false}) {
    return UserAccount(
      id: id,
      name: (map['name'] as String?)?.trim().isNotEmpty == true
          ? map['name'] as String
          : 'Unnamed user',
      phoneNumber: map['phoneNumber'] as String?,
      examTrack: map['examTrack'] as String? ?? '—',
      role: UserRole.fromStorage(map['role'] as String?),
      joinedOn: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'] as String) ?? DateTime.now()
          : DateTime.now(),
      isBlocked: map['blocked'] as bool? ?? false,
      isPremium: isPremium,
    );
  }
}
