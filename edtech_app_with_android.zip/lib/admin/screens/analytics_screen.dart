import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/analytics_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../widgets/stat_card.dart';

enum _AnalyticsTab { dailyUsers, monthlyUsers, revenue, coursePerformance }

/// Module 8 content. Every section is a one-shot aggregate read over
/// real Firestore data (see AdminAnalyticsRepository and
/// analytics_model.dart's doc comment for exactly what's a genuine
/// signal today) - refreshed via a retry button rather than a live
/// stream, since each of these scans across collections. A pill
/// sub-nav switches between the module's four sections.
class AnalyticsContent extends StatefulWidget {
  const AnalyticsContent({super.key});

  @override
  State<AnalyticsContent> createState() => _AnalyticsContentState();
}

class _AnalyticsContentState extends State<AnalyticsContent> {
  _AnalyticsTab _tab = _AnalyticsTab.dailyUsers;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              _TabPills(active: _tab, onSelect: (t) => setState(() => _tab = t)),
              const SizedBox(height: 20),
              switch (_tab) {
                _AnalyticsTab.dailyUsers => const _DailyUsersBank(),
                _AnalyticsTab.monthlyUsers => const _MonthlyUsersBank(),
                _AnalyticsTab.revenue => const _RevenueBank(),
                _AnalyticsTab.coursePerformance => const _CoursePerformanceBank(),
              },
            ],
          ),
        );
      },
    );
  }
}

class _DailyUsersBank extends ConsumerWidget {
  const _DailyUsersBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminDailyUsageProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load daily usage: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminDailyUsageProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (daily) => _DailyUsersView(daily: daily),
    );
  }
}

class _MonthlyUsersBank extends ConsumerWidget {
  const _MonthlyUsersBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminMonthlyUsageProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load monthly usage: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminMonthlyUsageProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (monthly) => _MonthlyUsersView(monthly: monthly),
    );
  }
}

class _RevenueBank extends ConsumerWidget {
  const _RevenueBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminRevenueTrendProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load revenue trend: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminRevenueTrendProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (revenue) => _RevenueView(revenue: revenue),
    );
  }
}

class _CoursePerformanceBank extends ConsumerWidget {
  const _CoursePerformanceBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminCoursePerformanceProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load course performance: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminCoursePerformanceProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (courses) => _CoursePerformanceView(courses: courses),
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 8 · Analytics',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('विश्लेषण',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TabPills extends StatelessWidget {
  final _AnalyticsTab active;
  final ValueChanged<_AnalyticsTab> onSelect;
  const _TabPills({required this.active, required this.onSelect});

  static const _tabs = [
    (_AnalyticsTab.dailyUsers, 'Daily Users', Icons.today_rounded),
    (_AnalyticsTab.monthlyUsers, 'Monthly Users', Icons.calendar_month_rounded),
    (_AnalyticsTab.revenue, 'Revenue Charts', Icons.show_chart_rounded),
    (_AnalyticsTab.coursePerformance, 'Course Performance',
        Icons.leaderboard_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final (tab, label, icon) in _tabs)
          ChoiceChip(
            label: Text(label),
            avatar: Icon(icon,
                size: 16,
                color: active == tab ? Colors.white : AppColors.textSecondary),
            selected: active == tab,
            onSelected: (_) => onSelect(tab),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == tab ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

Widget _summaryChip(String label, Color color) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(label,
        style:
            TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12.5)),
  );
}

// ---------------------------------------------------------------------
// Daily Users
// ---------------------------------------------------------------------

class _DailyUsersView extends StatelessWidget {
  final List<DailyUsage> daily;
  const _DailyUsersView({required this.daily});

  @override
  Widget build(BuildContext context) {
    final today = daily.last.activeUsers;
    final yesterday = daily[daily.length - 2].activeUsers;
    final last7 = daily.sublist(daily.length - 7);
    final avg7 = last7.fold<int>(0, (s, d) => s + d.activeUsers) / 7;
    final deltaPct =
        yesterday == 0 ? 0.0 : (today - yesterday) / yesterday * 100;
    final maxY =
        daily.map((d) => d.activeUsers).reduce((a, b) => a > b ? a : b);

    return LayoutBuilder(builder: (context, constraints) {
      final cols = constraints.maxWidth >= 700 ? 2 : 1;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GridView.count(
            crossAxisCount: cols,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: 2.1,
            children: [
              StatCard(
                label: "Today's Active Users",
                hindiLabel: 'आज के सक्रिय उपयोगकर्ता',
                value: NumberFormat.decimalPattern('en_IN').format(today),
                icon: Icons.today_rounded,
                accent: AppColors.marigoldDeep,
                deltaPct: deltaPct,
              ),
              StatCard(
                label: '7-Day Average',
                hindiLabel: '7-दिन का औसत',
                value: NumberFormat.decimalPattern('en_IN')
                    .format(avg7.round()),
                icon: Icons.timeline_rounded,
                accent: AppColors.teal,
                deltaPct: (today - avg7) / avg7 * 100,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Daily Active Users — Last 30 Days',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 20),
                  SizedBox(
                    height: 240,
                    child: LineChart(
                      LineChartData(
                        minY: 0,
                        maxY: maxY * 1.15,
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: false,
                          horizontalInterval: maxY / 4,
                          getDrawingHorizontalLine: (_) =>
                              FlLine(color: AppColors.border, strokeWidth: 1),
                        ),
                        borderData: FlBorderData(show: false),
                        titlesData: FlTitlesData(
                          topTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false)),
                          rightTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              interval: 5,
                              getTitlesWidget: (value, meta) {
                                final i = value.toInt();
                                if (i < 0 || i >= daily.length) {
                                  return const SizedBox.shrink();
                                }
                                return Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text(
                                    DateFormat('MMM d').format(daily[i].date),
                                    style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.textSecondary),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 44,
                              interval: maxY / 4,
                              getTitlesWidget: (value, meta) => Text(
                                '${(value / 1000).toStringAsFixed(1)}k',
                                style: const TextStyle(
                                    fontSize: 11,
                                    color: AppColors.textSecondary),
                              ),
                            ),
                          ),
                        ),
                        lineTouchData: LineTouchData(
                          touchTooltipData: LineTouchTooltipData(
                            getTooltipColor: (_) => AppColors.ink,
                            getTooltipItems: (spots) => spots.map((s) {
                              final d = daily[s.x.toInt()];
                              return LineTooltipItem(
                                '${DateFormat('MMM d').format(d.date)}\n${NumberFormat.decimalPattern('en_IN').format(d.activeUsers)} users',
                                const TextStyle(
                                    color: Colors.white, fontSize: 12),
                              );
                            }).toList(),
                          ),
                        ),
                        lineBarsData: [
                          LineChartBarData(
                            spots: [
                              for (int i = 0; i < daily.length; i++)
                                FlSpot(i.toDouble(),
                                    daily[i].activeUsers.toDouble()),
                            ],
                            isCurved: true,
                            curveSmoothness: 0.25,
                            color: AppColors.marigoldDeep,
                            barWidth: 3,
                            dotData: const FlDotData(show: false),
                            belowBarData: BarAreaData(
                              show: true,
                              color: AppColors.marigoldDeep.withOpacity(0.10),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    });
  }
}

// ---------------------------------------------------------------------
// Monthly Users
// ---------------------------------------------------------------------

class _MonthlyUsersView extends StatelessWidget {
  final List<MonthlyUsage> monthly;
  const _MonthlyUsersView({required this.monthly});

  @override
  Widget build(BuildContext context) {
    final peak = monthly.reduce((a, b) => a.activeUsers > b.activeUsers ? a : b);
    final avg =
        monthly.fold<int>(0, (s, m) => s + m.activeUsers) / monthly.length;
    final totalNew = monthly.fold<int>(0, (s, m) => s + m.newUsers);
    final maxY =
        monthly.map((m) => m.activeUsers).reduce((a, b) => a > b ? a : b);
    final fmt = NumberFormat.decimalPattern('en_IN');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _summaryChip(
                'Peak: ${peak.month} · ${fmt.format(peak.activeUsers)}',
                AppColors.marigoldDeep),
            _summaryChip(
                'Avg ${fmt.format(avg.round())} / month', AppColors.teal),
            _summaryChip('${fmt.format(totalNew)} new users (12 mo)',
                AppColors.violet),
          ],
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Monthly Active Users — Last 12 Months',
                        style: Theme.of(context).textTheme.titleMedium),
                    Row(
                      children: [
                        _legendDot(AppColors.ink, 'Active'),
                        const SizedBox(width: 14),
                        _legendDot(AppColors.marigold, 'New'),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 240,
                  child: BarChart(
                    BarChartData(
                      maxY: maxY * 1.2,
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        horizontalInterval: maxY / 4,
                        getDrawingHorizontalLine: (_) =>
                            FlLine(color: AppColors.border, strokeWidth: 1),
                      ),
                      borderData: FlBorderData(show: false),
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                          getTooltipColor: (_) => AppColors.ink,
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            final m = monthly[groupIndex];
                            return BarTooltipItem(
                              '${m.month}\n${fmt.format(m.activeUsers)} active\n${fmt.format(m.newUsers)} new',
                              const TextStyle(
                                  color: Colors.white, fontSize: 12),
                            );
                          },
                        ),
                      ),
                      titlesData: FlTitlesData(
                        topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              final i = value.toInt();
                              if (i < 0 || i >= monthly.length) {
                                return const SizedBox.shrink();
                              }
                              return Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(monthly[i].month,
                                    style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.textSecondary)),
                              );
                            },
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 48,
                            interval: maxY / 4,
                            getTitlesWidget: (value, meta) => Text(
                              '${(value / 1000).toStringAsFixed(0)}k',
                              style: const TextStyle(
                                  fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ),
                        ),
                      ),
                      barGroups: [
                        for (int i = 0; i < monthly.length; i++)
                          BarChartGroupData(
                            x: i,
                            barRods: [
                              BarChartRodData(
                                toY: monthly[i].activeUsers.toDouble(),
                                width: 14,
                                borderRadius: BorderRadius.circular(4),
                                gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    AppColors.ink.withOpacity(0.55),
                                    AppColors.ink,
                                  ],
                                ),
                              ),
                              BarChartRodData(
                                toY: monthly[i].newUsers.toDouble(),
                                width: 14,
                                borderRadius: BorderRadius.circular(4),
                                gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    AppColors.marigold.withOpacity(0.55),
                                    AppColors.marigold,
                                  ],
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _legendDot(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(label,
            style:
                const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }
}

// ---------------------------------------------------------------------
// Revenue Charts
// ---------------------------------------------------------------------

class _RevenueView extends StatelessWidget {
  final List<RevenuePoint> revenue;
  const _RevenueView({required this.revenue});

  @override
  Widget build(BuildContext context) {
    final total = revenue.fold<double>(0, (s, r) => s + r.amountInr);
    final avg = total / revenue.length;
    final growthPct = revenue.first.amountInr == 0
        ? 0.0
        : (revenue.last.amountInr - revenue.first.amountInr) /
            revenue.first.amountInr *
            100;
    final maxY =
        revenue.map((r) => r.amountInr).reduce((a, b) => a > b ? a : b);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _summaryChip(
                '₹${(total / 100000).toStringAsFixed(1)}L total (12 mo)',
                AppColors.ink),
            _summaryChip(
                '₹${(avg / 100000).toStringAsFixed(1)}L avg / month',
                AppColors.teal),
            _summaryChip(
                '${growthPct >= 0 ? '+' : ''}${growthPct.toStringAsFixed(1)}% vs 12 mo ago',
                growthPct >= 0 ? AppColors.teal : AppColors.coral),
          ],
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Revenue by Month (₹) — Last 12 Months',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 20),
                SizedBox(
                  height: 240,
                  child: BarChart(
                    BarChartData(
                      maxY: maxY * 1.2,
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        horizontalInterval: maxY / 4,
                        getDrawingHorizontalLine: (_) =>
                            FlLine(color: AppColors.border, strokeWidth: 1),
                      ),
                      borderData: FlBorderData(show: false),
                      barTouchData: BarTouchData(
                        touchTooltipData: BarTouchTooltipData(
                          getTooltipColor: (_) => AppColors.ink,
                          getTooltipItem: (group, groupIndex, rod, rodIndex) {
                            final r = revenue[groupIndex];
                            return BarTooltipItem(
                              '${r.month}\n₹${r.amountInr.toStringAsFixed(0)}',
                              const TextStyle(
                                  color: Colors.white, fontSize: 12),
                            );
                          },
                        ),
                      ),
                      titlesData: FlTitlesData(
                        topTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              final i = value.toInt();
                              if (i < 0 || i >= revenue.length) {
                                return const SizedBox.shrink();
                              }
                              return Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(revenue[i].month,
                                    style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.textSecondary)),
                              );
                            },
                          ),
                        ),
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 52,
                            interval: maxY / 4,
                            getTitlesWidget: (value, meta) => Text(
                              '${(value / 100000).toStringAsFixed(1)}L',
                              style: const TextStyle(
                                  fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ),
                        ),
                      ),
                      barGroups: [
                        for (int i = 0; i < revenue.length; i++)
                          BarChartGroupData(
                            x: i,
                            barRods: [
                              BarChartRodData(
                                toY: revenue[i].amountInr,
                                width: 20,
                                borderRadius: BorderRadius.circular(6),
                                gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    AppColors.violet.withOpacity(0.55),
                                    AppColors.violet,
                                  ],
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------
// Course Performance
// ---------------------------------------------------------------------

class _CoursePerformanceView extends StatefulWidget {
  final List<CoursePerformance> courses;
  const _CoursePerformanceView({required this.courses});

  @override
  State<_CoursePerformanceView> createState() =>
      _CoursePerformanceViewState();
}

class _CoursePerformanceViewState extends State<_CoursePerformanceView> {
  String _activeCategory = 'All';

  List<CoursePerformance> get _visible {
    final list = _activeCategory == 'All'
        ? widget.courses
        : widget.courses.where((c) => c.category == _activeCategory).toList();
    return [...list]
      ..sort((a, b) => b.enrollments.compareTo(a.enrollments));
  }

  @override
  Widget build(BuildContext context) {
    final all = ['All', ...analyticsCourseCategories];
    final visible = _visible;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final c in all)
              ChoiceChip(
                label: Text(c),
                selected: _activeCategory == c,
                onSelected: (_) => setState(() => _activeCategory = c),
                selectedColor: AppColors.ink,
                labelStyle: TextStyle(
                  color: _activeCategory == c
                      ? Colors.white
                      : AppColors.textPrimary,
                  fontWeight: FontWeight.w500,
                  fontSize: 12.5,
                ),
                backgroundColor: AppColors.surface,
                side: const BorderSide(color: AppColors.border),
              ),
          ],
        ),
        const SizedBox(height: 16),
        for (final course in visible)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _CoursePerformanceCard(course: course),
          ),
      ],
    );
  }
}

class _CoursePerformanceCard extends StatelessWidget {
  final CoursePerformance course;
  const _CoursePerformanceCard({required this.course});

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat.decimalPattern('en_IN');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(course.title,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontSize: 15)),
                      const SizedBox(height: 3),
                      Text(course.category,
                          style: const TextStyle(
                              fontSize: 12.5, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.star_rounded,
                            size: 16, color: AppColors.marigoldDeep),
                        const SizedBox(width: 3),
                        Text(course.rating.toStringAsFixed(1),
                            style: const TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13.5)),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text('${fmt.format(course.enrollments)} enrolled',
                        style: const TextStyle(
                            fontSize: 11.5, color: AppColors.textSecondary)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            _metricBar(
              label: 'Completion Rate',
              pct: course.completionRatePct,
              color: AppColors.teal,
            ),
            const SizedBox(height: 10),
            if (course.avgQuizScorePct != null)
              _metricBar(
                label: 'Avg Quiz Score',
                pct: course.avgQuizScorePct!,
                color: AppColors.violet,
              )
            else
              const Text(
                'No quiz linked to this course yet',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
          ],
        ),
      ),
    );
  }

  Widget _metricBar({
    required String label,
    required double pct,
    required Color color,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 12, color: AppColors.textSecondary)),
            Text('${pct.toStringAsFixed(0)}%',
                style: TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w600, color: color)),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: pct / 100,
            minHeight: 7,
            backgroundColor: AppColors.canvas,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ],
    );
  }
}
