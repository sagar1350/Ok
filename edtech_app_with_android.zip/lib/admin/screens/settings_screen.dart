import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/settings_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';

enum _SettingsTab { app, privacy, terms, contact }

/// Module 7 content. Each of the four sections streams its own doc
/// from Firestore (AdminSettingsRepository) and writes back on Save -
/// a pill sub-nav switches between them, matching the pattern used
/// for Modules 4 and 6.
class SettingsContent extends ConsumerStatefulWidget {
  const SettingsContent({super.key});

  @override
  ConsumerState<SettingsContent> createState() => _SettingsContentState();
}

class _SettingsContentState extends ConsumerState<SettingsContent> {
  _SettingsTab _tab = _SettingsTab.app;

  void _saved(String what) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$what saved')),
    );
  }

  void _saveFailed(String what, Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Could not save $what: $error')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              _TabPills(active: _tab, onSelect: (t) => setState(() => _tab = t)),
              const SizedBox(height: 20),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: switch (_tab) {
                  _SettingsTab.app => _AppSettingsTab(onSaved: _saved, onFailed: _saveFailed),
                  _SettingsTab.privacy => _PrivacyPolicyTab(onSaved: _saved, onFailed: _saveFailed),
                  _SettingsTab.terms => _TermsTab(onSaved: _saved, onFailed: _saveFailed),
                  _SettingsTab.contact => _ContactDetailsTab(onSaved: _saved, onFailed: _saveFailed),
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

typedef _SavedCallback = void Function(String what);
typedef _FailedCallback = void Function(String what, Object error);

class _AppSettingsTab extends ConsumerWidget {
  final _SavedCallback onSaved;
  final _FailedCallback onFailed;
  const _AppSettingsTab({required this.onSaved, required this.onFailed});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminAppSettingsStreamProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text('Could not load settings: $err')),
      ),
      data: (settings) => _AppSettingsView(
        key: ValueKey(settings.appName + settings.minAppVersion),
        settings: settings,
        onSave: () async {
          try {
            await ref
                .read(adminSettingsRepositoryProvider)
                .updateAppSettings(settings);
            onSaved('App settings');
          } catch (e) {
            onFailed('app settings', e);
          }
        },
      ),
    );
  }
}

class _PrivacyPolicyTab extends ConsumerWidget {
  final _SavedCallback onSaved;
  final _FailedCallback onFailed;
  const _PrivacyPolicyTab({required this.onSaved, required this.onFailed});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminPrivacyPolicyStreamProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text('Could not load privacy policy: $err')),
      ),
      data: (doc) => _LegalDocView(
        key: const ValueKey('privacy'),
        document: doc,
        onSave: () async {
          doc.lastUpdated = DateTime.now();
          try {
            await ref
                .read(adminSettingsRepositoryProvider)
                .updatePrivacyPolicy(doc);
            onSaved('Privacy Policy');
          } catch (e) {
            onFailed('privacy policy', e);
          }
        },
      ),
    );
  }
}

class _TermsTab extends ConsumerWidget {
  final _SavedCallback onSaved;
  final _FailedCallback onFailed;
  const _TermsTab({required this.onSaved, required this.onFailed});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminTermsStreamProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text('Could not load terms: $err')),
      ),
      data: (doc) => _LegalDocView(
        key: const ValueKey('terms'),
        document: doc,
        onSave: () async {
          doc.lastUpdated = DateTime.now();
          try {
            await ref.read(adminSettingsRepositoryProvider).updateTerms(doc);
            onSaved('Terms & Conditions');
          } catch (e) {
            onFailed('terms', e);
          }
        },
      ),
    );
  }
}

class _ContactDetailsTab extends ConsumerWidget {
  final _SavedCallback onSaved;
  final _FailedCallback onFailed;
  const _ContactDetailsTab({required this.onSaved, required this.onFailed});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(adminContactDetailsStreamProvider);
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text('Could not load contact details: $err')),
      ),
      data: (contact) => _ContactDetailsView(
        contact: contact,
        onSave: () async {
          try {
            await ref
                .read(adminSettingsRepositoryProvider)
                .updateContactDetails(contact);
            onSaved('Contact details');
          } catch (e) {
            onFailed('contact details', e);
          }
        },
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 7 · Settings',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('सेटिंग्स',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TabPills extends StatelessWidget {
  final _SettingsTab active;
  final ValueChanged<_SettingsTab> onSelect;
  const _TabPills({required this.active, required this.onSelect});

  static const _tabs = [
    (_SettingsTab.app, 'App Settings', Icons.tune_rounded),
    (_SettingsTab.privacy, 'Privacy Policy', Icons.privacy_tip_outlined),
    (_SettingsTab.terms, 'Terms & Conditions', Icons.gavel_rounded),
    (_SettingsTab.contact, 'Contact Details', Icons.contact_mail_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final (tab, label, icon) in _tabs)
          ChoiceChip(
            label: Text(label),
            avatar: Icon(icon,
                size: 16,
                color: active == tab ? Colors.white : AppColors.textSecondary),
            selected: active == tab,
            onSelected: (_) => onSelect(tab),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == tab ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Color accent;
  final List<Widget> children;

  const _SectionCard({
    required this.title,
    this.subtitle,
    required this.icon,
    required this.accent,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: accent, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: Theme.of(context).textTheme.titleMedium),
                      if (subtitle != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 2),
                          child: Text(subtitle!,
                              style: const TextStyle(
                                  fontSize: 12.5,
                                  color: AppColors.textSecondary)),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _AppSettingsView extends StatefulWidget {
  final AppSettings settings;
  final VoidCallback onSave;
  const _AppSettingsView({required this.settings, required this.onSave});

  @override
  State<_AppSettingsView> createState() => _AppSettingsViewState();
}

class _AppSettingsViewState extends State<_AppSettingsView> {
  late final TextEditingController _appName;
  late final TextEditingController _supportEmail;
  late final TextEditingController _minVersion;

  @override
  void initState() {
    super.initState();
    _appName = TextEditingController(text: widget.settings.appName);
    _supportEmail = TextEditingController(text: widget.settings.supportEmail);
    _minVersion = TextEditingController(text: widget.settings.minAppVersion);
  }

  @override
  void dispose() {
    _appName.dispose();
    _supportEmail.dispose();
    _minVersion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionCard(
          title: 'General',
          subtitle: 'Basic identity and defaults shown across the app',
          icon: Icons.settings_suggest_rounded,
          accent: AppColors.violet,
          children: [
            _LabeledField(
              label: 'App Name',
              child: TextField(
                controller: _appName,
                onChanged: (v) => s.appName = v,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Support Email',
              child: TextField(
                controller: _supportEmail,
                onChanged: (v) => s.supportEmail = v,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Default Language',
              child: DropdownButtonFormField<String>(
                value: s.defaultLanguage,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                items: [
                  for (final lang in appLanguages)
                    DropdownMenuItem(value: lang, child: Text(lang)),
                ],
                onChanged: (v) => setState(() => s.defaultLanguage = v!),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Free Mock Tests / Day',
              child: Row(
                children: [
                  IconButton.outlined(
                    onPressed: s.freeMockTestsPerDay > 0
                        ? () => setState(() => s.freeMockTestsPerDay--)
                        : null,
                    icon: const Icon(Icons.remove_rounded, size: 16),
                  ),
                  Container(
                    width: 48,
                    alignment: Alignment.center,
                    child: Text('${s.freeMockTestsPerDay}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 15)),
                  ),
                  IconButton.outlined(
                    onPressed: () => setState(() => s.freeMockTestsPerDay++),
                    icon: const Icon(Icons.add_rounded, size: 16),
                  ),
                  const SizedBox(width: 8),
                  const Text('for free-tier users',
                      style: TextStyle(
                          fontSize: 12.5, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _SectionCard(
          title: 'Access & Availability',
          subtitle: 'Controls that affect every user immediately on save',
          icon: Icons.shield_moon_outlined,
          accent: AppColors.coral,
          children: [
            _SwitchRow(
              label: 'Maintenance Mode',
              hint: 'Shows a maintenance screen and blocks sign-in',
              value: s.maintenanceMode,
              danger: true,
              onChanged: (v) => setState(() => s.maintenanceMode = v),
            ),
            const Divider(height: 28),
            _SwitchRow(
              label: 'Allow New Registrations',
              hint: 'Turn off to freeze sign-ups during high load or exams',
              value: s.allowNewRegistrations,
              onChanged: (v) => setState(() => s.allowNewRegistrations = v),
            ),
            const Divider(height: 28),
            _SwitchRow(
              label: 'Push Notifications',
              hint: 'Class reminders, results, and result-day alerts',
              value: s.pushNotificationsEnabled,
              onChanged: (v) => setState(() => s.pushNotificationsEnabled = v),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _SectionCard(
          title: 'App Updates',
          subtitle: 'Minimum version required to keep using the app',
          icon: Icons.system_update_alt_rounded,
          accent: AppColors.teal,
          children: [
            _SwitchRow(
              label: 'Force Update',
              hint: 'Block versions older than the minimum below',
              value: s.forceUpdateEnabled,
              onChanged: (v) => setState(() => s.forceUpdateEnabled = v),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Minimum App Version',
              child: TextField(
                controller: _minVersion,
                enabled: s.forceUpdateEnabled,
                onChanged: (v) => s.minAppVersion = v,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'e.g. 2.4.0',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: widget.onSave,
            style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
            icon: const Icon(Icons.save_outlined, size: 18),
            label: const Text('Save Settings'),
          ),
        ),
      ],
    );
  }
}

class _LegalDocView extends StatefulWidget {
  final LegalDocument document;
  final VoidCallback onSave;
  const _LegalDocView({super.key, required this.document, required this.onSave});

  @override
  State<_LegalDocView> createState() => _LegalDocViewState();
}

class _LegalDocViewState extends State<_LegalDocView> {
  late final TextEditingController _content;

  @override
  void initState() {
    super.initState();
    _content = TextEditingController(text: widget.document.content);
  }

  @override
  void dispose() {
    _content.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final doc = widget.document;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(doc.title,
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 2),
                          Text(doc.titleHindi,
                              style: const TextStyle(
                                  fontSize: 12.5,
                                  color: AppColors.textSecondary)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppColors.canvas,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Text(
                        'Updated ${DateFormat('MMM d, yyyy').format(doc.lastUpdated)}',
                        style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textSecondary),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _content,
                  maxLines: 18,
                  onChanged: (v) => doc.content = v,
                  style: const TextStyle(fontSize: 13.5, height: 1.5),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    alignLabelWithHint: true,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: widget.onSave,
            style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
            icon: const Icon(Icons.publish_rounded, size: 18),
            label: const Text('Save & Publish'),
          ),
        ),
      ],
    );
  }
}

class _ContactDetailsView extends StatefulWidget {
  final ContactDetails contact;
  final VoidCallback onSave;
  const _ContactDetailsView({required this.contact, required this.onSave});

  @override
  State<_ContactDetailsView> createState() => _ContactDetailsViewState();
}

class _ContactDetailsViewState extends State<_ContactDetailsView> {
  late final Map<String, TextEditingController> _controllers;

  @override
  void initState() {
    super.initState();
    final c = widget.contact;
    _controllers = {
      'email': TextEditingController(text: c.supportEmail),
      'phone': TextEditingController(text: c.supportPhone),
      'whatsapp': TextEditingController(text: c.whatsappNumber),
      'address': TextEditingController(text: c.officeAddress),
      'website': TextEditingController(text: c.websiteUrl),
      'facebook': TextEditingController(text: c.facebookUrl),
      'instagram': TextEditingController(text: c.instagramUrl),
      'youtube': TextEditingController(text: c.youtubeUrl),
    };
  }

  @override
  void dispose() {
    for (final ctrl in _controllers.values) {
      ctrl.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.contact;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionCard(
          title: 'Support',
          subtitle: 'Shown to users on the in-app "Help" screen',
          icon: Icons.support_agent_rounded,
          accent: AppColors.marigoldDeep,
          children: [
            _LabeledField(
              label: 'Support Email',
              child: TextField(
                controller: _controllers['email'],
                onChanged: (v) => c.supportEmail = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.email_outlined, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Support Phone',
              child: TextField(
                controller: _controllers['phone'],
                onChanged: (v) => c.supportPhone = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.call_outlined, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'WhatsApp Number',
              child: TextField(
                controller: _controllers['whatsapp'],
                onChanged: (v) => c.whatsappNumber = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.chat_outlined, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Office Address',
              child: TextField(
                controller: _controllers['address'],
                onChanged: (v) => c.officeAddress = v,
                maxLines: 3,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.location_on_outlined, size: 18)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _SectionCard(
          title: 'Web & Social',
          subtitle: 'Linked from the app footer and Contact Us screen',
          icon: Icons.public_rounded,
          accent: AppColors.violet,
          children: [
            _LabeledField(
              label: 'Website',
              child: TextField(
                controller: _controllers['website'],
                onChanged: (v) => c.websiteUrl = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.language_rounded, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Facebook',
              child: TextField(
                controller: _controllers['facebook'],
                onChanged: (v) => c.facebookUrl = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.facebook_rounded, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'Instagram',
              child: TextField(
                controller: _controllers['instagram'],
                onChanged: (v) => c.instagramUrl = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.camera_alt_outlined, size: 18)),
              ),
            ),
            const SizedBox(height: 14),
            _LabeledField(
              label: 'YouTube',
              child: TextField(
                controller: _controllers['youtube'],
                onChanged: (v) => c.youtubeUrl = v,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.play_circle_outline_rounded, size: 18)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: widget.onSave,
            style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
            icon: const Icon(Icons.save_outlined, size: 18),
            label: const Text('Save Contact Details'),
          ),
        ),
      ],
    );
  }
}

class _LabeledField extends StatelessWidget {
  final String label;
  final Widget child;
  const _LabeledField({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        child,
      ],
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final String label;
  final String hint;
  final bool value;
  final bool danger;
  final ValueChanged<bool> onChanged;

  const _SwitchRow({
    required this.label,
    required this.hint,
    required this.value,
    required this.onChanged,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13.5)),
              const SizedBox(height: 2),
              Text(hint,
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: danger ? AppColors.coral : AppColors.ink,
        ),
      ],
    );
  }
}
