import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/user_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';

/// Module 2 content. Data lives in Firestore (see
/// AdminUserRepository) - this widget just renders whatever
/// [adminUsersStreamProvider] emits and calls repository methods for
/// every mutation (block/unblock, admin role, exam-track note). There
/// is no local mutable copy of the user list anymore: every action
/// writes through to Firestore and the stream reflects it back.
class UserManagementContent extends ConsumerStatefulWidget {
  const UserManagementContent({super.key});

  @override
  ConsumerState<UserManagementContent> createState() =>
      _UserManagementContentState();
}

class _UserManagementContentState extends ConsumerState<UserManagementContent> {
  String _query = '';

  static const _avatarColors = [
    AppColors.marigold,
    AppColors.teal,
    AppColors.violet,
    AppColors.coral,
  ];

  List<UserAccount> _filter(List<UserAccount> users) {
    if (_query.trim().isEmpty) return users;
    final q = _query.trim().toLowerCase();
    return users
        .where((u) =>
            u.name.toLowerCase().contains(q) ||
            u.contact.toLowerCase().contains(q) ||
            u.examTrack.toLowerCase().contains(q))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final usersAsync = ref.watch(adminUsersStreamProvider);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              usersAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 40),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (err, st) => _ErrorState(
                  message: '$err',
                  onRetry: () => ref.invalidate(adminUsersStreamProvider),
                ),
                data: (users) {
                  final visible = _filter(users);
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _SummaryRow(users: users),
                      const SizedBox(height: 20),
                      _SearchField(
                        onChanged: (v) => setState(() => _query = v),
                      ),
                      const SizedBox(height: 16),
                      if (visible.isEmpty)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Center(
                            child: Text(
                              users.isEmpty
                                  ? 'No users yet'
                                  : 'No users match "$_query"',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        )
                      else
                        for (int i = 0; i < visible.length; i++)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _UserRow(
                              user: visible[i],
                              avatarColor:
                                  _avatarColors[i % _avatarColors.length],
                              onView: () => _showDetails(visible[i]),
                              onToggleBlock: () => _toggleBlock(visible[i]),
                              onToggleAdmin: () => _toggleAdmin(visible[i]),
                            ),
                          ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _toggleBlock(UserAccount user) async {
    try {
      await ref
          .read(adminUserRepositoryProvider)
          .setBlocked(user.id, !user.isBlocked);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update ${user.name}: $e')),
      );
    }
  }

  Future<void> _toggleAdmin(UserAccount user) async {
    final makeAdmin = !user.role.isAdmin;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(makeAdmin ? 'Grant admin access?' : 'Revoke admin access?'),
        content: Text(makeAdmin
            ? '${user.name} will get full access to this dashboard.'
            : '${user.name} will lose access to this dashboard.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(makeAdmin ? 'Grant' : 'Revoke'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await ref
          .read(adminUserRepositoryProvider)
          .setAdminRole(user.id, makeAdmin);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(makeAdmin
            ? '${user.name} is now an admin'
            : '${user.name} is no longer an admin')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update admin role: $e')),
      );
    }
  }

  void _showDetails(UserAccount user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(user.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _detailRow('User ID', user.id),
            _detailRow('Phone', user.contact),
            _detailRow('Exam track', user.examTrack),
            _detailRow('Joined on', DateFormat.yMMMd().format(user.joinedOn)),
            _detailRow('Status', user.isBlocked ? 'Blocked' : 'Active'),
            _detailRow('Plan', user.isPremium ? 'Premium' : 'Free'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(label,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
          ),
          Expanded(
              child: Text(value,
                  style: const TextStyle(fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Center(
        child: Column(
          children: [
            Text('Could not load users',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(message,
                style: const TextStyle(
                    fontSize: 12.5, color: AppColors.textSecondary),
                textAlign: TextAlign.center),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 2 · User Management',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('उपयोगकर्ता प्रबंधन',
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final List<UserAccount> users;
  const _SummaryRow({required this.users});

  @override
  Widget build(BuildContext context) {
    final blocked = users.where((u) => u.isBlocked).length;
    final premium = users.where((u) => u.isPremium).length;
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        _chip('${users.length} total', AppColors.ink),
        _chip('$blocked blocked', AppColors.coral),
        _chip('$premium premium', AppColors.marigoldDeep),
      ],
    );
  }

  Widget _chip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12.5),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const _SearchField({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return TextField(
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: 'Search users by name, phone, or exam track',
        prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textSecondary),
        filled: true,
        fillColor: AppColors.surface,
        contentPadding: const EdgeInsets.symmetric(vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.ink, width: 1.4),
        ),
      ),
    );
  }
}

class _UserRow extends StatelessWidget {
  final UserAccount user;
  final Color avatarColor;
  final VoidCallback onView;
  final VoidCallback onToggleBlock;
  final VoidCallback onToggleAdmin;

  const _UserRow({
    required this.user,
    required this.avatarColor,
    required this.onView,
    required this.onToggleBlock,
    required this.onToggleAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final narrow = constraints.maxWidth < 640;
      final info = InkWell(
        onTap: onView,
        borderRadius: BorderRadius.circular(12),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: avatarColor.withOpacity(0.15),
              child: Text(
                user.name.trim().isEmpty
                    ? '?'
                    : user.name.trim().split(' ').map((s) => s[0]).take(2).join(),
                style: TextStyle(color: avatarColor, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user.name,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 15)),
                  Text(user.contact,
                      style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.canvas,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Text(
                      user.examTrack,
                      style: const TextStyle(
                          fontSize: 11.5, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

      final controls = Wrap(
        spacing: 12,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          // Read-only: premium comes from a real subscription purchase
          // (users/{uid}/subscription/current), not something an
          // admin can flip by hand here.
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: user.isPremium
                  ? AppColors.marigold.withOpacity(0.15)
                  : AppColors.border.withOpacity(0.5),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              user.isPremium ? 'Premium' : 'Free',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: user.isPremium
                    ? AppColors.marigoldDeep
                    : AppColors.textSecondary,
              ),
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                user.isBlocked ? 'Blocked' : 'Active',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: user.isBlocked ? AppColors.coral : AppColors.teal,
                ),
              ),
              Switch(
                value: !user.isBlocked,
                activeColor: AppColors.teal,
                onChanged: (_) => onToggleBlock(),
              ),
            ],
          ),
          IconButton(
            tooltip: user.role.isAdmin
                ? 'Revoke admin access'
                : 'Grant admin access',
            icon: Icon(
              user.role.isAdmin
                  ? Icons.admin_panel_settings
                  : Icons.admin_panel_settings_outlined,
              color: user.role.isAdmin
                  ? AppColors.violet
                  : AppColors.textSecondary,
            ),
            onPressed: onToggleAdmin,
          ),
        ],
      );

      return Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: narrow
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    info,
                    const SizedBox(height: 10),
                    controls,
                  ],
                )
              : Row(
                  children: [
                    Expanded(child: info),
                    const SizedBox(width: 12),
                    controls,
                  ],
                ),
        ),
      );
    });
  }
}
