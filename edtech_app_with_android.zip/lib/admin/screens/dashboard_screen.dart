import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/analytics_model.dart';
import '../providers/admin_data_providers.dart';
import '../admin_theme.dart';
import '../widgets/stat_card.dart';
import '../widgets/growth_chart_card.dart';
import '../widgets/revenue_chart_card.dart';
import '../widgets/activity_ring_card.dart';

/// Module 1 content — the sidebar/Scaffold living around this now belongs
/// to AppShell, so this widget only renders the dashboard body.
class DashboardContent extends ConsumerWidget {
  const DashboardContent({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 24),
              _StatGrid(constraints: constraints),
              const SizedBox(height: 24),
              Text('Graphs & Charts',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              _ChartGrid(isWide: isWide),
            ],
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 1 · Dashboard',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              Text(
                'Overview of your Hindi-medium exam-prep platform',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
        CircleAvatar(
          backgroundColor: AppColors.marigold.withOpacity(0.2),
          child: const Text('Rk',
              style: TextStyle(
                  color: AppColors.marigoldDeep, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

class _StatGrid extends ConsumerWidget {
  final BoxConstraints constraints;
  const _StatGrid({required this.constraints});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final overviewAsync = ref.watch(adminAnalyticsOverviewProvider);
    return overviewAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Column(
            children: [
              const Text('Could not load dashboard stats',
                  style: TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminAnalyticsOverviewProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (overview) => _grid(overview),
    );
  }

  Widget _grid(AnalyticsOverview overview) {
    final width = constraints.maxWidth;
    int columns = 1;
    if (width >= 1200) {
      columns = 5;
    } else if (width >= 900) {
      columns = 3;
    } else if (width >= 600) {
      columns = 2;
    }

    final cards = [
      StatCard(
        label: 'Total Users',
        hindiLabel: 'कुल उपयोगकर्ता',
        value: _fmt(overview.totalUsers.toDouble()),
        icon: Icons.groups_rounded,
        accent: AppColors.ink,
      ),
      StatCard(
        label: 'Active Users (30d)',
        hindiLabel: 'सक्रिय उपयोगकर्ता',
        value: _fmt(overview.activeUsersLast30d.toDouble()),
        icon: Icons.bolt_rounded,
        accent: AppColors.teal,
      ),
      StatCard(
        label: 'Revenue',
        hindiLabel: 'राजस्व',
        value: '₹${_fmt(overview.totalRevenueInr)}',
        icon: Icons.currency_rupee_rounded,
        accent: AppColors.marigold,
      ),
      StatCard(
        label: 'Total Courses',
        hindiLabel: 'कुल पाठ्यक्रम',
        value: _fmt(overview.totalCourses.toDouble()),
        icon: Icons.menu_book_rounded,
        accent: AppColors.violet,
      ),
      StatCard(
        label: 'Total Quizzes',
        hindiLabel: 'कुल क्विज़',
        value: _fmt(overview.totalQuizzes.toDouble()),
        icon: Icons.quiz_rounded,
        accent: AppColors.coral,
      ),
    ];

    return GridView.count(
      crossAxisCount: columns,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: columns == 1 ? 2.2 : 1.35,
      children: cards,
    );
  }

  String _fmt(double value) {
    if (value >= 100000) {
      return '${(value / 100000).toStringAsFixed(1)}L';
    }
    if (value >= 1000) {
      return '${(value / 1000).toStringAsFixed(1)}k';
    }
    return value.toStringAsFixed(0);
  }
}

class _ChartGrid extends StatelessWidget {
  final bool isWide;
  const _ChartGrid({required this.isWide});

  @override
  Widget build(BuildContext context) {
    if (isWide) {
      return Column(
        children: [
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: const [
                Expanded(flex: 2, child: GrowthChartCard()),
                SizedBox(width: 16),
                Expanded(flex: 1, child: ActivityRingCard()),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const RevenueChartCard(),
        ],
      );
    }
    return const Column(
      children: [
        GrowthChartCard(),
        SizedBox(height: 16),
        ActivityRingCard(),
        SizedBox(height: 16),
        RevenueChartCard(),
      ],
    );
  }
}
