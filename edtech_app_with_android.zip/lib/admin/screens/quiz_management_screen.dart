import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/quiz_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';
import '../widgets/import_questions_dialog.dart';
import '../widgets/quiz_question_form_dialog.dart';

enum _QuizTab { questions, import, results, leaderboard }

/// Module 4 content. Quiz list and question bank stream straight from
/// Firestore (AdminQuizRepository); Results/Leaderboard are one-shot
/// aggregate reads (see adminQuizResultsProvider/
/// adminQuizLeaderboardProvider) refreshed with a pull-to-refresh-style
/// retry button rather than a live stream, since they scan
/// `quizAttempts` across every user. A pill sub-nav at the top switches
/// between the module's four sections.
class QuizManagementContent extends ConsumerStatefulWidget {
  const QuizManagementContent({super.key});

  @override
  ConsumerState<QuizManagementContent> createState() =>
      _QuizManagementContentState();
}

class _QuizManagementContentState extends ConsumerState<QuizManagementContent> {
  _QuizTab _tab = _QuizTab.questions;
  String _questionQuizFilter = 'All';
  String _resultsQuizFilter = 'All';

  Future<void> _openAddQuestion(
      List<Quiz> quizzes, {QuizQuestion? existing}) async {
    final result = await showDialog<QuizQuestion>(
      context: context,
      builder: (_) => QuizQuestionFormDialog(
        quizzes: quizzes,
        existing: existing,
        initialQuizId:
            _questionQuizFilter == 'All' ? null : _questionQuizFilter,
      ),
    );
    if (result == null || result.quizId == null) return;

    try {
      final repo = ref.read(adminQuizRepositoryProvider);
      if (existing == null) {
        await repo.addQuestion(result.quizId!, result);
      } else {
        await repo.updateQuestion(result.quizId!, result);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(existing == null
            ? 'Question added to the bank'
            : 'Question updated')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save question: $e')),
      );
    }
  }

  Future<void> _openImport(List<Quiz> quizzes) async {
    final imported = await showDialog<List<QuizQuestion>>(
      context: context,
      builder: (_) => ImportQuestionsDialog(quizzes: quizzes),
    );
    if (imported == null || imported.isEmpty) return;

    final repo = ref.read(adminQuizRepositoryProvider);
    int saved = 0;
    for (final q in imported) {
      if (q.quizId == null) continue;
      try {
        await repo.addQuestion(q.quizId!, q);
        saved++;
      } catch (_) {
        // keep going - report the partial count below
      }
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Imported $saved of ${imported.length} questions')),
    );
  }

  void _deleteQuestion(QuizQuestion q, String quizTitle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete question?'),
        content: Text('This removes it from $quizTitle\'s bank.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            onPressed: () async {
              Navigator.of(context).pop();
              if (q.quizId == null || q.id == null) return;
              try {
                await ref
                    .read(adminQuizRepositoryProvider)
                    .removeQuestion(q.quizId!, q.id!);
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Could not delete: $e')),
                );
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final quizzesAsync = ref.watch(adminQuizzesStreamProvider);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              _TabPills(active: _tab, onSelect: (t) => setState(() => _tab = t)),
              const SizedBox(height: 20),
              quizzesAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 40),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (err, st) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Center(child: Text('Could not load quizzes: $err')),
                ),
                data: (quizzes) => switch (_tab) {
                  _QuizTab.questions => _QuestionsBank(
                      quizzes: quizzes,
                      activeFilter: _questionQuizFilter,
                      onFilter: (v) =>
                          setState(() => _questionQuizFilter = v),
                      onAdd: () => _openAddQuestion(quizzes),
                      onEdit: (q) =>
                          _openAddQuestion(quizzes, existing: q),
                      onDelete: (q, title) => _deleteQuestion(q, title),
                    ),
                  _QuizTab.import =>
                    _ImportView(onImport: () => _openImport(quizzes)),
                  _QuizTab.results => _ResultsBank(
                      quizzes: quizzes,
                      activeFilter: _resultsQuizFilter,
                      onFilter: (v) => setState(() => _resultsQuizFilter = v),
                    ),
                  _QuizTab.leaderboard => const _LeaderboardBank(),
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _QuestionsBank extends ConsumerWidget {
  final List<Quiz> quizzes;
  final String activeFilter;
  final ValueChanged<String> onFilter;
  final VoidCallback onAdd;
  final ValueChanged<QuizQuestion> onEdit;
  final void Function(QuizQuestion, String quizTitle) onDelete;

  const _QuestionsBank({
    required this.quizzes,
    required this.activeFilter,
    required this.onFilter,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bankAsync = ref.watch(adminQuestionBankStreamProvider);
    return bankAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text('Could not load questions: $err')),
      ),
      data: (questions) => _QuestionsView(
        quizzes: quizzes,
        questions: questions,
        activeFilter: activeFilter,
        onFilter: onFilter,
        onAdd: onAdd,
        onEdit: onEdit,
        onDelete: onDelete,
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 4 · Quiz Management',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('प्रश्नोत्तरी प्रबंधन',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TabPills extends StatelessWidget {
  final _QuizTab active;
  final ValueChanged<_QuizTab> onSelect;
  const _TabPills({required this.active, required this.onSelect});

  static const _tabs = [
    (_QuizTab.questions, 'Add Questions', Icons.playlist_add_rounded),
    (_QuizTab.import, 'Import Questions', Icons.upload_file_rounded),
    (_QuizTab.results, 'Results', Icons.fact_check_rounded),
    (_QuizTab.leaderboard, 'Leaderboard', Icons.emoji_events_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final (tab, label, icon) in _tabs)
          ChoiceChip(
            label: Text(label),
            avatar: Icon(icon,
                size: 16,
                color: active == tab ? Colors.white : AppColors.textSecondary),
            selected: active == tab,
            onSelected: (_) => onSelect(tab),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == tab ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _QuizFilterChips extends StatelessWidget {
  final List<Quiz> quizzes;
  final String active;
  final ValueChanged<String> onSelect;
  const _QuizFilterChips(
      {required this.quizzes, required this.active, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final all = ['All', ...quizzes.map((q) => q.id)];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final id in all)
          ChoiceChip(
            label: Text(id == 'All'
                ? 'All quizzes'
                : quizzes.firstWhere((q) => q.id == id).title),
            selected: active == id,
            onSelected: (_) => onSelect(id),
            selectedColor: AppColors.teal,
            labelStyle: TextStyle(
              color: active == id ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _QuestionsView extends StatelessWidget {
  final List<Quiz> quizzes;
  final List<QuizQuestion> questions;
  final String activeFilter;
  final ValueChanged<String> onFilter;
  final VoidCallback onAdd;
  final ValueChanged<QuizQuestion> onEdit;
  final void Function(QuizQuestion, String quizTitle) onDelete;

  const _QuestionsView({
    required this.quizzes,
    required this.questions,
    required this.activeFilter,
    required this.onFilter,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final visible = activeFilter == 'All'
        ? questions
        : questions.where((q) => q.quizId == activeFilter).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text('${questions.length} questions in the bank',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 15)),
            ),
            FilledButton.icon(
              onPressed: quizzes.isEmpty ? null : onAdd,
              style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
              icon: const Icon(Icons.add_rounded, size: 18),
              label: const Text('Add Question'),
            ),
          ],
        ),
        const SizedBox(height: 14),
        _QuizFilterChips(
            quizzes: quizzes, active: activeFilter, onSelect: onFilter),
        const SizedBox(height: 16),
        if (visible.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text(
                  quizzes.isEmpty
                      ? 'No quizzes yet — create one in Firestore first'
                      : 'No questions yet — add the first one',
                  style: Theme.of(context).textTheme.bodyMedium),
            ),
          )
        else
          for (final q in visible)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _QuestionCard(
                question: q,
                quizTitle: quizzes
                    .firstWhere((quiz) => quiz.id == q.quizId,
                        orElse: () => Quiz(
                            id: q.quizId ?? '', title: 'Unknown quiz'))
                    .title,
                onEdit: () => onEdit(q),
                onDelete: () => onDelete(
                    q,
                    quizzes
                        .firstWhere((quiz) => quiz.id == q.quizId,
                            orElse: () => Quiz(
                                id: q.quizId ?? '', title: 'Unknown quiz'))
                        .title),
              ),
            ),
      ],
    );
  }
}

class _QuestionCard extends StatelessWidget {
  final QuizQuestion question;
  final String quizTitle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _QuestionCard({
    required this.question,
    required this.quizTitle,
    required this.onEdit,
    required this.onDelete,
  });

  Color get _difficultyColor => switch (question.difficulty) {
        'Easy' => AppColors.teal,
        'Hard' => AppColors.coral,
        _ => AppColors.marigoldDeep,
      };

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.canvas,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Text(quizTitle,
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.textSecondary)),
                ),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _difficultyColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(question.difficulty ?? 'Medium',
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _difficultyColor)),
                ),
                const Spacer(),
                Text('${question.marks ?? 1} marks',
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textSecondary)),
                IconButton(
                  tooltip: 'Edit question',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.edit_outlined,
                      size: 18, color: AppColors.textSecondary),
                  onPressed: onEdit,
                ),
                IconButton(
                  tooltip: 'Delete question',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.delete_outline_rounded,
                      size: 18, color: AppColors.coral),
                  onPressed: onDelete,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(question.text,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontSize: 14.5)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                for (int i = 0; i < question.options.length; i++)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: i == question.correctIndex
                          ? AppColors.teal.withOpacity(0.12)
                          : AppColors.canvas,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: i == question.correctIndex
                            ? AppColors.teal
                            : AppColors.border,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (i == question.correctIndex)
                          const Padding(
                            padding: EdgeInsets.only(right: 4),
                            child: Icon(Icons.check_circle_rounded,
                                size: 13, color: AppColors.teal),
                          ),
                        Text(question.options[i],
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: i == question.correctIndex
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                              color: i == question.correctIndex
                                  ? AppColors.teal
                                  : AppColors.textPrimary,
                            )),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ImportView extends StatelessWidget {
  final VoidCallback onImport;
  const _ImportView({required this.onImport});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.violet.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.upload_file_rounded,
                  color: AppColors.violet, size: 24),
            ),
            const SizedBox(height: 16),
            Text('Bulk import questions',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            const Text(
              'Upload an Excel (.xlsx) or JSON file to add many questions '
              'to a quiz at once, instead of adding them one by one. '
              'Each row/entry needs the question text, four options, the '
              'correct option, difficulty, and marks.',
              style: TextStyle(fontSize: 13.5, color: AppColors.textSecondary, height: 1.5),
            ),
            const SizedBox(height: 20),
            Wrap(
              spacing: 16,
              runSpacing: 12,
              children: const [
                _FormatHint(
                  icon: Icons.table_chart_outlined,
                  title: '.xlsx',
                  subtitle: 'One question per row',
                ),
                _FormatHint(
                  icon: Icons.data_object_rounded,
                  title: '.json',
                  subtitle: 'Array of question objects',
                ),
              ],
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onImport,
              style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
              icon: const Icon(Icons.upload_rounded, size: 18),
              label: const Text('Choose file to import'),
            ),
          ],
        ),
      ),
    );
  }
}

class _FormatHint extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _FormatHint(
      {required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.canvas,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 13)),
              Text(subtitle,
                  style: const TextStyle(
                      fontSize: 11.5, color: AppColors.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ResultsBank extends ConsumerWidget {
  final List<Quiz> quizzes;
  final String activeFilter;
  final ValueChanged<String> onFilter;

  const _ResultsBank({
    required this.quizzes,
    required this.activeFilter,
    required this.onFilter,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final resultsAsync = ref.watch(adminQuizResultsProvider);
    return resultsAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load results: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminQuizResultsProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (results) => _ResultsView(
        quizzes: quizzes,
        results: results,
        activeFilter: activeFilter,
        onFilter: onFilter,
      ),
    );
  }
}

class _ResultsView extends StatelessWidget {
  final List<Quiz> quizzes;
  final List<QuizResult> results;
  final String activeFilter;
  final ValueChanged<String> onFilter;

  const _ResultsView({
    required this.quizzes,
    required this.results,
    required this.activeFilter,
    required this.onFilter,
  });

  @override
  Widget build(BuildContext context) {
    final visible = activeFilter == 'All'
        ? results
        : results.where((r) => r.quizId == activeFilter).toList();
    final avg = visible.isEmpty
        ? 0.0
        : visible.map((r) => r.percentage).reduce((a, b) => a + b) /
            visible.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _summaryChip('${visible.length} attempts', AppColors.ink),
            _summaryChip(
                'Avg score ${avg.toStringAsFixed(1)}%', AppColors.teal),
          ],
        ),
        const SizedBox(height: 14),
        _QuizFilterChips(
            quizzes: quizzes, active: activeFilter, onSelect: onFilter),
        const SizedBox(height: 16),
        if (visible.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No attempts for this quiz yet',
                  style: Theme.of(context).textTheme.bodyMedium),
            ),
          )
        else
          Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                for (int i = 0; i < visible.length; i++)
                  _ResultRow(result: visible[i], striped: i.isOdd),
              ],
            ),
          ),
      ],
    );
  }

  Widget _summaryChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style:
              TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12.5)),
    );
  }
}

class _ResultRow extends StatelessWidget {
  final QuizResult result;
  final bool striped;
  const _ResultRow({required this.result, required this.striped});

  Color get _scoreColor {
    if (result.percentage >= 75) return AppColors.teal;
    if (result.percentage >= 50) return AppColors.marigoldDeep;
    return AppColors.coral;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: striped ? AppColors.canvas.withOpacity(0.5) : null,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(result.userName,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                Text(result.quizTitle,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '${result.score}/${result.totalMarks}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              alignment: Alignment.centerLeft,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _scoreColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('${result.percentage.toStringAsFixed(0)}%',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: _scoreColor)),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              DateFormat.yMMMd().format(result.attemptedOn),
              style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

class _LeaderboardBank extends ConsumerWidget {
  const _LeaderboardBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final leaderboardAsync = ref.watch(adminQuizLeaderboardProvider);
    return leaderboardAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load leaderboard: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminQuizLeaderboardProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (entries) => _LeaderboardView(entries: entries),
    );
  }
}

class _LeaderboardView extends StatelessWidget {
  final List<LeaderboardEntry> entries;
  const _LeaderboardView({required this.entries});

  static const _medalColors = [
    Color(0xFFFFD700),
    Color(0xFFC0C0C0),
    Color(0xFFCD7F32),
  ];

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Text('No quiz attempts yet',
              style: Theme.of(context).textTheme.bodyMedium),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Overall ranking by total score',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontSize: 15)),
        const SizedBox(height: 14),
        for (int i = 0; i < entries.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _LeaderboardCard(
              rank: i + 1,
              entry: entries[i],
              medalColor: i < 3 ? _medalColors[i] : null,
            ),
          ),
      ],
    );
  }
}

class _LeaderboardCard extends StatelessWidget {
  final int rank;
  final LeaderboardEntry entry;
  final Color? medalColor;

  const _LeaderboardCard({
    required this.rank,
    required this.entry,
    this.medalColor,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: medalColor != null
          ? medalColor!.withOpacity(0.06)
          : AppColors.surface,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            SizedBox(
              width: 36,
              child: medalColor != null
                  ? Icon(Icons.emoji_events_rounded,
                      color: medalColor, size: 24)
                  : Text('#$rank',
                      style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppColors.textSecondary)),
            ),
            const SizedBox(width: 8),
            CircleAvatar(
              backgroundColor: AppColors.violet.withOpacity(0.15),
              child: Text(
                entry.userName.trim().isEmpty
                    ? '?'
                    : entry.userName.trim().split(' ').map((s) => s[0]).take(2).join(),
                style: const TextStyle(
                    color: AppColors.violet, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(entry.userName,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 14.5)),
                  Text(
                    '${entry.examTrack} · ${entry.quizzesTaken} quizzes · '
                    '${entry.avgAccuracy.toStringAsFixed(1)}% avg accuracy',
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            Text(
              '${entry.totalScore} pts',
              style: const TextStyle(
                  fontWeight: FontWeight.w700, color: AppColors.ink, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
