import 'package:flutter/material.dart';
import '../widgets/side_nav.dart';
import 'analytics_screen.dart';
import 'course_management_screen.dart';
import 'dashboard_screen.dart';
import 'live_class_screen.dart';
import 'notification_screen.dart';
import 'payments_screen.dart';
import 'quiz_management_screen.dart';
import 'settings_screen.dart';
import 'user_management_screen.dart';

/// Hosts the sidebar (or drawer, on narrow screens) and swaps in the
/// content for whichever module is selected. Add a new module by adding
/// a matching case to [_content], keyed to that module's index in
/// [SideNav.items].
class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _selectedIndex = 0;

  Widget _content(int i) {
    switch (i) {
      case 0:
        return const DashboardContent();
      case 1:
        return const UserManagementContent();
      case 2:
        return const CourseManagementContent();
      case 3:
        return const QuizManagementContent();
      case 4:
        return const LiveClassContent();
      case 5:
        return const PaymentsContent();
      case 6:
        return const AnalyticsContent();
      case 7:
        return const SettingsContent();
      case 8:
        return const NotificationContent();
      default:
        return _ComingSoon(moduleName: SideNav.items[i].$1);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: SideNav(
          selectedIndex: _selectedIndex,
          onSelect: (i) {
            Navigator.of(context).pop(); // close the drawer
            _select(i);
          },
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 900;
          return Row(
            children: [
              if (isWide)
                SideNav(selectedIndex: _selectedIndex, onSelect: _select),
              Expanded(child: _content(_selectedIndex)),
            ],
          );
        },
      ),
    );
  }

  void _select(int i) {
    setState(() => _selectedIndex = i);
  }
}

class _ComingSoon extends StatelessWidget {
  final String moduleName;
  const _ComingSoon({required this.moduleName});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '$moduleName — coming soon',
        style: Theme.of(context).textTheme.titleMedium,
      ),
    );
  }
}
