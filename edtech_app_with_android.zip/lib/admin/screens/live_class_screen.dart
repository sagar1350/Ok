import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/course_model.dart';
import '../models/live_class_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';
import '../widgets/attendance_dialog.dart';
import '../widgets/live_class_form_dialog.dart';

/// Module 5 content. The class schedule streams straight from
/// Firestore (AdminLiveClassRepository); every mutation writes
/// through it. There's still no real Zoom/Google Meet API
/// integration — meeting links are a generated placeholder the admin
/// can hand-edit (see live_class_model.dart's doc comment).
class LiveClassContent extends ConsumerStatefulWidget {
  const LiveClassContent({super.key});

  @override
  ConsumerState<LiveClassContent> createState() => _LiveClassContentState();
}

class _LiveClassContentState extends ConsumerState<LiveClassContent> {
  String _activeCategory = 'All';

  List<LiveClass> _visible(List<LiveClass> classes) {
    if (_activeCategory == 'All') return classes;
    return classes.where((c) => c.category == _activeCategory).toList();
  }

  Future<void> _openForm({LiveClass? existing}) async {
    final result = await showDialog<LiveClass>(
      context: context,
      builder: (_) => LiveClassFormDialog(existing: existing),
    );
    if (result == null) return;
    try {
      final repo = ref.read(adminLiveClassRepositoryProvider);
      if (existing == null) {
        await repo.createLiveClass(result);
      } else {
        await repo.updateLiveClass(result);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(existing == null
            ? '"${result.title}" scheduled'
            : '"${result.title}" updated')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save class: $e')),
      );
    }
  }

  Future<void> _openAttendance(LiveClass liveClass) async {
    var roster = liveClass.attendees;
    // A freshly-scheduled class has no attendees recorded yet - seed
    // the checklist from every current user instead of showing an
    // empty dialog with nobody to mark present.
    if (roster.isEmpty) {
      try {
        final users =
            await ref.read(adminUserRepositoryProvider).watchUsers().first;
        roster = users
            .map((u) => Attendee(userId: u.id, name: u.name, present: false))
            .toList();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not load the user roster: $e')),
        );
        return;
      }
    }

    if (!mounted) return;
    final updated = await showDialog<List<Attendee>>(
      context: context,
      builder: (_) => AttendanceDialog(
        classTitle: liveClass.title,
        attendees: roster,
      ),
    );
    if (updated == null) return;
    try {
      await ref
          .read(adminLiveClassRepositoryProvider)
          .saveAttendance(liveClass.id, updated);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Attendance saved for "${liveClass.title}"')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save attendance: $e')),
      );
    }
  }

  void _copyLink(String link) {
    Clipboard.setData(ClipboardData(text: link));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Meeting link copied')),
    );
  }

  void _confirmDelete(LiveClass liveClass) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Cancel class?'),
        content: Text(
            '"${liveClass.title}" will be removed from the schedule. This can\'t be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Keep it'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            onPressed: () async {
              Navigator.of(context).pop();
              try {
                await ref
                    .read(adminLiveClassRepositoryProvider)
                    .deleteLiveClass(liveClass.id);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('"${liveClass.title}" was cancelled')),
                );
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Could not cancel: $e')),
                );
              }
            },
            child: const Text('Cancel class'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final classesAsync = ref.watch(adminLiveClassesStreamProvider);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide, onSchedule: () => _openForm()),
              const SizedBox(height: 20),
              _CategoryChips(
                active: _activeCategory,
                onSelect: (c) => setState(() => _activeCategory = c),
              ),
              const SizedBox(height: 20),
              classesAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 40),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (err, st) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Center(
                    child: Column(
                      children: [
                        Text('Could not load live classes: $err'),
                        const SizedBox(height: 8),
                        OutlinedButton(
                          onPressed: () =>
                              ref.invalidate(adminLiveClassesStreamProvider),
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  ),
                ),
                data: (classes) {
                  final visible = _visible(classes);
                  if (visible.isEmpty) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      child: Center(
                        child: Text(
                          classes.isEmpty
                              ? 'No live classes yet — tap "Schedule Class" to add one'
                              : 'No live classes in "$_activeCategory" yet',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                    );
                  }
                  return Column(
                    children: [
                      for (final liveClass in visible)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _LiveClassCard(
                            liveClass: liveClass,
                            onEdit: () => _openForm(existing: liveClass),
                            onDelete: () => _confirmDelete(liveClass),
                            onCopyLink: () => _copyLink(liveClass.meetingLink),
                            onAttendance: () => _openAttendance(liveClass),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  final VoidCallback onSchedule;
  const _Header({required this.isWide, required this.onSchedule});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 5 · Live Classes',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('लाइव कक्षाएं',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
        FilledButton.icon(
          onPressed: onSchedule,
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          icon: const Icon(Icons.add_rounded, size: 18),
          label: const Text('Schedule Class'),
        ),
      ],
    );
  }
}

class _CategoryChips extends StatelessWidget {
  final String active;
  final ValueChanged<String> onSelect;
  const _CategoryChips({required this.active, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final all = ['All', ...courseCategories];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final c in all)
          ChoiceChip(
            label: Text(c),
            selected: active == c,
            onSelected: (_) => onSelect(c),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == c ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _LiveClassCard extends StatelessWidget {
  final LiveClass liveClass;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onCopyLink;
  final VoidCallback onAttendance;

  const _LiveClassCard({
    required this.liveClass,
    required this.onEdit,
    required this.onDelete,
    required this.onCopyLink,
    required this.onAttendance,
  });

  Color get _platformColor => liveClass.platform == LiveClassPlatform.zoom
      ? AppColors.violet
      : AppColors.teal;

  IconData get _platformIcon => liveClass.platform == LiveClassPlatform.zoom
      ? Icons.videocam_rounded
      : Icons.duo_rounded;

  @override
  Widget build(BuildContext context) {
    final upcoming = liveClass.isUpcoming;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _platformColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(_platformIcon, color: _platformColor, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 8,
                        children: [
                          Text(liveClass.title,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(fontSize: 15)),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: (upcoming
                                      ? AppColors.teal
                                      : AppColors.textSecondary)
                                  .withOpacity(0.12),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              upcoming ? 'Upcoming' : 'Completed',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w600,
                                color: upcoming
                                    ? AppColors.teal
                                    : AppColors.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${liveClass.category} · ${liveClass.instructor}',
                        style: const TextStyle(
                            fontSize: 12.5, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.event_rounded,
                              size: 13, color: AppColors.textSecondary),
                          const SizedBox(width: 4),
                          Text(
                            DateFormat('EEE, MMM d · h:mm a')
                                .format(liveClass.scheduledAt),
                            style: const TextStyle(
                                fontSize: 12.5, color: AppColors.textSecondary),
                          ),
                          const SizedBox(width: 10),
                          const Icon(Icons.timer_outlined,
                              size: 13, color: AppColors.textSecondary),
                          const SizedBox(width: 4),
                          Text('${liveClass.durationMinutes} min',
                              style: const TextStyle(
                                  fontSize: 12.5,
                                  color: AppColors.textSecondary)),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Edit class',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.edit_outlined,
                      size: 18, color: AppColors.textSecondary),
                  onPressed: onEdit,
                ),
                IconButton(
                  tooltip: 'Cancel class',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.delete_outline_rounded,
                      size: 18, color: AppColors.coral),
                  onPressed: onDelete,
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(height: 1),
            const SizedBox(height: 12),
            LayoutBuilder(builder: (context, constraints) {
              final narrow = constraints.maxWidth < 560;
              final linkRow = InkWell(
                onTap: onCopyLink,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.canvas,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(liveClass.platform.label,
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: _platformColor)),
                      const SizedBox(width: 6),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 200),
                        child: Text(
                          liveClass.meetingLink,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 12, color: AppColors.textSecondary),
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.copy_rounded,
                          size: 13, color: AppColors.textSecondary),
                    ],
                  ),
                ),
              );
              final attendanceButton = OutlinedButton.icon(
                onPressed: onAttendance,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  foregroundColor: AppColors.textPrimary,
                ),
                icon: const Icon(Icons.how_to_reg_rounded, size: 16),
                label: Text(liveClass.attendees.isEmpty
                    ? 'Attendance'
                    : 'Attendance · ${liveClass.presentCount}/${liveClass.attendees.length}'),
              );
              return narrow
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        linkRow,
                        const SizedBox(height: 8),
                        attendanceButton,
                      ],
                    )
                  : Row(
                      children: [
                        linkRow,
                        const Spacer(),
                        attendanceButton,
                      ],
                    );
            }),
          ],
        ),
      ),
    );
  }
}
