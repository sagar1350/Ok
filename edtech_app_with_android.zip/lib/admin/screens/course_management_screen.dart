import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';
import '../widgets/course_form_dialog.dart';

/// Module 3 content. The course list itself comes straight from
/// Firestore via [adminCoursesStreamProvider] - every mutation here
/// (add/edit/publish/delete) writes through AdminCourseRepository and
/// the stream reflects it back; there's no separate local copy to
/// keep in sync.
class CourseManagementContent extends ConsumerStatefulWidget {
  const CourseManagementContent({super.key});

  @override
  ConsumerState<CourseManagementContent> createState() =>
      _CourseManagementContentState();
}

class _CourseManagementContentState
    extends ConsumerState<CourseManagementContent> {
  String _activeCategory = 'All';
  bool _busy = false;

  static const _categoryColors = [
    AppColors.marigold,
    AppColors.teal,
    AppColors.violet,
    AppColors.coral,
  ];

  Color _colorFor(String category) {
    final i = courseCategories.indexOf(category);
    return _categoryColors[(i < 0 ? 0 : i) % _categoryColors.length];
  }

  List<Course> _visible(List<Course> courses) {
    if (_activeCategory == 'All') return courses;
    return courses.where((c) => c.category == _activeCategory).toList();
  }

  Future<void> _openForm({Course? existing}) async {
    final result = await showDialog<Course>(
      context: context,
      builder: (_) => CourseFormDialog(existing: existing),
    );
    if (result == null) return;

    setState(() => _busy = true);
    final repo = ref.read(adminCourseRepositoryProvider);
    try {
      String courseId = result.id;
      // New course: create the doc first so we have an id to upload
      // media under, then patch in whatever got uploaded.
      if (courseId.isEmpty) {
        courseId = await repo.createCourse(result);
      }

      String? thumbnailUrl = result.thumbnailUrl;
      String? pdfUrl = result.pdfUrl;
      String? videoUrl = result.videoUrl;

      if (result.thumbnailBytes != null) {
        thumbnailUrl =
            await repo.uploadThumbnail(courseId, result.thumbnailBytes!);
      }
      if (result.pdfBytes != null) {
        pdfUrl = await repo.uploadNotesPdf(courseId, result.pdfBytes!);
      }
      if (result.videoBytes != null) {
        videoUrl = await repo.uploadLectureVideo(courseId, result.videoBytes!);
      }

      await repo.updateCourse(Course(
        id: courseId,
        title: result.title,
        category: result.category,
        description: result.description,
        status: result.status,
        thumbnailUrl: thumbnailUrl,
        pdfUrl: pdfUrl,
        videoUrl: videoUrl,
        createdOn: result.createdOn,
      ));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save "${result.title}": $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _confirmDelete(Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete course?'),
        content: Text(
            '"${course.title}" will be removed for all learners. This can\'t be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            onPressed: () async {
              Navigator.of(context).pop();
              try {
                await ref
                    .read(adminCourseRepositoryProvider)
                    .deleteCourse(course.id);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('"${course.title}" was deleted')),
                );
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Could not delete: $e')),
                );
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final coursesAsync = ref.watch(adminCoursesStreamProvider);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        int columns = 1;
        if (constraints.maxWidth >= 1100) {
          columns = 3;
        } else if (constraints.maxWidth >= 700) {
          columns = 2;
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(
                isWide: isWide,
                busy: _busy,
                onAdd: _busy ? null : () => _openForm(),
              ),
              const SizedBox(height: 20),
              _CategoryChips(
                active: _activeCategory,
                onSelect: (c) => setState(() => _activeCategory = c),
              ),
              const SizedBox(height: 20),
              coursesAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 40),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (err, st) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Center(
                    child: Column(
                      children: [
                        Text('Could not load courses: $err'),
                        const SizedBox(height: 8),
                        OutlinedButton(
                          onPressed: () =>
                              ref.invalidate(adminCoursesStreamProvider),
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  ),
                ),
                data: (courses) {
                  final visible = _visible(courses);
                  if (visible.isEmpty) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      child: Center(
                        child: Text(
                          courses.isEmpty
                              ? 'No courses yet — tap "Add Course" to create one'
                              : 'No courses in "$_activeCategory" yet',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                    );
                  }
                  return GridView.count(
                    crossAxisCount: columns,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: columns == 1 ? 1.5 : 0.92,
                    children: [
                      for (final course in visible)
                        _CourseCard(
                          course: course,
                          color: _colorFor(course.category),
                          onEdit: () => _openForm(existing: course),
                          onDelete: () => _confirmDelete(course),
                          onStatusChange: (status) => ref
                              .read(adminCourseRepositoryProvider)
                              .setStatus(course.id, status),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  final bool busy;
  final VoidCallback? onAdd;
  const _Header({required this.isWide, required this.busy, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 3 · Course Management',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('पाठ्यक्रम प्रबंधन',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
        FilledButton.icon(
          onPressed: onAdd,
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          icon: busy
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.add_rounded, size: 18),
          label: const Text('Add Course'),
        ),
      ],
    );
  }
}

class _CategoryChips extends StatelessWidget {
  final String active;
  final ValueChanged<String> onSelect;
  const _CategoryChips({required this.active, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final all = ['All', ...courseCategories];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final c in all)
          ChoiceChip(
            label: Text(c),
            selected: active == c,
            onSelected: (_) => onSelect(c),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == c ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _CourseCard extends StatelessWidget {
  final Course course;
  final Color color;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<String> onStatusChange;

  const _CourseCard({
    required this.course,
    required this.color,
    required this.onEdit,
    required this.onDelete,
    required this.onStatusChange,
  });

  Color get _statusColor {
    switch (course.status) {
      case 'published':
        return AppColors.teal;
      case 'archived':
        return AppColors.textSecondary;
      default:
        return AppColors.marigoldDeep;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(
              fit: StackFit.expand,
              children: [
                course.thumbnailBytes != null
                    ? Image.memory(course.thumbnailBytes!, fit: BoxFit.cover)
                    : course.thumbnailUrl != null
                        ? Image.network(course.thumbnailUrl!, fit: BoxFit.cover)
                        : Container(
                            color: color.withOpacity(0.12),
                            child: Icon(Icons.image_outlined,
                                color: color, size: 32),
                          ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: PopupMenuButton<String>(
                    initialValue: course.status,
                    onSelected: onStatusChange,
                    itemBuilder: (context) => const [
                      PopupMenuItem(value: 'draft', child: Text('Draft')),
                      PopupMenuItem(
                          value: 'published', child: Text('Published')),
                      PopupMenuItem(
                          value: 'archived', child: Text('Archived')),
                    ],
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _statusColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        course.status,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      course.category,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    course.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontSize: 15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    course.description,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _attachmentBadge(
                        icon: Icons.picture_as_pdf_outlined,
                        present: course.pdfName != null,
                      ),
                      const SizedBox(width: 8),
                      _attachmentBadge(
                        icon: Icons.videocam_outlined,
                        present: course.videoName != null,
                      ),
                      const Spacer(),
                      IconButton(
                        tooltip: 'Edit course',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.edit_outlined,
                            size: 18, color: AppColors.textSecondary),
                        onPressed: onEdit,
                      ),
                      IconButton(
                        tooltip: 'Delete course',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.delete_outline_rounded,
                            size: 18, color: AppColors.coral),
                        onPressed: onDelete,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _attachmentBadge({required IconData icon, required bool present}) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: present
            ? AppColors.teal.withOpacity(0.12)
            : AppColors.border.withOpacity(0.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(
        icon,
        size: 14,
        color: present ? AppColors.teal : AppColors.textSecondary,
      ),
    );
  }
}
