import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/payment_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';
import '../widgets/plan_form_dialog.dart';

enum _PaymentTab { plans, transactions, reports }

/// Module 6 content. Plans stream live from Firestore
/// (`subscriptionPlans`); transactions/revenue are one-shot reads over
/// `users/*/orders` (see AdminPaymentRepository) refreshed via retry
/// rather than a live stream, since they scan orders across every
/// user. A pill sub-nav switches between the module's three sections.
class PaymentsContent extends ConsumerStatefulWidget {
  const PaymentsContent({super.key});

  @override
  ConsumerState<PaymentsContent> createState() => _PaymentsContentState();
}

class _PaymentsContentState extends ConsumerState<PaymentsContent> {
  _PaymentTab _tab = _PaymentTab.plans;
  String _statusFilter = 'All';

  Future<void> _openPlanForm({SubscriptionPlan? existing}) async {
    final result = await showDialog<SubscriptionPlan>(
      context: context,
      builder: (_) => PlanFormDialog(existing: existing),
    );
    if (result == null) return;
    try {
      final repo = ref.read(adminPaymentRepositoryProvider);
      if (existing == null) {
        await repo.createPlan(result);
      } else {
        await repo.updatePlan(result);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save plan: $e')),
      );
    }
  }

  void _confirmDeletePlan(SubscriptionPlan plan) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete plan?'),
        content: Text(
            '"${plan.name}" will no longer be purchasable. Existing subscribers keep access until renewal.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            onPressed: () async {
              Navigator.of(context).pop();
              try {
                await ref
                    .read(adminPaymentRepositoryProvider)
                    .deletePlan(plan.id);
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Could not delete: $e')),
                );
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleActive(SubscriptionPlan plan) async {
    try {
      final updated = SubscriptionPlan(
        id: plan.id,
        name: plan.name,
        priceInr: plan.priceInr,
        billingCycle: plan.billingCycle,
        category: plan.category,
        features: plan.features,
        isActive: !plan.isActive,
        subscriberCount: plan.subscriberCount,
      );
      await ref.read(adminPaymentRepositoryProvider).updatePlan(updated);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update plan: $e')),
      );
    }
  }

  void _refund(PaymentTransaction txn) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Refund transaction?'),
        content: Text(
            'Refunds ${txn.id} (₹${txn.amountInr.toStringAsFixed(0)} from ${txn.userName}) via Razorpay and revokes what it granted.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.coral),
            onPressed: () async {
              Navigator.of(context).pop();
              try {
                await ref
                    .read(adminPaymentRepositoryProvider)
                    .refundTransaction(txn);
                ref.invalidate(adminTransactionsProvider);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Refund issued')),
                );
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Refund failed: $e')),
                );
              }
            },
            child: const Text('Refund'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              _TabPills(active: _tab, onSelect: (t) => setState(() => _tab = t)),
              const SizedBox(height: 20),
              switch (_tab) {
                _PaymentTab.plans => _PlansBank(
                    onAdd: () => _openPlanForm(),
                    onEdit: (p) => _openPlanForm(existing: p),
                    onDelete: _confirmDeletePlan,
                    onToggleActive: _toggleActive,
                  ),
                _PaymentTab.transactions => _TransactionsBank(
                    activeFilter: _statusFilter,
                    onFilter: (v) => setState(() => _statusFilter = v),
                    onRefund: _refund,
                  ),
                _PaymentTab.reports => const _ReportsBank(),
              },
            ],
          ),
        );
      },
    );
  }
}

class _PlansBank extends ConsumerWidget {
  final VoidCallback onAdd;
  final ValueChanged<SubscriptionPlan> onEdit;
  final ValueChanged<SubscriptionPlan> onDelete;
  final ValueChanged<SubscriptionPlan> onToggleActive;

  const _PlansBank({
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
    required this.onToggleActive,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final plansAsync = ref.watch(adminPlansStreamProvider);
    return plansAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load plans: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminPlansStreamProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (plans) => _PlansView(
        plans: plans,
        onAdd: onAdd,
        onEdit: onEdit,
        onDelete: onDelete,
        onToggleActive: onToggleActive,
      ),
    );
  }
}

class _TransactionsBank extends ConsumerWidget {
  final String activeFilter;
  final ValueChanged<String> onFilter;
  final ValueChanged<PaymentTransaction> onRefund;

  const _TransactionsBank({
    required this.activeFilter,
    required this.onFilter,
    required this.onRefund,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txnsAsync = ref.watch(adminTransactionsProvider);
    return txnsAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load transactions: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminTransactionsProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (transactions) => _TransactionsView(
        transactions: transactions,
        activeFilter: activeFilter,
        onFilter: onFilter,
        onRefund: onRefund,
      ),
    );
  }
}

class _ReportsBank extends ConsumerWidget {
  const _ReportsBank();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final monthlyAsync = ref.watch(adminMonthlyRevenueProvider);
    final byItemAsync = ref.watch(adminRevenueByItemProvider);
    final txnsAsync = ref.watch(adminTransactionsProvider);

    if (monthlyAsync.isLoading || byItemAsync.isLoading || txnsAsync.isLoading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    final error = monthlyAsync.error ?? byItemAsync.error ?? txnsAsync.error;
    if (error != null) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load revenue reports: $error'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () {
                  ref.invalidate(adminMonthlyRevenueProvider);
                  ref.invalidate(adminRevenueByItemProvider);
                  ref.invalidate(adminTransactionsProvider);
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    return _ReportsView(
      monthly: monthlyAsync.value ?? const [],
      planRevenue: byItemAsync.value ?? const [],
      transactions: txnsAsync.value ?? const [],
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 6 · Payments',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('भुगतान',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TabPills extends StatelessWidget {
  final _PaymentTab active;
  final ValueChanged<_PaymentTab> onSelect;
  const _TabPills({required this.active, required this.onSelect});

  static const _tabs = [
    (_PaymentTab.plans, 'Subscription Plans', Icons.card_membership_rounded),
    (_PaymentTab.transactions, 'Transactions', Icons.receipt_long_rounded),
    (_PaymentTab.reports, 'Revenue Reports', Icons.insights_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final (tab, label, icon) in _tabs)
          ChoiceChip(
            label: Text(label),
            avatar: Icon(icon,
                size: 16,
                color: active == tab ? Colors.white : AppColors.textSecondary),
            selected: active == tab,
            onSelected: (_) => onSelect(tab),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == tab ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _PlansView extends StatelessWidget {
  final List<SubscriptionPlan> plans;
  final VoidCallback onAdd;
  final ValueChanged<SubscriptionPlan> onEdit;
  final ValueChanged<SubscriptionPlan> onDelete;
  final ValueChanged<SubscriptionPlan> onToggleActive;

  const _PlansView({
    required this.plans,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
    required this.onToggleActive,
  });

  static const _accents = [
    AppColors.marigold,
    AppColors.teal,
    AppColors.violet,
    AppColors.coral,
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      int columns = 1;
      if (constraints.maxWidth >= 1100) {
        columns = 3;
      } else if (constraints.maxWidth >= 700) {
        columns = 2;
      }
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text('${plans.length} plans',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontSize: 15)),
              ),
              FilledButton.icon(
                onPressed: onAdd,
                style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Add Plan'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: columns,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: columns == 1 ? 1.05 : 0.78,
            children: [
              for (int i = 0; i < plans.length; i++)
                _PlanCard(
                  plan: plans[i],
                  accent: _accents[i % _accents.length],
                  onEdit: () => onEdit(plans[i]),
                  onDelete: () => onDelete(plans[i]),
                  onToggleActive: () => onToggleActive(plans[i]),
                ),
            ],
          ),
        ],
      );
    });
  }
}

class _PlanCard extends StatelessWidget {
  final SubscriptionPlan plan;
  final Color accent;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onToggleActive;

  const _PlanCard({
    required this.plan,
    required this.accent,
    required this.onEdit,
    required this.onDelete,
    required this.onToggleActive,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(plan.category,
                      style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w600,
                          color: accent)),
                ),
                const Spacer(),
                Switch(
                  value: plan.isActive,
                  activeColor: AppColors.teal,
                  onChanged: (_) => onToggleActive(),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(plan.name,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontSize: 18)),
            const SizedBox(height: 4),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text('₹${plan.priceInr.toStringAsFixed(0)}',
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: accent)),
                const SizedBox(width: 4),
                Text('/ ${plan.billingCycle.toLowerCase()}',
                    style: const TextStyle(
                        fontSize: 12.5, color: AppColors.textSecondary)),
              ],
            ),
            const SizedBox(height: 4),
            Text('${plan.subscriberCount} subscribers',
                style: const TextStyle(
                    fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 10),
            const Divider(height: 1),
            const SizedBox(height: 10),
            Expanded(
              child: plan.features.isEmpty
                  ? const Text('No features listed',
                      style: TextStyle(
                          fontSize: 12, color: AppColors.textSecondary))
                  : ListView(
                      shrinkWrap: true,
                      children: [
                        for (final f in plan.features)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.check_circle_rounded,
                                    size: 14, color: accent),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(f,
                                      style: const TextStyle(fontSize: 12.5)),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  tooltip: 'Edit plan',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.edit_outlined,
                      size: 18, color: AppColors.textSecondary),
                  onPressed: onEdit,
                ),
                IconButton(
                  tooltip: 'Delete plan',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.delete_outline_rounded,
                      size: 18, color: AppColors.coral),
                  onPressed: onDelete,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusChips extends StatelessWidget {
  final String active;
  final ValueChanged<String> onSelect;
  const _StatusChips({required this.active, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final all = ['All', ...transactionStatuses];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final s in all)
          ChoiceChip(
            label: Text(s),
            selected: active == s,
            onSelected: (_) => onSelect(s),
            selectedColor: AppColors.teal,
            labelStyle: TextStyle(
              color: active == s ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _TransactionsView extends StatelessWidget {
  final List<PaymentTransaction> transactions;
  final String activeFilter;
  final ValueChanged<String> onFilter;
  final ValueChanged<PaymentTransaction> onRefund;

  const _TransactionsView({
    required this.transactions,
    required this.activeFilter,
    required this.onFilter,
    required this.onRefund,
  });

  @override
  Widget build(BuildContext context) {
    final visible = activeFilter == 'All'
        ? transactions
        : transactions.where((t) => t.status == activeFilter).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('${transactions.length} transactions',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontSize: 15)),
        const SizedBox(height: 14),
        _StatusChips(active: activeFilter, onSelect: onFilter),
        const SizedBox(height: 16),
        if (visible.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No "$activeFilter" transactions',
                  style: Theme.of(context).textTheme.bodyMedium),
            ),
          )
        else
          for (final t in visible)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _TransactionCard(
                  txn: t, onRefund: () => onRefund(t)),
            ),
      ],
    );
  }
}

class _TransactionCard extends StatelessWidget {
  final PaymentTransaction txn;
  final VoidCallback onRefund;
  const _TransactionCard({required this.txn, required this.onRefund});

  Color get _statusColor => switch (txn.status) {
        'Success' => AppColors.teal,
        'Failed' => AppColors.coral,
        'Refunded' => AppColors.violet,
        _ => AppColors.marigoldDeep,
      };

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final narrow = constraints.maxWidth < 600;
      final info = Row(
        children: [
          CircleAvatar(
            backgroundColor: AppColors.violet.withOpacity(0.15),
            child: Text(
              txn.userName.trim().split(' ').map((s) => s[0]).take(2).join(),
              style: const TextStyle(
                  color: AppColors.violet, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(txn.userName,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13.5)),
                Text(
                  '${txn.planName} · ${txn.method} · ${txn.id}',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
        ],
      );

      final trailing = Wrap(
        spacing: 10,
        runSpacing: 6,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Text('₹${txn.amountInr.toStringAsFixed(0)}',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _statusColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(txn.status,
                style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: _statusColor)),
          ),
          Text(DateFormat.yMMMd().format(txn.paidOn),
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textSecondary)),
          if (txn.status == 'Success')
            OutlinedButton(
              onPressed: onRefund,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                foregroundColor: AppColors.coral,
                visualDensity: VisualDensity.compact,
              ),
              child: const Text('Refund', style: TextStyle(fontSize: 12)),
            ),
        ],
      );

      return Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: narrow
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [info, const SizedBox(height: 10), trailing],
                )
              : Row(
                  children: [
                    Expanded(child: info),
                    const SizedBox(width: 12),
                    trailing,
                  ],
                ),
        ),
      );
    });
  }
}

class _ReportsView extends StatelessWidget {
  final List<MonthlyRevenue> monthly;
  final List<PlanRevenueSlice> planRevenue;
  final List<PaymentTransaction> transactions;

  const _ReportsView({
    required this.monthly,
    required this.planRevenue,
    required this.transactions,
  });

  static const _sliceColors = [
    AppColors.marigold,
    AppColors.teal,
    AppColors.violet,
    AppColors.coral,
    AppColors.marigoldDeep,
  ];

  @override
  Widget build(BuildContext context) {
    final totalRevenue = monthly.fold<double>(0, (s, m) => s + m.amountInr);
    final totalTxns = transactions.length;
    final refunds = transactions.where((t) => t.status == 'Refunded').length;
    final refundRate = totalTxns == 0 ? 0.0 : refunds / totalTxns * 100;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _summaryChip(
                '₹${(totalRevenue / 100000).toStringAsFixed(1)}L total revenue',
                AppColors.ink),
            _summaryChip('$totalTxns transactions', AppColors.teal),
            _summaryChip(
                '${refundRate.toStringAsFixed(1)}% refund rate', AppColors.coral),
          ],
        ),
        const SizedBox(height: 20),
        LayoutBuilder(builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 900;
          final bar = _MonthlyRevenueChart(monthly: monthly);
          final donut =
              _PlanRevenueDonut(slices: planRevenue, colors: _sliceColors);
          if (isWide) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 3, child: bar),
                const SizedBox(width: 16),
                Expanded(flex: 2, child: donut),
              ],
            );
          }
          return Column(
            children: [bar, const SizedBox(height: 16), donut],
          );
        }),
      ],
    );
  }

  Widget _summaryChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              color: color, fontWeight: FontWeight.w600, fontSize: 12.5)),
    );
  }
}

class _MonthlyRevenueChart extends StatelessWidget {
  final List<MonthlyRevenue> monthly;
  const _MonthlyRevenueChart({required this.monthly});

  @override
  Widget build(BuildContext context) {
    final maxY = monthly.map((m) => m.amountInr).reduce((a, b) => a > b ? a : b);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Monthly Revenue (₹)',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 20),
            SizedBox(
              height: 220,
              child: BarChart(
                BarChartData(
                  maxY: maxY * 1.2,
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    horizontalInterval: maxY / 4,
                    getDrawingHorizontalLine: (_) =>
                        FlLine(color: AppColors.border, strokeWidth: 1),
                  ),
                  borderData: FlBorderData(show: false),
                  barTouchData: BarTouchData(
                    touchTooltipData: BarTouchTooltipData(
                      getTooltipColor: (_) => AppColors.ink,
                      getTooltipItem: (group, groupIndex, rod, rodIndex) {
                        final m = monthly[groupIndex];
                        return BarTooltipItem(
                          '${m.month}\n₹${m.amountInr.toStringAsFixed(0)}\n${m.transactionCount} txns',
                          const TextStyle(color: Colors.white, fontSize: 12),
                        );
                      },
                    ),
                  ),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          final i = value.toInt();
                          if (i < 0 || i >= monthly.length) {
                            return const SizedBox.shrink();
                          }
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(monthly[i].month,
                                style: const TextStyle(
                                    fontSize: 11,
                                    color: AppColors.textSecondary)),
                          );
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 52,
                        interval: maxY / 4,
                        getTitlesWidget: (value, meta) => Text(
                          '${(value / 100000).toStringAsFixed(1)}L',
                          style: const TextStyle(
                              fontSize: 11, color: AppColors.textSecondary),
                        ),
                      ),
                    ),
                  ),
                  barGroups: [
                    for (int i = 0; i < monthly.length; i++)
                      BarChartGroupData(
                        x: i,
                        barRods: [
                          BarChartRodData(
                            toY: monthly[i].amountInr,
                            width: 22,
                            borderRadius: BorderRadius.circular(6),
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [
                                AppColors.teal.withOpacity(0.55),
                                AppColors.teal,
                              ],
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanRevenueDonut extends StatelessWidget {
  final List<PlanRevenueSlice> slices;
  final List<Color> colors;
  const _PlanRevenueDonut({required this.slices, required this.colors});

  @override
  Widget build(BuildContext context) {
    final total = slices.fold<double>(0, (s, x) => s + x.amountInr);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Revenue by Plan',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            SizedBox(
              height: 170,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  PieChart(
                    PieChartData(
                      sectionsSpace: 3,
                      centerSpaceRadius: 48,
                      sections: [
                        for (int i = 0; i < slices.length; i++)
                          PieChartSectionData(
                            value: slices[i].amountInr,
                            color: colors[i % colors.length],
                            radius: 24,
                            showTitle: false,
                          ),
                      ],
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('₹${(total / 100000).toStringAsFixed(1)}L',
                          style: Theme.of(context).textTheme.titleMedium),
                      const Text('total',
                          style: TextStyle(
                              fontSize: 11, color: AppColors.textSecondary)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (int i = 0; i < slices.length; i++)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: colors[i % colors.length],
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(slices[i].planName,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyMedium),
                    ),
                    Text('₹${(slices[i].amountInr / 100000).toStringAsFixed(1)}L',
                        style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary,
                            fontSize: 12.5)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
