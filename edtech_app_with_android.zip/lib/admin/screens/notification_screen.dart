import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../models/course_model.dart' show courseCategories;
import '../models/notification_model.dart';
import '../admin_theme.dart';
import '../providers/admin_data_providers.dart';
import '../providers/admin_repository_providers.dart';

enum _NotifTab { compose, history }

/// Module 9 content. Composing sends through the sendNotification
/// Cloud Function (never a direct Firestore write - see that
/// function's doc comment); History streams the resulting
/// `notifications/{id}` records straight from Firestore.
class NotificationContent extends ConsumerStatefulWidget {
  const NotificationContent({super.key});

  @override
  ConsumerState<NotificationContent> createState() =>
      _NotificationContentState();
}

class _NotificationContentState extends ConsumerState<NotificationContent> {
  _NotifTab _tab = _NotifTab.compose;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 900;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(isWide: isWide),
              const SizedBox(height: 20),
              _TabPills(active: _tab, onSelect: (t) => setState(() => _tab = t)),
              const SizedBox(height: 20),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: switch (_tab) {
                  _NotifTab.compose => _ComposeView(
                      onSent: () => setState(() => _tab = _NotifTab.history),
                    ),
                  _NotifTab.history => const _HistoryView(),
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final bool isWide;
  const _Header({required this.isWide});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (!isWide)
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.ink),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Module 9 · Notifications',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              const Text('सूचनाएं',
                  style:
                      TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ],
    );
  }
}

class _TabPills extends StatelessWidget {
  final _NotifTab active;
  final ValueChanged<_NotifTab> onSelect;
  const _TabPills({required this.active, required this.onSelect});

  static const _tabs = [
    (_NotifTab.compose, 'Compose', Icons.edit_notifications_rounded),
    (_NotifTab.history, 'History', Icons.history_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      children: [
        for (final (tab, label, icon) in _tabs)
          ChoiceChip(
            label: Text(label),
            avatar: Icon(icon,
                size: 16,
                color: active == tab ? Colors.white : AppColors.textSecondary),
            selected: active == tab,
            onSelected: (_) => onSelect(tab),
            selectedColor: AppColors.ink,
            labelStyle: TextStyle(
              color: active == tab ? Colors.white : AppColors.textPrimary,
              fontWeight: FontWeight.w500,
              fontSize: 12.5,
            ),
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.border),
          ),
      ],
    );
  }
}

class _ComposeView extends ConsumerStatefulWidget {
  final VoidCallback onSent;
  const _ComposeView({required this.onSent});

  @override
  ConsumerState<_ComposeView> createState() => _ComposeViewState();
}

class _ComposeViewState extends ConsumerState<_ComposeView> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  String _category = 'general';
  NotificationTargetType _targetType = NotificationTargetType.all;
  String? _roleValue;
  String? _examTrackValue;
  final _userIdCtrl = TextEditingController();
  String _deepLinkScreen = '';
  final _courseIdCtrl = TextEditingController();
  bool _sending = false;

  static const _roles = ['student', 'teacher', 'parent'];

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    _userIdCtrl.dispose();
    _courseIdCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_titleCtrl.text.trim().isEmpty || _bodyCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title and message are both required')),
      );
      return;
    }

    String? targetValue;
    switch (_targetType) {
      case NotificationTargetType.role:
        targetValue = _roleValue;
      case NotificationTargetType.examTrack:
        targetValue = _examTrackValue;
      case NotificationTargetType.user:
        targetValue = _userIdCtrl.text.trim();
      case NotificationTargetType.all:
        targetValue = null;
    }
    if (_targetType != NotificationTargetType.all &&
        (targetValue == null || targetValue.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pick a target for this notification')),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Send this notification?'),
        content: Text(
          'Sending to: ${_targetType.label}'
          '${targetValue != null ? ' ($targetValue)' : ''}\n'
          'This goes out immediately and can\'t be recalled.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Send'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _sending = true);
    try {
      final result = await ref.read(adminNotificationRepositoryProvider).send(
            title: _titleCtrl.text.trim(),
            body: _bodyCtrl.text.trim(),
            category: _category,
            targetType: _targetType,
            targetValue: targetValue,
            deepLinkScreen: _deepLinkScreen.isEmpty ? null : _deepLinkScreen,
            deepLinkCourseId:
                _courseIdCtrl.text.trim().isEmpty ? null : _courseIdCtrl.text.trim(),
          );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Sent to ${result.devicesSent} of ${result.devicesSent + result.devicesFailed} devices '
              '(${result.recipientCount} eligible recipients)'),
        ),
      );
      _titleCtrl.clear();
      _bodyCtrl.clear();
      _userIdCtrl.clear();
      _courseIdCtrl.clear();
      widget.onSent();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not send: $e')),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _titleCtrl,
              maxLength: 65,
              decoration: const InputDecoration(
                labelText: 'Title',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 4),
            TextField(
              controller: _bodyCtrl,
              maxLength: 240,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Message',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(
                labelText: 'Category',
                helperText:
                    'Users can opt out of every category except General',
                border: OutlineInputBorder(),
              ),
              items: [
                for (final c in notificationCategories)
                  DropdownMenuItem(value: c, child: Text(categoryLabel(c))),
              ],
              onChanged: (v) => setState(() => _category = v!),
            ),
            const SizedBox(height: 16),
            Text('Send to', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in NotificationTargetType.values)
                  ChoiceChip(
                    label: Text(t.label),
                    selected: _targetType == t,
                    onSelected: (_) => setState(() => _targetType = t),
                    selectedColor: AppColors.teal,
                    labelStyle: TextStyle(
                      color: _targetType == t ? Colors.white : AppColors.textPrimary,
                      fontSize: 12.5,
                    ),
                    backgroundColor: AppColors.surface,
                    side: const BorderSide(color: AppColors.border),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            if (_targetType == NotificationTargetType.role)
              DropdownButtonFormField<String>(
                value: _roleValue,
                decoration: const InputDecoration(
                  labelText: 'Role',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final r in _roles)
                    DropdownMenuItem(value: r, child: Text(r)),
                ],
                onChanged: (v) => setState(() => _roleValue = v),
              ),
            if (_targetType == NotificationTargetType.examTrack)
              DropdownButtonFormField<String>(
                value: _examTrackValue,
                decoration: const InputDecoration(
                  labelText: 'Exam track',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final c in courseCategories)
                    DropdownMenuItem(value: c, child: Text(c)),
                ],
                onChanged: (v) => setState(() => _examTrackValue = v),
              ),
            if (_targetType == NotificationTargetType.user)
              TextField(
                controller: _userIdCtrl,
                decoration: const InputDecoration(
                  labelText: 'User ID',
                  helperText: 'From the User Management screen',
                  border: OutlineInputBorder(),
                ),
              ),
            const SizedBox(height: 16),
            Text('Deep link (optional)',
                style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _deepLinkScreen,
              decoration: const InputDecoration(
                labelText: 'Opens',
                border: OutlineInputBorder(),
              ),
              items: [
                for (final entry in deepLinkScreens.entries)
                  DropdownMenuItem(value: entry.key, child: Text(entry.value)),
              ],
              onChanged: (v) => setState(() => _deepLinkScreen = v!),
            ),
            if (_deepLinkScreen == 'course-detail') ...[
              const SizedBox(height: 10),
              TextField(
                controller: _courseIdCtrl,
                decoration: const InputDecoration(
                  labelText: 'Course ID',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            const SizedBox(height: 20),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: _sending ? null : _send,
                style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
                icon: _sending
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send_rounded, size: 18),
                label: Text(_sending ? 'Sending…' : 'Send Notification'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryView extends ConsumerWidget {
  const _HistoryView();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final historyAsync = ref.watch(adminNotificationHistoryProvider);
    return historyAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, st) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Column(
            children: [
              Text('Could not load history: $err'),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => ref.invalidate(adminNotificationHistoryProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
      data: (records) {
        if (records.isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text('No notifications sent yet',
                  style: Theme.of(context).textTheme.bodyMedium),
            ),
          );
        }
        return Column(
          children: [
            for (final record in records)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _HistoryCard(record: record),
              ),
          ],
        );
      },
    );
  }
}

class _HistoryCard extends StatelessWidget {
  final NotificationRecord record;
  const _HistoryCard({required this.record});

  Color get _statusColor => switch (record.status) {
        'sent' => AppColors.teal,
        'failed' => AppColors.coral,
        _ => AppColors.marigoldDeep,
      };

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(record.title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 14.5)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _statusColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(record.status,
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _statusColor)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(record.body,
                style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                _tag(categoryLabel(record.category), AppColors.violet),
                _tag(
                  record.targetType == 'all'
                      ? 'Everyone'
                      : '${record.targetType}: ${record.targetValue}',
                  AppColors.ink,
                ),
                if (record.status == 'sent')
                  _tag(
                    '${record.successCount}/${record.successCount + record.failureCount} delivered',
                    AppColors.teal,
                  ),
                if (record.error != null) _tag(record.error!, AppColors.coral),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              DateFormat.yMMMd().add_jm().format(record.sentAt),
              style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tag(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.canvas,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: 11, color: color, fontWeight: FontWeight.w600)),
    );
  }
}
