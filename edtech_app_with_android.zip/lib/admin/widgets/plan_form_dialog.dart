import 'package:flutter/material.dart';
import '../models/course_model.dart';
import '../models/payment_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`; returns the built/updated [SubscriptionPlan]
/// through `Navigator.pop(context, plan)`, or null if cancelled. Pass
/// [existing] to edit a plan in place, or leave it null to add a new one.
class PlanFormDialog extends StatefulWidget {
  final SubscriptionPlan? existing;
  const PlanFormDialog({super.key, this.existing});

  @override
  State<PlanFormDialog> createState() => _PlanFormDialogState();
}

class _PlanFormDialogState extends State<PlanFormDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _priceCtrl;
  late final TextEditingController _featureCtrl;
  late String _cycle;
  late String _category;
  late bool _isActive;
  late List<String> _features;
  String? _nameError;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _priceCtrl =
        TextEditingController(text: e != null ? e.priceInr.toStringAsFixed(0) : '');
    _featureCtrl = TextEditingController();
    _cycle = e?.billingCycle ?? billingCycles.first;
    _category = e?.category ?? 'All Exams';
    _isActive = e?.isActive ?? true;
    _features = List.of(e?.features ?? []);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    _featureCtrl.dispose();
    super.dispose();
  }

  void _addFeature() {
    final text = _featureCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _features.add(text);
      _featureCtrl.clear();
    });
  }

  void _save() {
    final price = double.tryParse(_priceCtrl.text.trim());
    setState(() {
      _nameError = _nameCtrl.text.trim().isEmpty
          ? 'Plan name is required'
          : (price == null || price <= 0)
              ? 'Enter a valid price'
              : null;
    });
    if (_nameError != null) return;

    final e = widget.existing;
    final plan = SubscriptionPlan(
      id: e?.id ?? 'PLN${DateTime.now().millisecondsSinceEpoch}',
      name: _nameCtrl.text.trim(),
      priceInr: price!,
      billingCycle: _cycle,
      category: _category,
      features: _features,
      isActive: _isActive,
      subscriberCount: e?.subscriberCount ?? 0,
    );
    Navigator.of(context).pop(plan);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    final categories = ['All Exams', ...courseCategories];
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(isEdit ? 'Edit Plan' : 'Add Subscription Plan'),
      content: SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _nameCtrl,
                decoration: InputDecoration(
                  labelText: 'Plan name',
                  errorText: _nameError,
                  border: const OutlineInputBorder(),
                ),
                onChanged: (_) {
                  if (_nameError != null) setState(() => _nameError = null);
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _priceCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Price (₹)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _cycle,
                      decoration: const InputDecoration(
                        labelText: 'Billing cycle',
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        for (final c in billingCycles)
                          DropdownMenuItem(value: c, child: Text(c)),
                      ],
                      onChanged: (v) => setState(() => _cycle = v!),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(
                  labelText: 'Targets',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final c in categories)
                    DropdownMenuItem(value: c, child: Text(c)),
                ],
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 14),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Active',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                subtitle: const Text('Visible to learners for purchase',
                    style: TextStyle(fontSize: 12)),
                value: _isActive,
                activeColor: AppColors.teal,
                onChanged: (v) => setState(() => _isActive = v),
              ),
              const SizedBox(height: 8),
              Text('Features',
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontSize: 12.5)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _featureCtrl,
                      decoration: const InputDecoration(
                        hintText: 'e.g. Live doubt sessions',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      onSubmitted: (_) => _addFeature(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: _addFeature,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.border),
                    ),
                    child: const Text('Add'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (_features.isEmpty)
                const Text('No features added yet',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary))
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final f in _features)
                      Chip(
                        label: Text(f, style: const TextStyle(fontSize: 12)),
                        backgroundColor: AppColors.canvas,
                        side: const BorderSide(color: AppColors.border),
                        onDeleted: () => setState(() => _features.remove(f)),
                      ),
                  ],
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: _save,
          child: Text(isEdit ? 'Save changes' : 'Add plan'),
        ),
      ],
    );
  }
}
