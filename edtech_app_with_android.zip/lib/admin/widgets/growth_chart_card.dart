import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/dashboard_data.dart';
import '../providers/admin_data_providers.dart';
import '../admin_theme.dart';

class GrowthChartCard extends ConsumerWidget {
  const GrowthChartCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usageAsync = ref.watch(adminDailyUsageProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('New vs. Active Users — Last 14 Days',
                    style: Theme.of(context).textTheme.titleMedium),
                Row(
                  children: [
                    _legendDot(AppColors.marigold, 'New users'),
                    const SizedBox(width: 14),
                    _legendDot(AppColors.ink, 'Active users'),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 220,
              child: usageAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, st) => Center(
                  child: Text('Could not load usage data',
                      style: const TextStyle(color: AppColors.textSecondary)),
                ),
                data: (usage) {
                  final points = usage
                      .skip(usage.length > 14 ? usage.length - 14 : 0)
                      .map((d) => GrowthPoint(
                            '${d.date.day}/${d.date.month}',
                            d.newUsers.toDouble(),
                            d.activeUsers.toDouble(),
                          ))
                      .toList();
                  if (points.isEmpty) {
                    return const Center(child: Text('No data yet'));
                  }
                  final maxY = [
                    ...points.map((p) => p.users),
                    ...points.map((p) => p.active),
                    1.0,
                  ].reduce((a, b) => a > b ? a : b);
                  return _chart(points, maxY);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chart(List<GrowthPoint> points, double maxY) {
    return LineChart(
      LineChartData(
        minY: 0,
        maxY: maxY * 1.15,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: maxY / 4 == 0 ? 1 : maxY / 4,
          getDrawingHorizontalLine: (_) => FlLine(
            color: AppColors.border,
            strokeWidth: 1,
          ),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 2,
              getTitlesWidget: (value, meta) {
                final i = value.toInt();
                if (i < 0 || i >= points.length) {
                  return const SizedBox.shrink();
                }
                return Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    points[i].label,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 44,
              interval: maxY / 4 == 0 ? 1 : maxY / 4,
              getTitlesWidget: (value, meta) => Text(
                value.toStringAsFixed(0),
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
        ),
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            getTooltipColor: (_) => AppColors.ink,
          ),
        ),
        lineBarsData: [
          _line(points.map((p) => p.users).toList(), AppColors.marigold),
          _line(points.map((p) => p.active).toList(), AppColors.ink),
        ],
      ),
    );
  }

  LineChartBarData _line(List<double> values, Color color) {
    return LineChartBarData(
      spots: [
        for (int i = 0; i < values.length; i++) FlSpot(i.toDouble(), values[i])
      ],
      isCurved: true,
      curveSmoothness: 0.25,
      color: color,
      barWidth: 3,
      dotData: const FlDotData(show: false),
      belowBarData: BarAreaData(
        show: true,
        color: color.withOpacity(0.08),
      ),
    );
  }

  Widget _legendDot(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(label,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }
}
