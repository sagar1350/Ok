import 'package:flutter/material.dart';
import '../models/quiz_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`; returns the built/updated [QuizQuestion] through
/// `Navigator.pop(context, question)`, or null if cancelled. Pass
/// [existing] to edit a question in place, or leave it null to add a new
/// one. [quizzes] populates the "belongs to" quiz picker.
class QuizQuestionFormDialog extends StatefulWidget {
  final List<Quiz> quizzes;
  final QuizQuestion? existing;
  final String? initialQuizId;

  const QuizQuestionFormDialog({
    super.key,
    required this.quizzes,
    this.existing,
    this.initialQuizId,
  });

  @override
  State<QuizQuestionFormDialog> createState() =>
      _QuizQuestionFormDialogState();
}

class _QuizQuestionFormDialogState extends State<QuizQuestionFormDialog> {
  late final TextEditingController _textCtrl;
  late final List<TextEditingController> _optionCtrls;
  late String _quizId;
  late String _difficulty;
  late int _marks;
  int _correctIndex = 0;
  String? _textError;
  String? _optionsError;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _textCtrl = TextEditingController(text: e?.text ?? '');
    _optionCtrls = List.generate(
      4,
      (i) => TextEditingController(
          text: e != null && i < e.options.length ? e.options[i] : ''),
    );
    _quizId = e?.quizId ??
        widget.initialQuizId ??
        (widget.quizzes.isNotEmpty ? widget.quizzes.first.id : '');
    _difficulty = e?.difficulty ?? quizDifficulties.first;
    _marks = e?.marks ?? 2;
    _correctIndex = e?.correctIndex ?? 0;
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    for (final c in _optionCtrls) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    setState(() {
      _textError = _textCtrl.text.trim().isEmpty ? 'Question text is required' : null;
      _optionsError = _optionCtrls.any((c) => c.text.trim().isEmpty)
          ? 'All four options are required'
          : null;
    });
    if (_textError != null || _optionsError != null) return;

    final e = widget.existing;
    final question = QuizQuestion(
      id: e?.id ?? 'Q${DateTime.now().millisecondsSinceEpoch}',
      quizId: _quizId,
      text: _textCtrl.text.trim(),
      options: [for (final c in _optionCtrls) c.text.trim()],
      correctIndex: _correctIndex,
      difficulty: _difficulty,
      marks: _marks,
    );
    Navigator.of(context).pop(question);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(isEdit ? 'Edit Question' : 'Add Question'),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<String>(
                value: widget.quizzes.any((q) => q.id == _quizId)
                    ? _quizId
                    : null,
                decoration: const InputDecoration(
                  labelText: 'Belongs to quiz',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final q in widget.quizzes)
                    DropdownMenuItem(value: q.id, child: Text(q.title)),
                ],
                onChanged: (v) => setState(() => _quizId = v!),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _textCtrl,
                maxLines: 2,
                decoration: InputDecoration(
                  labelText: 'Question (प्रश्न)',
                  errorText: _textError,
                  border: const OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                onChanged: (_) {
                  if (_textError != null) setState(() => _textError = null);
                },
              ),
              const SizedBox(height: 14),
              Text('Options — tap the radio for the correct one',
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontSize: 12.5)),
              if (_optionsError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(_optionsError!,
                      style:
                          const TextStyle(color: AppColors.coral, fontSize: 12)),
                ),
              const SizedBox(height: 6),
              for (int i = 0; i < 4; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Radio<int>(
                        value: i,
                        groupValue: _correctIndex,
                        activeColor: AppColors.teal,
                        onChanged: (v) => setState(() => _correctIndex = v!),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _optionCtrls[i],
                          decoration: InputDecoration(
                            labelText: 'Option ${i + 1}',
                            isDense: true,
                            border: const OutlineInputBorder(),
                          ),
                          onChanged: (_) {
                            if (_optionsError != null) {
                              setState(() => _optionsError = null);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _difficulty,
                      decoration: const InputDecoration(
                        labelText: 'Difficulty',
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        for (final d in quizDifficulties)
                          DropdownMenuItem(value: d, child: Text(d)),
                      ],
                      onChanged: (v) => setState(() => _difficulty = v!),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<int>(
                      value: _marks,
                      decoration: const InputDecoration(
                        labelText: 'Marks',
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        for (final m in [1, 2, 3, 5])
                          DropdownMenuItem(value: m, child: Text('$m')),
                      ],
                      onChanged: (v) => setState(() => _marks = v!),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: _save,
          child: Text(isEdit ? 'Save changes' : 'Add question'),
        ),
      ],
    );
  }
}
