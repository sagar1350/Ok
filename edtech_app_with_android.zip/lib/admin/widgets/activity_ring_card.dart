import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/dashboard_data.dart';
import '../providers/admin_data_providers.dart';
import '../admin_theme.dart';

/// Signature element of the dashboard: today's activity rendered as a
/// scoring ring — the same visual language as the circular progress mark
/// on a graded answer sheet — rather than a generic pie chart.
class ActivityRingCard extends ConsumerWidget {
  const ActivityRingCard({super.key});

  static const _colors = [AppColors.marigold, AppColors.teal];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final overviewAsync = ref.watch(adminAnalyticsOverviewProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Today's Activity", style: Theme.of(context).textTheme.titleMedium),
            const Text('आज की गतिविधि',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            SizedBox(
              height: 260,
              child: overviewAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, st) => const Center(
                  child: Text('Could not load activity data',
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
                data: (overview) {
                  final slices = [
                    ActivitySlice(
                        'Quiz attempts', overview.quizAttemptsToday.toDouble(), 0),
                    ActivitySlice(
                        'New signups', overview.newSignupsToday.toDouble(), 1),
                  ];
                  return _body(context, slices);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body(BuildContext context, List<ActivitySlice> slices) {
    final total = slices.fold<double>(0, (sum, s) => sum + s.value);
    final hasData = total > 0;
    return Column(
      children: [
        SizedBox(
          height: 190,
          child: Stack(
            alignment: Alignment.center,
            children: [
              PieChart(
                PieChartData(
                  sectionsSpace: 3,
                  centerSpaceRadius: 55,
                  sections: [
                    for (int i = 0; i < slices.length; i++)
                      PieChartSectionData(
                        value: hasData ? slices[i].value : 1,
                        color: hasData
                            ? _colors[slices[i].colorSeed % _colors.length]
                            : AppColors.border,
                        radius: 26,
                        showTitle: false,
                      ),
                  ],
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    total.toStringAsFixed(0),
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const Text(
                    'events today',
                    style: TextStyle(
                        fontSize: 11, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        for (int i = 0; i < slices.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _colors[slices[i].colorSeed % _colors.length],
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(slices[i].label,
                      style: Theme.of(context).textTheme.bodyMedium),
                ),
                Text(
                  slices[i].value.toStringAsFixed(0),
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
