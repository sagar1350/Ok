import 'package:flutter/material.dart';
import '../admin_theme.dart';

/// A single top-line metric tile, styled like an exam scorecard: a thin
/// color-coded band along the top identifies the metric family, a large
/// figure carries the number, and a small delta chip shows movement
/// since the previous period.
class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String hindiLabel;
  final IconData icon;
  final Color accent;
  final double? deltaPct;

  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.hindiLabel,
    required this.icon,
    required this.accent,
    this.deltaPct,
  });

  @override
  Widget build(BuildContext context) {
    final delta = deltaPct;
    final isUp = (delta ?? 0) >= 0;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // signature accent band
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Container(
                margin: const EdgeInsets.only(left: -18, right: -18),
                height: 4,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accent, accent.withOpacity(0.25)],
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: accent, size: 20),
                ),
                if (delta != null)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: (isUp ? AppColors.teal : AppColors.coral)
                          .withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isUp ? Icons.arrow_upward : Icons.arrow_downward,
                          size: 12,
                          color: isUp ? AppColors.teal : AppColors.coral,
                        ),
                        const SizedBox(width: 2),
                        Text(
                          '${delta.abs().toStringAsFixed(1)}%',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isUp ? AppColors.teal : AppColors.coral,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 2),
            Text(label, style: Theme.of(context).textTheme.bodyMedium),
            Text(
              hindiLabel,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
