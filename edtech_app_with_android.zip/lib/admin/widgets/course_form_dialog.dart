import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/course_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`; returns the built/updated [Course] through
/// `Navigator.pop(context, course)`, or null if cancelled. Pass
/// [existing] to edit a course in place, or leave it null to add a new one.
class CourseFormDialog extends StatefulWidget {
  final Course? existing;
  const CourseFormDialog({super.key, this.existing});

  @override
  State<CourseFormDialog> createState() => _CourseFormDialogState();
}

class _CourseFormDialogState extends State<CourseFormDialog> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _descCtrl;
  late String _category;
  late String _status;
  Uint8List? _thumbBytes;
  String? _thumbName;
  String? _thumbUrl;
  Uint8List? _pdfBytes;
  String? _pdfName;
  String? _pdfUrl;
  Uint8List? _videoBytes;
  String? _videoName;
  String? _videoUrl;
  String? _titleError;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _titleCtrl = TextEditingController(text: e?.title ?? '');
    _descCtrl = TextEditingController(text: e?.description ?? '');
    _category = e?.category ?? courseCategories.first;
    _status = e?.status ?? 'draft';
    _thumbBytes = e?.thumbnailBytes;
    _thumbName = e?.thumbnailName;
    _thumbUrl = e?.thumbnailUrl;
    _pdfBytes = e?.pdfBytes;
    _pdfName = e?.pdfName;
    _pdfUrl = e?.pdfUrl;
    _videoBytes = e?.videoBytes;
    _videoName = e?.videoName;
    _videoUrl = e?.videoUrl;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickThumbnail() async {
    try {
      final result = await FilePicker.platform
          .pickFiles(type: FileType.image, withData: true);
      final f = result?.files.single;
      if (f == null) return;
      setState(() {
        _thumbBytes = f.bytes;
        _thumbName = f.name;
      });
    } catch (_) {
      _showPickerError();
    }
  }

  Future<void> _pickPdf() async {
    try {
      final result = await FilePicker.platform.pickFiles(
          type: FileType.custom, allowedExtensions: ['pdf'], withData: true);
      final f = result?.files.single;
      if (f == null) return;
      setState(() {
        _pdfName = f.name;
        _pdfBytes = f.bytes;
      });
    } catch (_) {
      _showPickerError();
    }
  }

  Future<void> _pickVideo() async {
    try {
      final result =
          await FilePicker.platform.pickFiles(type: FileType.video, withData: true);
      final f = result?.files.single;
      if (f == null) return;
      setState(() {
        _videoName = f.name;
        _videoBytes = f.bytes;
      });
    } catch (_) {
      _showPickerError();
    }
  }

  void _showPickerError() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Couldn't open the file picker")),
    );
  }

  void _save() {
    if (_titleCtrl.text.trim().isEmpty) {
      setState(() => _titleError = 'Course title is required');
      return;
    }
    final e = widget.existing;
    final course = Course(
      id: e?.id ?? '',
      title: _titleCtrl.text.trim(),
      category: _category,
      description: _descCtrl.text.trim(),
      status: _status,
      thumbnailBytes: _thumbBytes,
      thumbnailName: _thumbName,
      thumbnailUrl: _thumbUrl,
      pdfBytes: _pdfBytes,
      pdfName: _pdfName,
      pdfUrl: _pdfUrl,
      videoBytes: _videoBytes,
      videoName: _videoName,
      videoUrl: _videoUrl,
      createdOn: e?.createdOn ?? DateTime.now(),
    );
    Navigator.of(context).pop(course);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(isEdit ? 'Edit Course' : 'Add Course'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleCtrl,
                decoration: InputDecoration(
                  labelText: 'Course title',
                  errorText: _titleError,
                  border: const OutlineInputBorder(),
                ),
                onChanged: (_) {
                  if (_titleError != null) setState(() => _titleError = null);
                },
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final c in courseCategories)
                    DropdownMenuItem(value: c, child: Text(c)),
                ],
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _status,
                decoration: const InputDecoration(
                  labelText: 'Status',
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(value: 'draft', child: Text('Draft')),
                  DropdownMenuItem(
                      value: 'published', child: Text('Published')),
                  DropdownMenuItem(
                      value: 'archived', child: Text('Archived')),
                ],
                onChanged: (v) => setState(() => _status = v!),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _descCtrl,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 18),
              _UploadRow(
                label: 'Thumbnail',
                fileName: _thumbName,
                icon: Icons.image_outlined,
                preview: _thumbBytes != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.memory(_thumbBytes!,
                            width: 40, height: 40, fit: BoxFit.cover),
                      )
                    : null,
                onUpload: _pickThumbnail,
              ),
              const SizedBox(height: 10),
              _UploadRow(
                label: 'PDF notes',
                fileName: _pdfName,
                icon: Icons.picture_as_pdf_outlined,
                onUpload: _pickPdf,
              ),
              const SizedBox(height: 10),
              _UploadRow(
                label: 'Video lecture',
                fileName: _videoName,
                icon: Icons.videocam_outlined,
                onUpload: _pickVideo,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: _save,
          child: Text(isEdit ? 'Save changes' : 'Add course'),
        ),
      ],
    );
  }
}

class _UploadRow extends StatelessWidget {
  final String label;
  final String? fileName;
  final IconData icon;
  final Widget? preview;
  final VoidCallback onUpload;

  const _UploadRow({
    required this.label,
    required this.fileName,
    required this.icon,
    required this.onUpload,
    this.preview,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        preview ??
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.canvas,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: Icon(icon, size: 18, color: AppColors.textSecondary),
            ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 12.5, color: AppColors.textSecondary)),
              Text(
                fileName ?? 'No file selected',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: fileName != null
                      ? AppColors.textPrimary
                      : AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
        OutlinedButton(
          onPressed: onUpload,
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: AppColors.border),
          ),
          child: Text(fileName == null ? 'Upload' : 'Replace'),
        ),
      ],
    );
  }
}
