import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/dashboard_data.dart';
import '../providers/admin_data_providers.dart';
import '../admin_theme.dart';

class RevenueChartCard extends ConsumerWidget {
  const RevenueChartCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final revenueAsync = ref.watch(adminRevenueTrendProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Revenue by Month (₹)',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 20),
            SizedBox(
              height: 220,
              child: revenueAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (err, st) => const Center(
                  child: Text('Could not load revenue data',
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
                data: (points) {
                  final bars = points
                      .map((p) => RevenueBar(p.month, p.amountInr))
                      .toList();
                  final maxAmount = bars.isEmpty
                      ? 1.0
                      : bars.map((b) => b.amountInr).reduce((a, b) => a > b ? a : b);
                  final maxY = maxAmount <= 0 ? 1.0 : maxAmount;
                  return _chart(bars, maxY);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chart(List<RevenueBar> bars, double maxY) {
    return BarChart(
      BarChartData(
        maxY: maxY * 1.2,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: maxY / 4,
          getDrawingHorizontalLine: (_) =>
              FlLine(color: AppColors.border, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => AppColors.ink,
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              final bar = bars[groupIndex];
              return BarTooltipItem(
                '${bar.month}\n₹${bar.amountInr.toStringAsFixed(0)}',
                const TextStyle(color: Colors.white, fontSize: 12),
              );
            },
          ),
        ),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final i = value.toInt();
                if (i < 0 || i >= bars.length) {
                  return const SizedBox.shrink();
                }
                return Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    bars[i].month,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 52,
              interval: maxY / 4,
              getTitlesWidget: (value, meta) => Text(
                '${(value / 100000).toStringAsFixed(1)}L',
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
        ),
        barGroups: [
          for (int i = 0; i < bars.length; i++)
            BarChartGroupData(
              x: i,
              barRods: [
                BarChartRodData(
                  toY: bars[i].amountInr,
                  width: 22,
                  borderRadius: BorderRadius.circular(6),
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      AppColors.violet.withOpacity(0.55),
                      AppColors.violet,
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
