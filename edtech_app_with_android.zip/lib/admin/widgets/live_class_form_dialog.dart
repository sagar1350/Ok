import 'package:flutter/material.dart';
import '../models/course_model.dart';
import '../models/live_class_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`; returns the built/updated [LiveClass] through
/// `Navigator.pop(context, liveClass)`, or null if cancelled. Pass
/// [existing] to reschedule/edit a class in place, or leave it null to
/// schedule a new one.
class LiveClassFormDialog extends StatefulWidget {
  final LiveClass? existing;
  const LiveClassFormDialog({super.key, this.existing});

  @override
  State<LiveClassFormDialog> createState() => _LiveClassFormDialogState();
}

class _LiveClassFormDialogState extends State<LiveClassFormDialog> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _instructorCtrl;
  late final TextEditingController _linkCtrl;
  late String _category;
  late DateTime _date;
  late TimeOfDay _time;
  late int _duration;
  late LiveClassPlatform _platform;
  String? _titleError;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _titleCtrl = TextEditingController(text: e?.title ?? '');
    _instructorCtrl = TextEditingController(text: e?.instructor ?? '');
    _category = e?.category ?? courseCategories.first;
    _date = e?.scheduledAt ?? DateTime.now().add(const Duration(days: 1));
    _time = TimeOfDay.fromDateTime(
        e?.scheduledAt ?? DateTime.now().add(const Duration(hours: 2)));
    _duration = e?.durationMinutes ?? 60;
    _platform = e?.platform ?? LiveClassPlatform.zoom;
    _linkCtrl = TextEditingController(
        text: e?.meetingLink ??
            generateMeetingLinkPlaceholder(
                _platform, _titleCtrl.text.isEmpty ? 'new' : _titleCtrl.text));
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _instructorCtrl.dispose();
    _linkCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked != null) setState(() => _time = picked);
  }

  void _regenerateLink() {
    setState(() {
      _linkCtrl.text = generateMeetingLinkPlaceholder(
        _platform,
        '${_titleCtrl.text}${DateTime.now().millisecondsSinceEpoch}',
      );
    });
  }

  void _save() {
    if (_titleCtrl.text.trim().isEmpty) {
      setState(() => _titleError = 'Class title is required');
      return;
    }
    final e = widget.existing;
    final scheduledAt = DateTime(
        _date.year, _date.month, _date.day, _time.hour, _time.minute);
    final liveClass = LiveClass(
      id: e?.id ?? '',
      title: _titleCtrl.text.trim(),
      category: _category,
      scheduledAt: scheduledAt,
      durationMinutes: _duration,
      instructor: _instructorCtrl.text.trim().isEmpty
          ? 'TBD'
          : _instructorCtrl.text.trim(),
      platform: _platform,
      meetingLink: _linkCtrl.text.trim(),
      attendees: e?.attendees ?? [],
    );
    Navigator.of(context).pop(liveClass);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(isEdit ? 'Edit Live Class' : 'Schedule Class'),
      content: SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleCtrl,
                decoration: InputDecoration(
                  labelText: 'Class title',
                  errorText: _titleError,
                  border: const OutlineInputBorder(),
                ),
                onChanged: (_) {
                  if (_titleError != null) setState(() => _titleError = null);
                },
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final c in courseCategories)
                    DropdownMenuItem(value: c, child: Text(c)),
                ],
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _instructorCtrl,
                decoration: const InputDecoration(
                  labelText: 'Instructor',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.border),
                        foregroundColor: AppColors.textPrimary,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: const Icon(Icons.calendar_today_rounded, size: 16),
                      label: Text(
                          '${_date.day}/${_date.month}/${_date.year}'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.border),
                        foregroundColor: AppColors.textPrimary,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: const Icon(Icons.access_time_rounded, size: 16),
                      label: Text(_time.format(context)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<int>(
                value: _duration,
                decoration: const InputDecoration(
                  labelText: 'Duration',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final m in [30, 45, 60, 90, 120])
                    DropdownMenuItem(value: m, child: Text('$m minutes')),
                ],
                onChanged: (v) => setState(() => _duration = v!),
              ),
              const SizedBox(height: 18),
              Text('Platform',
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontSize: 12.5)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final p in LiveClassPlatform.values)
                    ChoiceChip(
                      label: Text(p.label),
                      selected: _platform == p,
                      onSelected: (_) {
                        setState(() {
                          _platform = p;
                          _regenerateLink();
                        });
                      },
                      selectedColor: p == LiveClassPlatform.zoom
                          ? AppColors.violet
                          : AppColors.teal,
                      labelStyle: TextStyle(
                        color: _platform == p
                            ? Colors.white
                            : AppColors.textPrimary,
                        fontWeight: FontWeight.w500,
                        fontSize: 12.5,
                      ),
                      backgroundColor: AppColors.surface,
                      side: const BorderSide(color: AppColors.border),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _linkCtrl,
                decoration: InputDecoration(
                  labelText: 'Meeting link',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    tooltip: 'Generate a new link',
                    icon: const Icon(Icons.refresh_rounded, size: 20),
                    onPressed: _regenerateLink,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: _save,
          child: Text(isEdit ? 'Save changes' : 'Schedule class'),
        ),
      ],
    );
  }
}
