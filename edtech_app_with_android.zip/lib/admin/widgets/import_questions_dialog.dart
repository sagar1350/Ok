import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/quiz_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`. Lets the admin pick an .xlsx or .json file and
/// preview the rows that would be imported into a quiz's question bank,
/// then confirms with `Navigator.pop(context, questions)`.
///
/// There's no backend yet to actually parse the workbook/JSON, so once a
/// file is picked this builds a realistic preview from
/// [buildMockImportPreview] keyed off the file name — swap that for a
/// real xlsx/json parser once the import endpoint exists.
class ImportQuestionsDialog extends StatefulWidget {
  final List<Quiz> quizzes;
  const ImportQuestionsDialog({super.key, required this.quizzes});

  @override
  State<ImportQuestionsDialog> createState() => _ImportQuestionsDialogState();
}

class _ImportQuestionsDialogState extends State<ImportQuestionsDialog> {
  late String _quizId;
  String? _fileName;
  List<QuizQuestion>? _preview;
  String? _error;

  @override
  void initState() {
    super.initState();
    _quizId = widget.quizzes.isNotEmpty ? widget.quizzes.first.id : '';
  }

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls', 'json'],
      );
      final f = result?.files.single;
      if (f == null) return;
      setState(() {
        _fileName = f.name;
        _error = null;
        _preview = buildMockImportPreview(_quizId, f.name);
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = "Couldn't open the file picker");
    }
  }

  void _import() {
    if (_preview == null || _preview!.isEmpty) {
      setState(() => _error = 'Pick a file with at least one question first');
      return;
    }
    Navigator.of(context).pop(_preview);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Import Questions'),
      content: SizedBox(
        width: 480,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Upload an Excel (.xlsx) or JSON file with question, four '
              'options, the correct option, and marks per row.',
              style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: widget.quizzes.any((q) => q.id == _quizId)
                  ? _quizId
                  : null,
              decoration: const InputDecoration(
                labelText: 'Import into quiz',
                border: OutlineInputBorder(),
              ),
              items: [
                for (final q in widget.quizzes)
                  DropdownMenuItem(value: q.id, child: Text(q.title)),
              ],
              onChanged: (v) => setState(() {
                _quizId = v!;
                if (_fileName != null) {
                  _preview = buildMockImportPreview(_quizId, _fileName!);
                }
              }),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.canvas,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: AppColors.border, style: BorderStyle.solid),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.violet.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.upload_file_rounded,
                        color: AppColors.violet, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _fileName ?? 'No file selected',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: _fileName != null
                            ? AppColors.textPrimary
                            : AppColors.textSecondary,
                      ),
                    ),
                  ),
                  OutlinedButton(
                    onPressed: _pickFile,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.border),
                    ),
                    child: Text(_fileName == null ? 'Choose file' : 'Replace'),
                  ),
                ],
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(_error!,
                    style:
                        const TextStyle(color: AppColors.coral, fontSize: 12)),
              ),
            if (_preview != null) ...[
              const SizedBox(height: 16),
              Text('${_preview!.length} questions found — preview',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 13.5)),
              const SizedBox(height: 8),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 220),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: _preview!.length,
                  separatorBuilder: (_, __) => const Divider(height: 14),
                  itemBuilder: (context, i) {
                    final q = _preview![i];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${i + 1}. ${q.text}',
                            style:
                                const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                        const SizedBox(height: 3),
                        Text(
                          'Correct: ${q.options[q.correctIndex]} · '
                          '${q.difficulty} · ${q.marks} marks',
                          style: const TextStyle(
                              fontSize: 12, color: AppColors.textSecondary),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: _import,
          child: const Text('Import questions'),
        ),
      ],
    );
  }
}

/// Builds a stand-in preview for the picked file. Deterministic per quiz
/// so re-picking the same file looks the same; replace with real
/// xlsx/json parsing once there's a backend to send the file to.
List<QuizQuestion> buildMockImportPreview(String quizId, String fileName) {
  final pool = <(String, List<String>, int)>[
    (
      'गंगा नदी का उद्गम स्थल कौन सा है?',
      ['गोमुख', 'यमुनोत्री', 'रुद्रप्रयाग', 'हरिद्वार'],
      0,
    ),
    (
      'न्यूटन की गति का प्रथम नियम किससे संबंधित है?',
      ['जड़त्व', 'त्वरण', 'संवेग संरक्षण', 'गुरुत्वाकर्षण'],
      0,
    ),
    (
      'वाइगोत्स्की के सिद्धांत में ZPD का पूरा नाम क्या है?',
      [
        'Zone of Proximal Development',
        'Zonal Progress Distance',
        'Zero Point Deviation',
        'Zonal Personality Development',
      ],
      0,
    ),
    (
      'यदि किसी संख्या का 20% 40 है, तो संख्या क्या है?',
      ['160', '200', '180', '220'],
      1,
    ),
    (
      'भारत के प्रथम राष्ट्रपति कौन थे?',
      ['डॉ. राजेंद्र प्रसाद', 'जवाहरलाल नेहरू', 'सरदार पटेल', 'डॉ. अंबेडकर'],
      0,
    ),
  ];
  final seed = fileName.length + quizId.length;
  final count = 3 + (seed % 3); // 3–5 rows
  return List.generate(count, (i) {
    final (text, options, correct) = pool[i % pool.length];
    return QuizQuestion(
      id: 'QIMP${DateTime.now().millisecondsSinceEpoch}$i',
      quizId: quizId,
      text: text,
      options: options,
      correctIndex: correct,
      difficulty: quizDifficulties[i % quizDifficulties.length],
      marks: 2,
    );
  });
}
