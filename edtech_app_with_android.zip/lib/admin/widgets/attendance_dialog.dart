import 'package:flutter/material.dart';
import '../models/live_class_model.dart';
import '../admin_theme.dart';

/// Shown via `showDialog`. Lets the admin mark each enrolled learner
/// present/absent for one live class, then confirms with
/// `Navigator.pop(context, attendees)`. Pass the class's current
/// [attendees] list in — this dialog mutates copies, not the originals,
/// so a cancel leaves the source list untouched.
class AttendanceDialog extends StatefulWidget {
  final String classTitle;
  final List<Attendee> attendees;
  const AttendanceDialog(
      {super.key, required this.classTitle, required this.attendees});

  @override
  State<AttendanceDialog> createState() => _AttendanceDialogState();
}

class _AttendanceDialogState extends State<AttendanceDialog> {
  late List<Attendee> _roster;

  @override
  void initState() {
    super.initState();
    _roster = widget.attendees
        .map((a) => Attendee(userId: a.userId, name: a.name, present: a.present))
        .toList();
  }

  void _markAll(bool present) {
    setState(() {
      for (final a in _roster) {
        a.present = present;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final present = _roster.where((a) => a.present).length;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text('Attendance — ${widget.classTitle}'),
      content: SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.teal.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('$present / ${_roster.length} present',
                      style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.teal)),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => _markAll(true),
                  child: const Text('Mark all present'),
                ),
                TextButton(
                  onPressed: () => _markAll(false),
                  child: const Text('Mark all absent'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 340),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: _roster.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) {
                  final a = _roster[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: AppColors.violet.withOpacity(0.15),
                          child: Text(
                            a.name.trim().split(' ').map((s) => s[0]).take(2).join(),
                            style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.violet,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(a.name,
                              style: const TextStyle(
                                  fontSize: 13.5, fontWeight: FontWeight.w500)),
                        ),
                        Text(
                          a.present ? 'Present' : 'Absent',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: a.present
                                ? AppColors.teal
                                : AppColors.textSecondary,
                          ),
                        ),
                        Switch(
                          value: a.present,
                          activeColor: AppColors.teal,
                          onChanged: (v) => setState(() => a.present = v),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.ink),
          onPressed: () => Navigator.of(context).pop(_roster),
          child: const Text('Save attendance'),
        ),
      ],
    );
  }
}
