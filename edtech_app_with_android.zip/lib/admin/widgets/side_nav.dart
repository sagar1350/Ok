import 'package:flutter/material.dart';
import '../admin_theme.dart';

/// The app's left-hand navigation. Shared by every module screen so the
/// same nine-item map (Dashboard, Users, Courses, Quizzes, Live Classes,
/// Payments, Analytics, Settings, Notifications) always renders
/// identically, with only the selected item changing.
class SideNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  const SideNav({
    super.key,
    required this.selectedIndex,
    required this.onSelect,
  });

  static const items = [
    ('Dashboard', Icons.dashboard_rounded),
    ('User Management', Icons.people_alt_rounded),
    ('Course Management', Icons.menu_book_rounded),
    ('Quizzes', Icons.quiz_rounded),
    ('Live Classes', Icons.video_camera_front_rounded),
    ('Payments', Icons.payments_rounded),
    ('Analytics', Icons.bar_chart_rounded),
    ('Settings', Icons.settings_rounded),
    ('Notifications', Icons.notifications_active_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      color: AppColors.ink,
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: AppColors.marigold,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(Icons.school_rounded,
                    color: AppColors.ink, size: 20),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Exam Prep Admin',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 36),
          for (int i = 0; i < items.length; i++)
            _NavTile(
              label: items[i].$1,
              icon: items[i].$2,
              selected: i == selectedIndex,
              onTap: () => onSelect(i),
            ),
        ],
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _NavTile({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? Colors.white.withOpacity(0.08) : null,
          borderRadius: BorderRadius.circular(10),
          border: selected
              ? const Border(
                  left: BorderSide(color: AppColors.marigold, width: 3))
              : null,
        ),
        child: Row(
          children: [
            Icon(icon,
                size: 18,
                color: selected ? AppColors.marigold : Colors.white70),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: selected ? Colors.white : Colors.white70,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
