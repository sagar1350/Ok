import 'package:flutter/material.dart';
import 'admin_theme.dart';
import 'screens/app_shell.dart';

/// Entry point for the Exam Admin Dashboard module.
///
/// The dashboard (`screens/`, `widgets/`, `models/` under this folder) was
/// built as its own standalone Flutter Web app with its own [AppTheme]. It
/// still runs on the mock data described in its module READMEs -
/// [AppShell]'s screens read from `lib/admin/models/*` - swap those for
/// real repositories/providers the same way the rest of the app's
/// `repositories/` + `providers/` layers work when there's a backend for
/// user/course/quiz/payment/settings management to call.
///
/// Wrapped in its own [Theme] (rather than merged into the main
/// `MaterialApp.theme`) so the "ink & marigold" admin palette doesn't leak
/// into student-facing screens, and vice versa.
class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: AppTheme.light,
      child: const AppShell(),
    );
  }
}
