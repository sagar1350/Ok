import 'package:flutter/material.dart';
import '../sync/sync_progress.dart';
import '../sync/sync_stream.dart';

/// Thin progress bar driven by [SyncStream], fed by
/// `SyncController.updateProgress` from inside
/// `QueueProcessor.processQueue()` (see PHASE9_NOTES.md). Renders
/// nothing before the first update *and* once a batch finishes
/// (`completed >= total`) - the pasted version only hid on `null`,
/// which would leave the bar stuck full between syncs since nothing
/// resets it to an "idle" value. Same "no layout cost when there's
/// nothing to say" pattern as OfflineBanner/PendingSyncIndicator.
/// Not yet placed on any screen - drop it wherever it should show
/// (e.g. next to PendingSyncIndicator).
class SyncProgressBar extends StatelessWidget {
  const SyncProgressBar({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<SyncProgress>(
      stream: SyncStream.instance.stream,
      builder: (_, snapshot) {

        final progress = snapshot.data;

        if (progress == null ||
            progress.total == 0 ||
            progress.completed >= progress.total) {
          return const SizedBox();
        }

        return LinearProgressIndicator(

          value: progress.percent,

        );

      },
    );
  }
}
