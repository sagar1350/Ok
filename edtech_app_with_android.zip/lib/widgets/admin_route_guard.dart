import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/admin_access_provider.dart';

/// Wraps [AdminDashboardScreen] in the route table. Re-checks the
/// `admin` custom claim independently of whatever brought the user to
/// this route - SplashScreen already checks it before navigating, but
/// this is the actual gate: a deep link, a stale/replayed route, or a
/// revoked-mid-session admin should never render admin UI.
class AdminRouteGuard extends ConsumerWidget {
  final Widget child;

  const AdminRouteGuard({super.key, required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adminCheck = ref.watch(isAdminProvider);

    return adminCheck.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (_, __) => const _AccessDenied(),
      data: (isAdmin) => isAdmin ? child : const _AccessDenied(),
    );
  }
}

class _AccessDenied extends StatelessWidget {
  const _AccessDenied();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline, size: 56, color: Colors.grey),
              const SizedBox(height: 16),
              const Text(
                'Admin access required',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              const Text(
                'This account isn\'t granted admin access. Contact an '
                'existing admin if you believe this is a mistake.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () =>
                    Navigator.pushReplacementNamed(context, '/dashboard'),
                child: const Text('Back to app'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
