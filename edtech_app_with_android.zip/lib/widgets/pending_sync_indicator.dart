import 'package:flutter/material.dart';
import '../services/queue_stream.dart';

/// Small text indicator of how many items are waiting to sync, fed by
/// [QueueStream] (updated automatically by QueueManager whenever the
/// sync_queue box changes - see queue_manager.dart's
/// refreshQueueCount()). Renders nothing once the count is 0, same
/// "no layout cost when there's nothing to say" pattern as
/// OfflineBanner.
class PendingSyncIndicator extends StatelessWidget {
  const PendingSyncIndicator({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: QueueStream.instance.stream,
      builder: (context, snapshot) {
        final pending = snapshot.data ?? 0;
        if (pending == 0) return const SizedBox.shrink();

        return Text(
          "Pending Sync : $pending",
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade700,
            fontWeight: FontWeight.w500,
          ),
        );
      },
    );
  }
}
