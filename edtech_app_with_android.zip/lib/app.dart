import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/otp_screen.dart';
import 'screens/role_selection_screen.dart';
import 'screens/student_dashboard.dart';
import 'screens/course_list_screen.dart';
import 'screens/course_detail_screen.dart';
import 'screens/video_player_screen.dart';
import 'screens/quiz_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/subscription_plans_screen.dart';
import 'screens/saved_lessons_screen.dart';
import 'screens/config_error_screen.dart';
import 'screens/route_error_screen.dart';
import 'admin/admin_dashboard_screen.dart';
import 'widgets/admin_route_guard.dart';
import 'models/course.dart';
import 'providers/theme_provider.dart';
import 'providers/locale_provider.dart';
import 'providers/auth_provider.dart';
import 'translations/app_localizations.dart';
import 'widgets/offline_banner.dart';
import 'services/notification_service.dart';
import 'screens/notification_preferences_screen.dart';
import 'security/screenshot_protection.dart';

class MyApp extends ConsumerWidget {
  final bool firebaseReady;
  final String? firebaseInitError;

  const MyApp({
    super.key,
    this.firebaseReady = true,
    this.firebaseInitError,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Providers se values read karo
    final themeMode = ref.watch(themeModeProvider);
    final locale = ref.watch(localeProvider);

    return MaterialApp(
      title: 'EdTech Pro',
      debugShowCheckedModeBanner: false,
      // Lets NotificationService navigate on a notification tap even
      // when it fires before any screen's BuildContext exists yet
      // (app opened cold from a terminated-state push).
      navigatorKey: NotificationService.navigatorKey,
      
      // Theme - Light aur Dark dono support
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        primaryColor: const Color(0xFF6C63FF),
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          centerTitle: false,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF6C63FF),
            foregroundColor: Colors.white,
            minimumSize: const Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        cardTheme: CardTheme(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.grey[100],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(
              color: Color(0xFF6C63FF),
              width: 2,
            ),
          ),
        ),
      ),
      
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF6C63FF),
        scaffoldBackgroundColor: const Color(0xFF121212),
        cardTheme: CardTheme(
          elevation: 0,
          color: const Color(0xFF1E1E1E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF2C2C2C),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      
      themeMode: themeMode,
      
      // Language support
      locale: locale,
      supportedLocales: const [
        Locale('en', ''),
        Locale('hi', ''),
      ],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      
      // App ki starting screen
      // Agar Firebase configure nahi hai, to seedha login/dashboard pe jaane
      // ki jagah ek clear "configuration missing" screen dikhao - crash
      // hone se behtar hai.
      initialRoute: firebaseReady ? '/' : '/config-error',
      onGenerateRoute: _generateRoute,

      // Shows a thin "you're offline" banner above whatever screen is
      // current, so cached/offline data doesn't look like a bug. One
      // place to add this instead of every screen remembering to.
      builder: (context, child) {
        return SafeArea(
          bottom: false,
          child: Column(
            children: [
              const OfflineBanner(),
              Expanded(child: child ?? const SizedBox.shrink()),
            ],
          ),
        );
      },
    );
  }

  // Routing - har screen ka rasta
  // Har route ko try/catch mein wrap kiya hai taaki galat/missing arguments
  // (jaise settings.arguments null hona) app ko crash na kare, balki ek
  // safe error screen dikhaye.
  Route<dynamic>? _generateRoute(RouteSettings settings) {
    try {
      switch (settings.name) {
        case '/':
          return _buildRoute(const SplashScreen());
        case '/config-error':
          return _buildRoute(ConfigErrorScreen(message: firebaseInitError));
        case '/login':
          return _buildRoute(const LoginScreen());
        case '/otp':
          final phone = settings.arguments as String?;
          if (phone == null || phone.isEmpty) {
            return _buildRoute(const RouteErrorScreen(
              message: 'Phone number missing. Please go back and try again.',
            ));
          }
          return _buildRoute(OTPScreen(phoneNumber: phone));
        case '/role-select':
          return _buildRoute(const RoleSelectionScreen());
        case '/dashboard':
          return _buildRoute(const StudentDashboard());
        case '/admin':
          // AdminRouteGuard re-checks the `admin` custom claim right
          // here, independent of how this route was reached (splash
          // redirect, deep link, back-stack replay, etc.) - see the
          // guard's doc comment.
          return _buildRoute(
            const AdminRouteGuard(child: AdminDashboardScreen()),
          );
        case '/courses':
          return _buildRoute(const CourseListScreen());
        case '/course-detail':
          final courseId = settings.arguments as String?;
          if (courseId == null || courseId.isEmpty) {
            return _buildRoute(const RouteErrorScreen(
              message: 'Course not found.',
            ));
          }
          return _buildRoute(CourseDetailScreen(courseId: courseId));
        case '/video':
          final data = settings.arguments as Map<String, dynamic>?;
          final url = data?['url'] as String?;
          final title = data?['title'] as String?;
          final course = data?['course'] as Course?;
          if (url == null || url.isEmpty) {
            return _buildRoute(const RouteErrorScreen(
              message: 'Video link missing.',
            ));
          }
          return _buildRoute(SecureScreen(
            child: VideoPlayerScreen(
              videoUrl: url,
              lessonTitle: title ?? 'Lesson',
              course: course,
            ),
          ));
        case '/quiz':
          return _buildRoute(const SecureScreen(child: QuizScreen()));
        case '/settings':
          return _buildRoute(const SettingsScreen());
        case '/notification-preferences':
          return _buildRoute(const NotificationPreferencesScreen());
        case '/subscription-plans':
          return _buildRoute(const SubscriptionPlansScreen());
        case '/saved-lessons':
          return _buildRoute(const SavedLessonsScreen());
        default:
          return _buildRoute(const RouteErrorScreen(
            message: 'Page not found.',
          ));
      }
    } catch (e) {
      return _buildRoute(RouteErrorScreen(message: e.toString()));
    }
  }

  // Smooth animation ke saath screen change
  PageRouteBuilder _buildRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(opacity: animation, child: child);
      },
      transitionDuration: const Duration(milliseconds: 300),
    );
  }
}
