import '../models/app_user.dart';
import '../models/user_role.dart';

/// Reads/writes the app-level user profile document (role, name) that
/// lives alongside Firebase Auth's own user record.
abstract class UserRepository {
  Future<AppUser?> getProfile(String uid);

  Stream<AppUser?> watchProfile(String uid);

  Future<void> createProfileIfMissing(String uid, {String? phoneNumber});

  Future<void> setRole(String uid, UserRole role);

  /// Stamps `lastActiveAt` on the caller's own profile - the one
  /// signal the admin dashboard's Analytics module (Module 8) uses to
  /// compute real active-user counts, since there's no separate
  /// analytics-events pipeline. Called once per app session from
  /// AuthNotifier, not on every screen - see its call site for why.
  Future<void> stampLastActive(String uid);

  /// Emits `notificationPrefs` from the profile doc, with every key
  /// in [optionalNotificationCategories] defaulted to true if unset -
  /// matches how sendNotification (Cloud Function) treats a missing
  /// key. See NotificationPreferencesScreen.
  Stream<Map<String, bool>> watchNotificationPrefs(String uid);

  Future<void> updateNotificationPrefs(String uid, Map<String, bool> prefs);
}
