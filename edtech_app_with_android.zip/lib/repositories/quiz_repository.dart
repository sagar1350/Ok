import '../models/quiz.dart';

abstract class QuizRepository {
  /// Loads a quiz by id. The dashboard's "Daily Quiz" action uses id
  /// `daily`.
  Future<Quiz?> getQuiz(String quizId);

  Future<void> submitResult({
    required String uid,
    required String quizId,
    required int score,
    required int total,
  });
}
