/// Abstraction over whatever auth backend we use (Firebase phone/OTP
/// today). AuthNotifier depends on this interface, not on
/// `FirebaseAuth.instance` directly, so auth flows can be unit-tested
/// with a fake implementation instead of a real network call.
abstract class AuthRepository {
  /// Fires whenever the signed-in user changes (including at startup
  /// with the currently-persisted session, if any). Emits the uid of
  /// the signed-in user, or null when signed out.
  Stream<String?> authStateChanges();

  String? get currentUid;

  /// Starts phone verification. [onCodeSent] is called once Firebase
  /// has sent the SMS with a verificationId to pass to [verifyOtp].
  /// [onVerificationFailed] is called with a human-readable message.
  /// [onAutoVerified] fires if the OTP is auto-detected/verified by the
  /// platform without the user typing it in.
  Future<void> sendOtp(
    String phoneNumber, {
    required void Function(String verificationId) onCodeSent,
    required void Function(String message) onVerificationFailed,
    required void Function() onAutoVerified,
  });

  /// Verifies the 6-digit code against a verificationId from [sendOtp].
  /// Returns true on success.
  Future<bool> verifyOtp({
    required String verificationId,
    required String smsCode,
  });

  /// True only if the signed-in user's ID token carries the `admin`
  /// custom claim, set server-side by the `setAdminRole` Cloud
  /// Function (see functions/index.js) - never by the client.
  /// This is the actual authorization check; the `role` field on the
  /// user's Firestore profile doc is just a UI label and must never
  /// be trusted for gating admin screens or data.
  ///
  /// [forceRefresh] bypasses the cached ID token. Pass true right
  /// after a grant/revoke might have happened (e.g. before routing to
  /// `/admin`), since a cached token can be up to an hour stale.
  Future<bool> isAdmin({bool forceRefresh = false});

  Future<void> signOut();
}
