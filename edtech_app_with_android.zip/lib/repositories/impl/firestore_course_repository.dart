import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/course.dart';
import '../../models/course_progress.dart';
import '../../utils/perf_trace.dart';
import '../course_repository.dart';

class FirestoreCourseRepository implements CourseRepository {
  final FirebaseFirestore _db;

  FirestoreCourseRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _courses =>
      _db.collection('courses');

  CollectionReference<Map<String, dynamic>> _enrollments(String uid) =>
      _db.collection('users').doc(uid).collection('enrollments');

  @override
  Future<List<Course>> getCourses({String? subject, String? level}) async {
    // Timed as its own trace mainly for the `allCoursesProvider` case
    // (no filters - the whole-catalog fetch on session start), since
    // that's the one that gates how long a student stares at a
    // skeleton screen before the app is usable.
    return PerfTrace.run('catalog_fetch', () async {
      Query<Map<String, dynamic>> query =
          _courses.where('status', isEqualTo: 'published');
      if (subject != null && subject != 'All') {
        query = query.where('subject', isEqualTo: subject);
      }
      if (level != null && level != 'All') {
        query = query.where('level', isEqualTo: level);
      }
      final snapshot = await query.get();
      return snapshot.docs
          .map((d) => Course.fromMap(d.id, d.data()))
          .toList();
    });
  }

  @override
  Future<Course?> getCourseById(String courseId) async {
    final doc = await _courses.doc(courseId).get();
    if (!doc.exists || doc.data() == null) return null;
    return Course.fromMap(doc.id, doc.data()!);
  }

  @override
  Future<List<CourseProgress>> getContinueLearning(String uid) async {
    final snapshot = await _enrollments(uid)
        .orderBy('lastAccessedAt', descending: true)
        .limit(10)
        .get();
    return snapshot.docs
        .map((d) => CourseProgress.fromMap(d.id, d.data()))
        .toList();
  }

  @override
  Future<List<Course>> getRecommended(String uid, {int limit = 4}) async {
    // No personalization model yet - surface the most-enrolled courses.
    // Swap this query out once a recommendation service exists; callers
    // only depend on the interface, not this implementation detail.
    final snapshot = await _courses
        .where('status', isEqualTo: 'published')
        .orderBy('studentsCount', descending: true)
        .limit(limit)
        .get();
    return snapshot.docs.map((d) => Course.fromMap(d.id, d.data())).toList();
  }

  @override
  Future<void> recordLessonProgress({
    required String uid,
    required Course course,
    required String lessonLabel,
    required double progressPercent,
  }) async {
    final progress = CourseProgress(
      courseId: course.id,
      courseTitle: course.title,
      iconKey: course.iconKey,
      colorKey: course.colorKey,
      lastLessonLabel: lessonLabel,
      progressPercent: progressPercent,
      lastAccessedAt: DateTime.now(),
    );
    await _enrollments(uid)
        .doc(course.id)
        .set(progress.toMap(), SetOptions(merge: true));
  }
}
