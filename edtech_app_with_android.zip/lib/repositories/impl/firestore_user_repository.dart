import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/app_user.dart';
import '../../models/notification_prefs.dart';
import '../../models/user_role.dart';
import '../user_repository.dart';

class FirestoreUserRepository implements UserRepository {
  final FirebaseFirestore _db;

  FirestoreUserRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');

  @override
  Future<AppUser?> getProfile(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    return AppUser.fromMap(uid, doc.data()!);
  }

  @override
  Stream<AppUser?> watchProfile(String uid) {
    return _users.doc(uid).snapshots().map((doc) {
      if (!doc.exists || doc.data() == null) return null;
      return AppUser.fromMap(uid, doc.data()!);
    });
  }

  @override
  Future<void> createProfileIfMissing(String uid, {String? phoneNumber}) async {
    final ref = _users.doc(uid);
    final existing = await ref.get();
    if (existing.exists) return;
    final user = AppUser(
      uid: uid,
      phoneNumber: phoneNumber,
      role: UserRole.student,
      createdAt: DateTime.now(),
    );
    await ref.set(user.toMap());
  }

  @override
  Future<void> setRole(String uid, UserRole role) async {
    await _users.doc(uid).set({'role': role.storageValue}, SetOptions(merge: true));
  }

  @override
  Future<void> stampLastActive(String uid) async {
    await _users.doc(uid).set(
      {'lastActiveAt': DateTime.now().toIso8601String()},
      SetOptions(merge: true),
    );
  }

  @override
  Stream<Map<String, bool>> watchNotificationPrefs(String uid) {
    return _users.doc(uid).snapshots().map((doc) {
      final stored = (doc.data()?['notificationPrefs'] as Map?) ?? {};
      return {
        for (final key in optionalNotificationCategories.keys)
          key: stored[key] as bool? ?? true,
      };
    });
  }

  @override
  Future<void> updateNotificationPrefs(
      String uid, Map<String, bool> prefs) async {
    await _users.doc(uid).set(
      {'notificationPrefs': prefs},
      SetOptions(merge: true),
    );
  }
}
