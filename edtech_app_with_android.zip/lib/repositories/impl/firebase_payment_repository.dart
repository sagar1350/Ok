import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../../models/course_purchase.dart';
import '../../models/subscription_status.dart';
import '../payment_repository.dart';

/// Talks to the `createOrder`/`verifyPayment` callables in
/// `functions/index.js` and reads the resulting entitlement docs back
/// from Firestore. Mirrors the shape of `FirestoreCourseRepository` -
/// screens/providers depend on `PaymentRepository`, not this class.
class FirebasePaymentRepository implements PaymentRepository {
  final FirebaseFunctions _functions;
  final FirebaseFirestore _firestore;

  FirebasePaymentRepository({
    FirebaseFunctions? functions,
    FirebaseFirestore? firestore,
  })  : _functions = functions ?? FirebaseFunctions.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Future<CheckoutOrder> createCourseOrder(String courseId) async {
    final result = await _functions.httpsCallable('createOrder').call({
      'type': 'course',
      'courseId': courseId,
    });
    return _orderFromResponse(result.data);
  }

  @override
  Future<CheckoutOrder> createSubscriptionOrder(SubscriptionPlan plan) async {
    final result = await _functions.httpsCallable('createOrder').call({
      'type': 'subscription',
      'plan': plan.id,
    });
    return _orderFromResponse(result.data);
  }

  CheckoutOrder _orderFromResponse(dynamic data) {
    final map = Map<String, dynamic>.from(data as Map);
    return CheckoutOrder(
      razorpayOrderId: map['razorpayOrderId'] as String,
      razorpayKeyId: map['razorpayKeyId'] as String,
      amountInPaise: (map['amountInPaise'] as num).toInt(),
      currency: map['currency'] as String? ?? 'INR',
      description: map['description'] as String? ?? '',
    );
  }

  @override
  Future<void> verifyPayment({
    required String razorpayOrderId,
    required String razorpayPaymentId,
    required String razorpaySignature,
  }) async {
    await _functions.httpsCallable('verifyPayment').call({
      'razorpay_order_id': razorpayOrderId,
      'razorpay_payment_id': razorpayPaymentId,
      'razorpay_signature': razorpaySignature,
    });
  }

  @override
  Stream<Set<String>> watchPurchasedCourseIds(String uid) {
    return _firestore
        .collection('users')
        .doc(uid)
        .collection('purchases')
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.id).toSet());
  }

  @override
  Stream<CoursePurchase?> watchCoursePurchase(String uid, String courseId) {
    return _firestore
        .collection('users')
        .doc(uid)
        .collection('purchases')
        .doc(courseId)
        .snapshots()
        .map((snap) =>
            snap.exists ? CoursePurchase.fromMap(courseId, snap.data()!) : null);
  }

  @override
  Stream<SubscriptionStatus?> watchSubscription(String uid) {
    return _firestore
        .collection('users')
        .doc(uid)
        .collection('subscription')
        .doc('current')
        .snapshots()
        .map((snap) =>
            snap.exists ? SubscriptionStatus.fromMap(snap.data()!) : null);
  }
}
