import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/quiz.dart';
import '../quiz_repository.dart';

class FirestoreQuizRepository implements QuizRepository {
  final FirebaseFirestore _db;

  FirestoreQuizRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  @override
  Future<Quiz?> getQuiz(String quizId) async {
    final doc = await _db.collection('quizzes').doc(quizId).get();
    if (!doc.exists || doc.data() == null) return null;
    return Quiz.fromMap(doc.id, doc.data()!);
  }

  @override
  Future<void> submitResult({
    required String uid,
    required String quizId,
    required int score,
    required int total,
  }) async {
    await _db
        .collection('users')
        .doc(uid)
        .collection('quizAttempts')
        .add({
      'quizId': quizId,
      'score': score,
      'total': total,
      'submittedAt': DateTime.now().toIso8601String(),
    });
  }
}
