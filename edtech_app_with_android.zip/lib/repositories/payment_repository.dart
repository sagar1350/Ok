import '../models/course_purchase.dart';
import '../models/subscription_status.dart';

/// The order data needed to open the Razorpay checkout sheet, handed
/// back by `createCourseOrder`/`createSubscriptionOrder`. The amount
/// and Razorpay order id always come from the server
/// (`createOrder` Cloud Function) - never computed on-device.
class CheckoutOrder {
  final String razorpayOrderId;
  final String razorpayKeyId;
  final int amountInPaise;
  final String currency;
  final String description;

  const CheckoutOrder({
    required this.razorpayOrderId,
    required this.razorpayKeyId,
    required this.amountInPaise,
    required this.currency,
    required this.description,
  });
}

abstract class PaymentRepository {
  /// Asks the server to create a Razorpay order for a one-time course
  /// purchase. Throws if the course is free or already owned.
  Future<CheckoutOrder> createCourseOrder(String courseId);

  /// Asks the server to create a Razorpay order for a subscription
  /// plan.
  Future<CheckoutOrder> createSubscriptionOrder(SubscriptionPlan plan);

  /// Sends the Razorpay checkout result to the server for signature
  /// verification. Only after this returns successfully does the
  /// purchase/subscription doc exist - a client-side "payment
  /// succeeded" callback from the Razorpay SDK is never enough on its
  /// own to unlock content.
  Future<void> verifyPayment({
    required String razorpayOrderId,
    required String razorpayPaymentId,
    required String razorpaySignature,
  });

  /// Live stream of the signed-in user's purchased course ids.
  Stream<Set<String>> watchPurchasedCourseIds(String uid);

  Stream<CoursePurchase?> watchCoursePurchase(String uid, String courseId);

  /// Live stream of the signed-in user's subscription (null if they
  /// have never subscribed).
  Stream<SubscriptionStatus?> watchSubscription(String uid);
}
