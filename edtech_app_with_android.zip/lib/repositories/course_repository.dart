import '../models/course.dart';
import '../models/course_progress.dart';

abstract class CourseRepository {
  /// All courses, optionally filtered by subject/level ('All' means no
  /// filter for that dimension).
  Future<List<Course>> getCourses({String? subject, String? level});

  Future<Course?> getCourseById(String courseId);

  /// Courses the user is actively enrolled in, most-recently-accessed
  /// first - powers the dashboard's "Continue Learning" row.
  Future<List<CourseProgress>> getContinueLearning(String uid);

  /// A short recommended list for the dashboard. Falls back to "most
  /// popular" when there isn't enough personalization data yet.
  Future<List<Course>> getRecommended(String uid, {int limit = 4});

  Future<void> recordLessonProgress({
    required String uid,
    required Course course,
    required String lessonLabel,
    required double progressPercent,
  });
}
