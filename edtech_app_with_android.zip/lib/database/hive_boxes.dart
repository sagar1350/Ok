class HiveBoxes {

  static const syncQueue = "sync_queue";

  // main.dart pehle se hi in do boxes ko raw string literals se khol raha
  // tha (Hive.openBox('settings') / Hive.openBox('downloads')) - unhe bhi
  // yahan la kar ek hi jagah se sab box names manage karte hain, taaki
  // future mein koi naya box add karte waqt typo se do alag names na ban
  // jayein (e.g. "download" vs "downloads").
  static const settings = "settings";
  static const downloads = "downloads";

}
