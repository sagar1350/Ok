import 'package:hive_flutter/hive_flutter.dart';

import '../models/sync_item.dart';
import 'hive_boxes.dart';

class LocalDatabase {

  static Future<void> init() async {

    await Hive.initFlutter();

    Hive.registerAdapter(SyncItemAdapter());

    await Hive.openBox<SyncItem>(HiveBoxes.syncQueue);

    // Phase 3/4 se already-existing untyped boxes bhi yahin khol rahe hain,
    // taaki main.dart mein Hive setup ek hi jagah se ho (pehle yeh
    // Hive.openBox('settings') / Hive.openBox('downloads') seedha
    // main.dart mein the).
    await Hive.openBox(HiveBoxes.settings);
    await Hive.openBox(HiveBoxes.downloads);

  }

  static Box<SyncItem> get syncBox =>
      Hive.box<SyncItem>(HiveBoxes.syncQueue);

  static Box get settingsBox => Hive.box(HiveBoxes.settings);

  static Box get downloadsBox => Hive.box(HiveBoxes.downloads);

}
