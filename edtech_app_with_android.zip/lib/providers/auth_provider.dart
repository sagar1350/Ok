import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../repositories/auth_repository.dart';
import '../repositories/user_repository.dart';
import '../utils/logger.dart';
import 'repository_providers.dart';
import '../services/notification_service.dart' show NotificationService;

// Auth state model
class AuthState {
  final String? uid;
  final bool isLoading;
  final String? error;
  final String? verificationId;
  final bool isLoggedIn;

  const AuthState({
    this.uid,
    this.isLoading = false,
    this.error,
    this.verificationId,
    this.isLoggedIn = false,
  });

  AuthState copyWith({
    String? uid,
    bool? isLoading,
    String? error,
    String? verificationId,
    bool? isLoggedIn,
  }) {
    return AuthState(
      uid: uid ?? this.uid,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      verificationId: verificationId ?? this.verificationId,
      isLoggedIn: isLoggedIn ?? this.isLoggedIn,
    );
  }
}

// Auth provider - sare auth functions yahan hain.
// AuthNotifier ab AuthRepository (interface) pe depend karta hai, seedhe
// FirebaseAuth pe nahi - isse auth flow ko fake repo ke saath test kiya
// ja sakta hai, aur backend switch karne ke liye sirf repository_providers.dart
// mein binding change karni hogi.
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    ref.watch(authRepositoryProvider),
    ref.watch(userRepositoryProvider),
  );
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _authRepo;
  final UserRepository _userRepo;
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  AuthNotifier(this._authRepo, this._userRepo) : super(const AuthState()) {
    _checkExistingUser();
  }

  // Check karo pehle se login hai ya nahi
  void _checkExistingUser() {
    _authRepo.authStateChanges().listen((String? uid) {
      if (uid != null) {
        state = state.copyWith(uid: uid, isLoggedIn: true);
        // Har login pe profile doc create karo agar pehle se nahi hai.
        _userRepo.createProfileIfMissing(uid);
        // One write per app session (not per screen) - good enough
        // resolution for the admin dashboard's daily/monthly active-
        // user counts without turning every navigation into a write.
        _userRepo.stampLastActive(uid);
        // Crash reports ko is uid se tag karo (see AppLogger.setUserId
        // doc comment for why - shared-device app, helps correlate a
        // crash to a specific account during investigation).
        AppLogger.setUserId(uid);
      } else {
        state = state.copyWith(isLoggedIn: false);
        AppLogger.setUserId(null);
      }
    });
  }

  // OTP bhejo phone number par
  Future<void> sendOTP(String phoneNumber) async {
    state = state.copyWith(isLoading: true, error: null);

    try {
      await _authRepo.sendOtp(
        phoneNumber,
        onCodeSent: (verificationId) {
          state = state.copyWith(
            isLoading: false,
            verificationId: verificationId,
          );
        },
        onVerificationFailed: (message) {
          state = state.copyWith(isLoading: false, error: message);
        },
        onAutoVerified: () {
          state = state.copyWith(isLoading: false, isLoggedIn: true);
        },
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString(),
      );
    }
  }

  // OTP verify karo
  Future<bool> verifyOTP(String smsCode) async {
    state = state.copyWith(isLoading: true);

    if (state.verificationId == null) {
      state = state.copyWith(
        isLoading: false,
        error: 'Please request a new OTP and try again.',
      );
      return false;
    }

    final success = await _authRepo.verifyOtp(
      verificationId: state.verificationId!,
      smsCode: smsCode,
    );

    if (success) {
      state = state.copyWith(isLoading: false, isLoggedIn: true);
    } else {
      state = state.copyWith(
        isLoading: false,
        error: 'Invalid OTP. Please try again.',
      );
    }
    return success;
  }

  // Logout
  Future<void> logout() async {
    await _authRepo.signOut();
    await _storage.deleteAll();

    // Shared-device app - don't let the next person keep receiving this
    // user's pushes (see notification_service.dart's deleteToken doc).
    try {
      await NotificationService().deleteToken();
    } catch (_) {
      // Non-fatal, same reasoning as the downloads-box clear below.
    }

    // This is a shared-device app (school/library phones/tablets are
    // common for students) - anything cached per-user must not survive
    // into the next person's session. `settings` (theme/locale) is a
    // device preference and is intentionally left alone; `downloads`
    // is per-user content and must go. Guarded the same way main.dart
    // guards Hive startup - a cache-clear failure shouldn't block logout.
    try {
      if (Hive.isBoxOpen('downloads')) {
        await Hive.box('downloads').clear();
      }
    } catch (_) {
      // Non-fatal - worst case a stale download list lingers until the
      // box is next opened and cleared.
    }

    state = const AuthState();
  }
}
