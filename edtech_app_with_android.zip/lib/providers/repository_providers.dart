import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../repositories/auth_repository.dart';
import '../repositories/course_repository.dart';
import '../repositories/payment_repository.dart';
import '../repositories/quiz_repository.dart';
import '../repositories/user_repository.dart';
import '../repositories/impl/firebase_auth_repository.dart';
import '../repositories/impl/firebase_payment_repository.dart';
import '../repositories/impl/firestore_course_repository.dart';
import '../repositories/impl/firestore_quiz_repository.dart';
import '../repositories/impl/firestore_user_repository.dart';

/// Single place where interfaces are bound to concrete implementations.
/// Everything else in the app (notifiers, screens) depends on the
/// abstract *Repository types above, not on Firebase directly - so
/// swapping backends or injecting fakes in tests means overriding just
/// these providers, e.g.:
///
/// ```dart
/// ProviderScope(
///   overrides: [authRepositoryProvider.overrideWithValue(FakeAuthRepository())],
///   child: ...,
/// )
/// ```
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return FirebaseAuthRepository();
});

final userRepositoryProvider = Provider<UserRepository>((ref) {
  return FirestoreUserRepository();
});

final courseRepositoryProvider = Provider<CourseRepository>((ref) {
  return FirestoreCourseRepository();
});

final quizRepositoryProvider = Provider<QuizRepository>((ref) {
  return FirestoreQuizRepository();
});

final paymentRepositoryProvider = Provider<PaymentRepository>((ref) {
  return FirebasePaymentRepository();
});
