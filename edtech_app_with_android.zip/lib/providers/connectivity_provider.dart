import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Whether the device currently has *some* network path (wifi/cellular).
/// This is a device-level signal, not a guarantee Firebase itself is
/// reachable (e.g. captive portals, or Firebase being down) - it's used
/// to explain *why* a screen might be showing stale/cached data, not to
/// gate reads (Firestore already falls back to cache automatically).
final connectivityProvider = StreamProvider<bool>((ref) async* {
  final connectivity = Connectivity();

  final initial = await connectivity.checkConnectivity();
  yield _isOnline(initial);

  yield* connectivity.onConnectivityChanged.map(_isOnline);
});

bool _isOnline(List<ConnectivityResult> results) {
  return results.any((r) => r != ConnectivityResult.none);
}
