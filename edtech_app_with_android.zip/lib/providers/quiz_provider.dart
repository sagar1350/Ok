import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/quiz.dart';
import '../repositories/quiz_repository.dart';
import 'auth_provider.dart';
import 'repository_providers.dart';

class QuizState {
  final bool isLoading;
  final String? error;
  final Quiz? quiz;
  final int currentQuestion;
  final int score;
  final int? selectedOption;
  final bool isAnswered;
  final bool isFinished;

  const QuizState({
    this.isLoading = true,
    this.error,
    this.quiz,
    this.currentQuestion = 0,
    this.score = 0,
    this.selectedOption,
    this.isAnswered = false,
    this.isFinished = false,
  });

  QuizState copyWith({
    bool? isLoading,
    String? error,
    Quiz? quiz,
    int? currentQuestion,
    int? score,
    int? selectedOption,
    bool clearSelectedOption = false,
    bool? isAnswered,
    bool? isFinished,
  }) {
    return QuizState(
      isLoading: isLoading ?? this.isLoading,
      error: error,
      quiz: quiz ?? this.quiz,
      currentQuestion: currentQuestion ?? this.currentQuestion,
      score: score ?? this.score,
      selectedOption:
          clearSelectedOption ? null : (selectedOption ?? this.selectedOption),
      isAnswered: isAnswered ?? this.isAnswered,
      isFinished: isFinished ?? this.isFinished,
    );
  }
}

/// Drives the quiz-taking flow (QuizScreen). Previously this state and
/// the question data both lived inside the widget's setState - moved
/// here so the quiz can be loaded from Firestore and so submitting a
/// result is a repository call instead of dead code.
class QuizController extends StateNotifier<QuizState> {
  final QuizRepository _repo;
  final String? _uid;
  final String _quizId;

  QuizController(this._repo, this._uid, {String quizId = 'daily'})
      : _quizId = quizId,
        super(const QuizState()) {
    _load();
  }

  Future<void> _load() async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final quiz = await _repo.getQuiz(_quizId);
      if (quiz == null || quiz.questions.isEmpty) {
        state = state.copyWith(
          isLoading: false,
          error: 'No quiz available right now.',
        );
        return;
      }
      state = state.copyWith(isLoading: false, quiz: quiz);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void checkAnswer(int selectedOption) {
    if (state.isAnswered || state.quiz == null) return;
    final question = state.quiz!.questions[state.currentQuestion];
    final correct = selectedOption == question.correctIndex;
    state = state.copyWith(
      selectedOption: selectedOption,
      isAnswered: true,
      score: correct ? state.score + 1 : state.score,
    );
  }

  void nextQuestion() {
    final quiz = state.quiz;
    if (quiz == null) return;
    if (state.currentQuestion < quiz.questions.length - 1) {
      state = state.copyWith(
        currentQuestion: state.currentQuestion + 1,
        clearSelectedOption: true,
        isAnswered: false,
      );
    } else {
      state = state.copyWith(isFinished: true);
      if (_uid != null) {
        _repo.submitResult(
          uid: _uid,
          quizId: _quizId,
          score: state.score,
          total: quiz.questions.length,
        );
      }
    }
  }

  void retry() {
    state = state.copyWith(
      currentQuestion: 0,
      score: 0,
      clearSelectedOption: true,
      isAnswered: false,
      isFinished: false,
    );
  }
}

final quizControllerProvider =
    StateNotifierProvider.autoDispose<QuizController, QuizState>((ref) {
  final uid = ref.watch(authProvider).uid;
  return QuizController(ref.watch(quizRepositoryProvider), uid);
});
