import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../models/subscription_status.dart';
import 'auth_provider.dart';
import 'repository_providers.dart';

/// The signed-in user's purchased course ids, live. Empty (not an
/// error) when signed out - screens should already be gating on
/// `authProvider` before reaching anything that reads this.
final purchasedCourseIdsProvider = StreamProvider.autoDispose<Set<String>>((ref) {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return const Stream.empty();
  return ref.watch(paymentRepositoryProvider).watchPurchasedCourseIds(uid);
});

final subscriptionStatusProvider =
    StreamProvider.autoDispose<SubscriptionStatus?>((ref) {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return const Stream.empty();
  return ref.watch(paymentRepositoryProvider).watchSubscription(uid);
});

/// Whether the signed-in user can play a given course's `locked`
/// lessons right now: free course, an active subscription, or a
/// one-time purchase of that specific course. `CourseDetailScreen` and
/// `VideoPlayerScreen` both read this instead of re-deriving it.
final hasCourseAccessProvider = Provider.autoDispose.family<bool, Course>((ref, course) {
  if (course.isFree) return true;

  final subscription = ref.watch(subscriptionStatusProvider).valueOrNull;
  if (subscription?.isActive == true) return true;

  final purchased = ref.watch(purchasedCourseIdsProvider).valueOrNull ?? {};
  return purchased.contains(course.id);
});
