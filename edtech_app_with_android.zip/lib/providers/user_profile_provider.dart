import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/app_user.dart';
import '../models/user_role.dart';
import '../models/app_permissions.dart';
import 'auth_provider.dart';
import 'repository_providers.dart';

/// Streams the signed-in user's profile doc (name, role) so
/// RoleSelectionScreen and the dashboard stay in sync with Firestore.
/// Emits null while signed out or before the profile doc exists.
final userProfileProvider = StreamProvider<AppUser?>((ref) {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return Stream.value(null);
  return ref.watch(userRepositoryProvider).watchProfile(uid);
});

/// UI capability flags derived from the current profile's role - see
/// AppPermissions' doc comment for why this is UI-only, never a
/// substitute for real access checks (isAdminProvider / rules).
final permissionsProvider = Provider<AppPermissions>((ref) {
  final role = ref.watch(userProfileProvider).valueOrNull?.role ?? UserRole.student;
  return AppPermissions(role);
});

/// Persists the role the user picks on RoleSelectionScreen.
final setUserRoleProvider =
    Provider<Future<void> Function(UserRole)>((ref) {
  return (UserRole role) async {
    final uid = ref.read(authProvider).uid;
    if (uid == null) return;
    await ref.read(userRepositoryProvider).setRole(uid, role);
  };
});
