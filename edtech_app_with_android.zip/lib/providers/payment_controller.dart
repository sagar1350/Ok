import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../models/subscription_status.dart';
import '../services/razorpay_checkout_service.dart';
import 'repository_providers.dart';
import 'user_profile_provider.dart';

/// Drives a single purchase attempt end to end:
/// 1. `createOrder` Cloud Function (server decides the price - never
///    trust `course.priceInr`/`plan.priceInr` for the actual charge,
///    they're display-only on the client).
/// 2. Razorpay's native checkout sheet.
/// 3. `verifyPayment` Cloud Function, which checks the payment
///    signature and only then writes the purchase/subscription doc
///    that unlocks content.
///
/// `AsyncValue<void>` on this notifier is purely "is a purchase in
/// flight / did it just fail" for the button's own spinner - it is
/// never read to decide access; `hasCourseAccessProvider` (backed by
/// the Firestore doc `verifyPayment` writes) is the only source of
/// truth for that.
class PaymentController extends StateNotifier<AsyncValue<void>> {
  final Ref _ref;
  final RazorpayCheckoutService _checkout = RazorpayCheckoutService();

  PaymentController(this._ref) : super(const AsyncValue.data(null));

  Future<void> purchaseCourse(Course course) => _run(() async {
        final repo = _ref.read(paymentRepositoryProvider);
        final order = await repo.createCourseOrder(course.id);
        final result = await _checkout.open(
          order: order,
          contactPhone: _contactPhone(),
        );
        await repo.verifyPayment(
          razorpayOrderId: result.razorpayOrderId,
          razorpayPaymentId: result.razorpayPaymentId,
          razorpaySignature: result.razorpaySignature,
        );
      });

  Future<void> subscribe(SubscriptionPlan plan) => _run(() async {
        final repo = _ref.read(paymentRepositoryProvider);
        final order = await repo.createSubscriptionOrder(plan);
        final result = await _checkout.open(
          order: order,
          contactPhone: _contactPhone(),
        );
        await repo.verifyPayment(
          razorpayOrderId: result.razorpayOrderId,
          razorpayPaymentId: result.razorpayPaymentId,
          razorpaySignature: result.razorpaySignature,
        );
      });

  String _contactPhone() =>
      _ref.read(userProfileProvider).valueOrNull?.phoneNumber ?? '';

  Future<void> _run(Future<void> Function() action) async {
    state = const AsyncValue.loading();
    try {
      await action();
      state = const AsyncValue.data(null);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}

final paymentControllerProvider =
    StateNotifierProvider.autoDispose<PaymentController, AsyncValue<void>>(
        (ref) => PaymentController(ref));
