import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'auth_provider.dart';
import 'repository_providers.dart';

/// The single source of truth for "is this user allowed into the
/// admin dashboard". Backed by AuthRepository.isAdmin(), which reads
/// the `admin` custom claim off the Firebase ID token - a claim only
/// the setAdminRole Cloud Function can set.
///
/// Deliberately NOT derived from userProfileProvider's `role` field:
/// that field lives in Firestore, is only a display label, and (as of
/// the firestore.rules tightening) can no longer even be client-set
/// to 'admin' - but this provider is what actually gates navigation,
/// so it never trusts that field even indirectly.
///
/// Re-evaluates whenever authProvider's uid changes (login/logout).
/// Call `ref.refresh(isAdminProvider)` after a grant/revoke might have
/// just happened, since Firebase caches ID tokens for up to an hour.
final isAdminProvider = FutureProvider<bool>((ref) async {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return false;
  return ref.watch(authRepositoryProvider).isAdmin();
});
