import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/course.dart';
import '../models/course_progress.dart';
import 'auth_provider.dart';
import 'repository_providers.dart';

class CourseFilter {
  final String subject;
  final String level;
  const CourseFilter({this.subject = 'All', this.level = 'All'});

  CourseFilter copyWith({String? subject, String? level}) => CourseFilter(
        subject: subject ?? this.subject,
        level: level ?? this.level,
      );
}

/// Holds the currently-selected subject/level filter chips on
/// CourseListScreen.
final courseFilterProvider =
    StateProvider<CourseFilter>((ref) => const CourseFilter());

/// The entire course catalog, fetched from Firestore exactly once per
/// app session (this provider has no `.autoDispose` and isn't a
/// `.family`, so Riverpod keeps its result cached for the lifetime of
/// the root ProviderScope). Everything else that needs course data -
/// the filtered list, a single course's detail, the dashboard's
/// recommended row - reads from this instead of issuing its own query.
///
/// This only makes sense because the catalog is small (tens to low
/// hundreds of courses, typical for a single-institution app). If this
/// ever needs to serve a catalog of thousands, filtering belongs back
/// on the server (Firestore `where` clauses + pagination) instead of
/// pulling everything client-side - watch `getCourses`' one remaining
/// caller below if that threshold gets close.
final allCoursesProvider = FutureProvider<List<Course>>((ref) async {
  return ref.watch(courseRepositoryProvider).getCourses();
});

/// The filtered course list for CourseListScreen. Filtering happens in
/// Dart over the already-fetched `allCoursesProvider` result instead of
/// re-querying Firestore per filter chip tap - each tap used to be a
/// network round trip (and a Firestore read) even though the whole
/// catalog was already sitting in memory. This also means changing
/// filters keeps working offline, since no new query is issued.
final courseListProvider = Provider<AsyncValue<List<Course>>>((ref) {
  final filter = ref.watch(courseFilterProvider);
  final coursesAsync = ref.watch(allCoursesProvider);
  return coursesAsync.whenData((courses) {
    return courses.where((c) {
      final subjectOk = filter.subject == 'All' || c.subject == filter.subject;
      final levelOk = filter.level == 'All' || c.level == filter.level;
      return subjectOk && levelOk;
    }).toList();
  });
});

/// A single course's detail, by id. Looks it up in the already-cached
/// catalog first (instant, no network call, works offline) and only
/// falls back to a direct Firestore fetch for a course that isn't in
/// that list yet - e.g. a deep link opened before the catalog has
/// loaded. `.autoDispose` because, unlike the catalog, there's no
/// benefit to keeping every course-detail visit resident in memory for
/// the rest of the session.
final courseDetailProvider =
    FutureProvider.autoDispose.family<Course?, String>((ref, courseId) async {
  final allCourses = await ref.watch(allCoursesProvider.future);
  final match = allCourses.where((c) => c.id == courseId);
  if (match.isNotEmpty) return match.first;
  return ref.watch(courseRepositoryProvider).getCourseById(courseId);
});

/// "Continue Learning" row on the dashboard - the signed-in user's
/// active enrollments, most-recent first. This is inherently a
/// separate query (per-user subcollection, not part of the catalog),
/// so it can't be derived from `allCoursesProvider`. `VideoPlayerScreen`
/// invalidates this after recording lesson progress so the row updates
/// without needing an app restart.
final continueLearningProvider =
    FutureProvider<List<CourseProgress>>((ref) async {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return [];
  return ref.watch(courseRepositoryProvider).getContinueLearning(uid);
});

/// "Recommended" row on the dashboard. Kept as its own repository call
/// (rather than derived from `allCoursesProvider` client-side) even
/// though today's implementation just sorts by student count - a real
/// recommendation engine will need its own backend logic anyway, and
/// this is the seam where that plugs in later without touching the UI.
final recommendedCoursesProvider = FutureProvider<List<Course>>((ref) async {
  final uid = ref.watch(authProvider).uid;
  if (uid == null) return [];
  return ref.watch(courseRepositoryProvider).getRecommended(uid);
});
