import 'package:flutter/material.dart';

/// Maps the small string keys stored on [Course]/[CourseProgress]
/// (`iconKey`, `colorKey`) to actual Flutter types. Kept separate from
/// the models so `models/` has no Flutter dependency and stays easy to
/// unit test.
class CourseVisuals {
  CourseVisuals._();

  static const _icons = <String, IconData>{
    'code': Icons.code,
    'calculate': Icons.calculate,
    'biotech': Icons.biotech,
    'language': Icons.language,
    'history': Icons.history,
    'computer': Icons.computer,
  };

  static const _colors = <String, Color>{
    'deepPurple': Colors.deepPurple,
    'teal': Colors.teal,
    'orange': Colors.orange,
    'pink': Colors.pink,
    'blue': Colors.blue,
    'indigo': Colors.indigo,
  };

  static IconData icon(String key) => _icons[key] ?? Icons.school;

  static Color color(String key) => _colors[key] ?? Colors.deepPurple;
}
