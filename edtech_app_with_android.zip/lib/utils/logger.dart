import 'package:flutter/foundation.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

/// Centralized place to record errors.
///
/// Debug console mein hamesha print karta hai. Jab Firebase ready ho
/// (see `AppLogger.attachCrashlytics` in main.dart), errors/logs
/// Firebase Crashlytics ko bhi forward hote hain - non-fatal by default,
/// `fatal: true` un cases ke liye jo already app ko crash kar chuke the
/// (runZonedGuarded/FlutterError.onError se aane wale).
///
/// Sab jagah errors is ek jagah se guzarte hain isliye crash reporting
/// service switch karna (Crashlytics se Sentry, waghera) sirf is file
/// mein change se ho jayega.
class AppLogger {
  AppLogger._();

  /// Firebase init hone se pehle ya jab Firebase configured hi nahi hai
  /// (placeholder config - see config_check.dart), Crashlytics available
  /// nahi hota. Isliye yeh flag off rehta hai jab tak main.dart
  /// explicitly `attachCrashlytics()` na bulaye - us se pehle recordError
  /// sirf console pe print karta hai, kabhi crash nahi hota agar
  /// Crashlytics missing ho.
  static bool _crashlyticsAttached = false;

  /// Firebase.initializeApp() ke baad main.dart se bulao. Debug builds
  /// mein Crashlytics collection off rakhte hain by default taaki local
  /// dev noise production dashboard ko clutter na kare - override karne
  /// ke liye kDebugMode check hata sakte ho agar debug builds ke crashes
  /// bhi track karne hain.
  static Future<void> attachCrashlytics() async {
    try {
      await FirebaseCrashlytics.instance
          .setCrashlyticsCollectionEnabled(!kDebugMode);
      _crashlyticsAttached = true;
    } catch (e, st) {
      // Crashlytics khud fail ho gaya to bas console pe log karo - app
      // launch hona chahiye regardless.
      if (kDebugMode) {
        // ignore: avoid_print
        print('[AppLogger] Crashlytics attach failed: $e\n$st');
      }
    }
  }

  static void recordError(
    Object error,
    StackTrace? stack, {
    String? reason,
    bool fatal = false,
  }) {
    if (kDebugMode) {
      // ignore: avoid_print
      print('[AppLogger] ${reason ?? 'Error'}: $error');
      if (stack != null) {
        // ignore: avoid_print
        print(stack);
      }
    }

    if (_crashlyticsAttached) {
      FirebaseCrashlytics.instance.recordError(
        error,
        stack,
        reason: reason,
        fatal: fatal,
      );
    }
  }

  /// Breadcrumb-style log line, visible in a Crashlytics report's log
  /// history alongside whatever error eventually gets recorded - useful
  /// for "what happened right before this crash" without needing a full
  /// analytics pipeline.
  static void info(String message) {
    if (kDebugMode) {
      // ignore: avoid_print
      print('[AppLogger] $message');
    }
    if (_crashlyticsAttached) {
      FirebaseCrashlytics.instance.log(message);
    }
  }

  /// Attaches the signed-in user's uid to future Crashlytics reports, so
  /// a crash can be correlated back to a specific account when
  /// investigating (e.g. "this user keeps hitting a crash on the quiz
  /// screen"). Call from AuthNotifier on login; call with `null` on
  /// logout to clear it, since Crashlytics keeps the identifier across
  /// the whole app session otherwise (and this is a shared device app -
  /// see the per-user Hive clearing in AuthNotifier.logout).
  static void setUserId(String? uid) {
    if (_crashlyticsAttached) {
      FirebaseCrashlytics.instance.setUserIdentifier(uid ?? '');
    }
  }
}
