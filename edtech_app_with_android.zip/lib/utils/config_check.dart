import 'package:firebase_core/firebase_core.dart';

/// Placeholder values jo `flutterfire configure` chalane se pehle
/// lib/firebase_options.dart mein hote hain. Agar app in values ke saath
/// launch hoti hai to Firebase.initializeApp() ek confusing native
/// exception deta hai jo pehchanna mushkil hota hai - isliye pehle hi
/// check kar lete hain.
const List<String> _placeholderMarkers = [
  'YOUR_API_KEY_HERE',
  'YOUR_APP_ID_HERE',
  'YOUR_SENDER_ID_HERE',
  'YOUR_PROJECT_ID_HERE',
];

bool isFirebaseConfigured(FirebaseOptions options) {
  final values = [
    options.apiKey,
    options.appId,
    options.messagingSenderId,
    options.projectId,
  ];
  return values.every((v) => !_placeholderMarkers.contains(v) && v.isNotEmpty);
}
