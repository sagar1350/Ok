import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:flutter/foundation.dart';
import 'logger.dart';

/// Activates Firebase App Check, which stops anything but this app's
/// real, unmodified builds from calling our Firebase Auth/Firestore
/// backend - a cloned APK, a scraped API key, or a bot hitting the
/// phone-auth endpoint directly all get rejected before they reach
/// Firestore, regardless of what the security rules say.
///
/// Debug builds use the debug provider (prints a token to the console
/// on first run - register it in Firebase console > App Check >
/// your app > Manage debug tokens, or debug builds will be rejected
/// once enforcement is turned on). Release builds use Play Integrity
/// (Android) / DeviceCheck+App Attest (iOS), which need no extra
/// client-side setup beyond enabling App Check for the app in the
/// Firebase console.
///
/// Called from main.dart right after Firebase.initializeApp() -
/// wrapped in its own try/catch there so a provider hiccup never
/// crashes app startup, only leaves App Check inactive (which is safe
/// as long as enforcement is left in "unenforced/monitor" mode until
/// you've confirmed real traffic isn't being rejected).
Future<void> activateAppCheck() async {
  try {
    await FirebaseAppCheck.instance.activate(
      androidProvider:
          kDebugMode ? AndroidProvider.debug : AndroidProvider.playIntegrity,
      appleProvider:
          kDebugMode ? AppleProvider.debug : AppleProvider.appAttest,
    );
  } catch (e, st) {
    AppLogger.recordError(e, st, reason: 'App Check activation failed');
  }
}
