import 'package:firebase_performance/firebase_performance.dart';
import 'logger.dart';

/// Thin wrapper around Firebase Performance Monitoring's custom traces.
///
/// Network requests (Firestore's underlying gRPC/HTTP calls) and screen
/// rendering are already auto-instrumented by the `firebase_performance`
/// SDK once it's initialized - nothing extra needed for those. This
/// wrapper is for the handful of operations worth measuring as their
/// own named trace: ones with logic beyond "wait for a network call"
/// (e.g. filtering an already-fetched catalog client-side) or ones the
/// team specifically wants a dashboard number for (e.g. "how long does
/// the catalog take to become usable on a student's first launch").
///
/// Wrapping every provider/repository call would just add noise to the
/// Performance dashboard - use this only where a slow trend would
/// actually change what gets optimized next.
class PerfTrace {
  PerfTrace._();

  /// Runs [action], timing it as a named trace `name`. If Performance
  /// Monitoring isn't available yet (Firebase not configured - see
  /// config_check.dart) this just runs [action] untimed; a missing
  /// trace should never be the reason a feature breaks.
  static Future<T> run<T>(String name, Future<T> Function() action) async {
    Trace? trace;
    try {
      trace = FirebasePerformance.instance.newTrace(name);
      await trace.start();
    } catch (e, st) {
      AppLogger.recordError(e, st, reason: 'PerfTrace start failed: $name');
      trace = null;
    }

    try {
      final result = await action();
      trace?.setMetric('success', 1);
      return result;
    } catch (e) {
      trace?.setMetric('success', 0);
      rethrow;
    } finally {
      try {
        await trace?.stop();
      } catch (_) {
        // Stopping a trace shouldn't be able to fail the underlying
        // operation it's measuring - swallow and move on.
      }
    }
  }
}
