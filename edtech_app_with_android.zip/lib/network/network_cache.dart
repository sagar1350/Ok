class NetworkCache {

  Future<void> saveResponse() async {}

  Future<dynamic> readResponse() async {}

}
