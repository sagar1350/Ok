import 'package:dio/dio.dart';

Future<Response> retryRequest(
    Dio dio,
    RequestOptions request,
) {

  return dio.fetch(request);

}
