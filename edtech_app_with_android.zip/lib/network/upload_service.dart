import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';

/// Thin wrapper over Firebase Storage uploads. [storagePath] must
/// match one of the patterns allowed in storage.rules (e.g.
/// `courses/{courseId}/thumbnail.png`) - an admin-only path for
/// anything the admin dashboard uploads.
class UploadService {
  final FirebaseStorage _storage;

  UploadService({FirebaseStorage? storage})
      : _storage = storage ?? FirebaseStorage.instance;

  /// Uploads [bytes] to [storagePath] and returns its public download
  /// URL. Throws [FirebaseException] on failure (e.g. rejected by
  /// storage.rules for size/content-type, or a network error) -
  /// callers should surface that to the admin as a retryable error
  /// rather than silently dropping the upload.
  Future<String> uploadBytes(
    String storagePath,
    Uint8List bytes, {
    required String contentType,
  }) async {
    final ref = _storage.ref(storagePath);
    await ref.putData(bytes, SettableMetadata(contentType: contentType));
    return ref.getDownloadURL();
  }

  Future<void> deleteFile(String storagePath) async {
    try {
      await _storage.ref(storagePath).delete();
    } on FirebaseException catch (e) {
      // object-not-found is fine (nothing to clean up); anything else
      // should still surface.
      if (e.code != 'object-not-found') rethrow;
    }
  }
}
