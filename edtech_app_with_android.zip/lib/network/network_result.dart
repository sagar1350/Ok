class NetworkResult<T> {
  final bool success;
  final T? data;
  final String? message;

  NetworkResult.success(this.data)
      : success = true,
        message = null;

  NetworkResult.failure(this.message)
      : success = false,
        data = null;
}
