class RefreshService {
  Future<bool> refreshToken() async {
    // TODO:
    // Call POST /auth/refresh
    // Read refresh token
    // Save new access token
    // Return true if successful

    return false;
  }
}
