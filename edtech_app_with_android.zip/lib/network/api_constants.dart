class ApiConstants {
  static const String baseUrl =
      "https://api.yourapp.com/v1";

  static const Duration connectTimeout =
      Duration(seconds: 30);

  static const Duration receiveTimeout =
      Duration(seconds: 30);
}
