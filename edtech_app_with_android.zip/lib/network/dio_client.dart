import 'package:dio/dio.dart';

import 'api_constants.dart';
import 'auth_interceptor.dart';
import 'logging_interceptor.dart';
import 'ssl_pinning.dart';

class DioClient {

  late final Dio dio;

  DioClient() {

    dio = Dio(
      BaseOptions(
        baseUrl: ApiConstants.baseUrl,
        connectTimeout:
            ApiConstants.connectTimeout,
        receiveTimeout:
            ApiConstants.receiveTimeout,
      ),
    );

    dio.interceptors.add(
      AuthInterceptor(dio),
    );

    dio.interceptors.add(
      LoggingInterceptor(),
    );

    // No-op until a real pinned cert is configured - see
    // ssl_pinning.dart's doc comment.
    SSLPinning.attachTo(dio);

  }

}
