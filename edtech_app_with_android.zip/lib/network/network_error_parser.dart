import 'package:dio/dio.dart';

String parseNetworkError(DioException e) {

  switch(e.type){

    case DioExceptionType.connectionTimeout:
      return "Connection Timeout";

    case DioExceptionType.receiveTimeout:
      return "Server Timeout";

    case DioExceptionType.badResponse:
      return "Server Error";

    default:
      return "Unknown Error";
  }

}
