import 'package:dio/dio.dart';

import 'network_error_parser.dart';
import 'network_result.dart';

class ApiService {

  final Dio dio;

  ApiService(this.dio);

  Future<NetworkResult<Map<String,dynamic>>> post(
      String url,
      Map<String,dynamic> body,
  ) async {

    try{

      final response =
          await dio.post(url,data: body);

      return NetworkResult.success(
          response.data);

    } on DioException catch(e){

      return NetworkResult.failure(
          parseNetworkError(e));

    }catch(e){

      return NetworkResult.failure(
          e.toString());

    }

  }

}
