import 'package:dio/dio.dart';

import 'network_retry.dart';
import 'refresh_service.dart';
import 'token_manager.dart';

class AuthInterceptor extends Interceptor {
  AuthInterceptor(this._dio);

  // Needed to actually replay the failed request after a successful
  // refresh (see onError's Retry branch below) - passed in from
  // DioClient rather than creating a fresh Dio here, so the retry
  // goes out with the same base URL/timeouts/other interceptors as
  // the original call.
  final Dio _dio;

  final TokenManager _tokenManager = TokenManager();
  final RefreshService _refreshService = RefreshService();

  @override
  Future<void> onRequest(
      RequestOptions options,
      RequestInterceptorHandler handler,
  ) async {

    final token = await _tokenManager.accessToken();

    if (token != null && token.isNotEmpty) {
      options.headers["Authorization"] = "Bearer $token";
    }

    options.headers["Content-Type"] = "application/json";
    options.headers["Accept"] = "application/json";

    handler.next(options);
  }

  @override
  Future<void> onError(
      DioException err,
      ErrorInterceptorHandler handler,
  ) async {

    final isUnauthorized = err.response?.statusCode == 401;
    // Guards against looping if the *refreshed* token also comes
    // back 401 (e.g. account disabled server-side).
    final alreadyRetried =
        err.requestOptions.extra['retriedAfterRefresh'] == true;

    if (!isUnauthorized || alreadyRetried) {
      handler.next(err);
      return;
    }

    // 401 -> Refresh Token API
    final refreshed = await _refreshService.refreshToken();

    if (!refreshed) {
      // Failed -> Logout. RefreshService.refreshToken() is still a
      // TODO stub that always returns false, so this is the branch
      // that actually runs today - clearing tokens here is the
      // "Logout" step; routing the user to the login screen still
      // depends on whatever reads auth state (AuthNotifier /
      // authRepositoryProvider) noticing the tokens are gone.
      await _tokenManager.clear();
      handler.next(err);
      return;
    }

    // Success -> Retry, with the freshly-saved access token.
    final newToken = await _tokenManager.accessToken();
    final retryOptions = err.requestOptions
      ..headers["Authorization"] = "Bearer $newToken"
      ..extra['retriedAfterRefresh'] = true;

    try {
      final response = await retryRequest(_dio, retryOptions);
      handler.resolve(response);
    } catch (_) {
      // Retry itself failed (network blip, still-bad response,
      // etc.) - fall through with the original error rather than
      // masking it with a different one.
      handler.next(err);
    }
  }
}
