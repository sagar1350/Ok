import 'package:dio/dio.dart';

class LoggingInterceptor extends Interceptor {

  @override
  void onRequest(
      RequestOptions options,
      RequestInterceptorHandler handler,
  ) {

    print("REQUEST : ${options.method}");
    print("URL : ${options.uri}");

    handler.next(options);
  }

  @override
  void onResponse(
      Response response,
      ResponseInterceptorHandler handler,
  ) {

    print("STATUS : ${response.statusCode}");

    handler.next(response);
  }

  @override
  void onError(
      DioException err,
      ErrorInterceptorHandler handler,
  ) {

    print("ERROR : ${err.message}");

    handler.next(err);
  }

}
