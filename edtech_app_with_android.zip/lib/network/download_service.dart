class DownloadService {

  Future<void> download(
      String url,
      String savePath,
  ) async {

    // Download with progress

  }

}
