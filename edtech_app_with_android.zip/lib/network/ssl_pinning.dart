import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';

/// Certificate pinning for [DioClient]. Was a 3-line comment stub
/// before this - the pasted `SSLPinningInterceptor`/`badCertificateCallback`
/// version wasn't usable as a fix, for reasons worth being explicit
/// about (see PHASE12_NOTES.md for the fuller writeup):
///
/// - It set `(options as dynamic).validateCertificate = ...` on a
///   `RequestOptions` - that property doesn't exist on the class, so
///   the assignment does nothing at all; no certificate is ever
///   actually checked through that path.
/// - `badCertificateCallback` alone doesn't pin anything either: Dart's
///   `HttpClient` only invokes it for a certificate that already FAILED
///   normal platform trust validation. A certificate from a
///   still-trusted-but-wrong CA (the actual threat pinning defends
///   against - a mis-issued or compromised CA cert for your domain)
///   passes platform validation and never reaches that callback, so it
///   would sail through unpinned.
///
/// This uses the approach that actually enforces pinning: build the
/// `HttpClient`'s `SecurityContext` with `withTrustedRoots: false` and
/// load ONLY the pinned certificate(s) into it via
/// `setTrustedCertificatesBytes`. With no other root CAs trusted, a
/// connection can only succeed against a server presenting one of the
/// exact pinned certs - a different, otherwise-valid CA-signed cert for
/// the same domain is rejected outright rather than reaching (and
/// possibly passing) a callback.
///
/// Inert as shipped: `ApiConstants.baseUrl` is still the placeholder
/// `api.yourapp.com` (see `config_check.dart` for the same pattern
/// around Firebase's placeholder config) and `_pinnedCertAssetPaths` is
/// empty, so `attachTo()` below is a no-op until both are real. Once
/// there's a real API domain: export its leaf (or intermediate) cert as
/// DER, add it under `assets/certs/`, list the asset path below, and
/// register it in `pubspec.yaml`'s `flutter: assets:`.
class SSLPinning {
  static const List<String> _pinnedCertAssetPaths = [
    // 'assets/certs/api_yourapp_com.der',
  ];

  static Future<void> attachTo(Dio dio) async {
    if (_pinnedCertAssetPaths.isEmpty) return;

    final context = SecurityContext(withTrustedRoots: false);
    for (final path in _pinnedCertAssetPaths) {
      final bytes = await File(path).readAsBytes();
      context.setTrustedCertificatesBytes(bytes);
    }

    (dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () {
      return HttpClient(context: context);
    };
  }
}
