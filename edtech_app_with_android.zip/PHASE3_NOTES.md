# Phase 3: Performance & offline capabilities

## Problem
Every course-data read was a live Firestore query, including one per
filter chip tap on the course list - the whole catalog was already in
memory but got re-fetched anyway. Loading states were bare spinners.
Three dependencies (`cached_network_image`, `lottie`, `fl_chart`,
`google_fonts`) sat in `pubspec.yaml` unused, adding to app size and
build time for nothing. The "download" button on a lesson was a no-op
placeholder despite `connectivity_plus` and `shimmer` already being
dependencies with nothing built on top of them. Logging out cleared a
Hive box that, at the time, held nothing - but that box was clearly
meant to hold *something* eventually.

## What changed

**Fetch the catalog once, filter in memory.** `allCoursesProvider`
fetches every course a single time per session; `courseListProvider`
now derives the filtered view from that in Dart instead of re-querying
Firestore per chip tap. `courseDetailProvider` checks the same cached
list before falling back to a direct fetch. `test/course_providers_test.dart`
asserts this with a call-count check, not just by inspection.

**Firestore's disk cache is uncapped** (`main.dart`) instead of the
40MB default - for a catalog with curriculum/video metadata plus a
student's own progress, the default cap meant older cached documents
would silently get evicted and stop being available offline.

**Perceived-performance polish**: `ShimmerBox`/`CourseCardSkeleton`/
`CourseRowSkeleton` (`lib/widgets/shimmer_placeholders.dart`) replace
bare spinners on the course grid and dashboard rows, matching the real
content's layout so there's no reflow when data arrives. `OfflineBanner`
(`lib/widgets/offline_banner.dart`), mounted once in `app.dart`'s
`MaterialApp.builder`, tells the student when they're looking at cached
data instead of a screen that looks frozen/broken.

**"Saved for Offline Browsing"** (bookmark icon on `VideoPlayerScreen`,
browsable from Settings): `OfflineLessonStore` (`lib/services/`) puts
the previously-unused `downloads` Hive box to work, storing lesson
*metadata* locally. Deliberately not called "download" anywhere in the
UI - `youtube_player_flutter` has no offline playback mode and
YouTube's terms don't allow caching the stream outside their own app,
so promising real offline video would be a lie. The feature is honestly
scoped to "browse your saved lesson list without a connection."

**Removed dead dependencies**: `cached_network_image`, `lottie`,
`fl_chart`, `google_fonts` - none were ever imported anywhere.

**Test coverage**: `test/offline_lesson_store_test.dart` added (round-trips
save/isSaved/remove/getAll against a real temp-dir Hive instance, not a
mock) - this was the one piece of new logic from this phase that had no
test yet.

## Deliberately out of scope for this phase
- Actual offline video playback - not achievable with YouTube-hosted
  lessons regardless of caching strategy (see `OfflineLessonStore`'s doc
  comment); would need lesson videos hosted as files on infrastructure
  you control.
- Real course thumbnail images - courses still render via icon+color
  (`CourseVisuals`), not photos, so `cached_network_image` had nothing
  to do. Worth revisiting once/if courses get real thumbnail URLs in
  Firestore.
- Pagination for the course catalog - `allCoursesProvider` fetching
  everything client-side only makes sense while the catalog is small
  (a single institution's worth of courses). Noted directly in the
  provider's doc comment as the thing to revisit if that stops being
  true.
